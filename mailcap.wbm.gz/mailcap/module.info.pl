desc_pl=Typy program�w MIME
longdesc_pl=Edytuj plik /etc/mailcap, kt�ry zawiera map� typ�w MIME i program�w do ich obs�ugi
