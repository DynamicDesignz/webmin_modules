# prodder-lib.pl

do '../web-lib.pl';
&init_config();
require '../ui-lib.pl'; 

sub readdatabase{
	($filename, $temp1) =@_;
	open(F1, $config{'bannerfilelocation'} .'/'. $filename);
	@data = <F1>;
	close(F1);
	return @data;
}
sub writeblockfile{
	($filename, $temp1) =@_;
	&open_tempfile(F1, ">".$config{'bannerfilelocation'} .'/'. $filename);
	&print_tempfile(F1, $in{"data_block"});
	&close_tempfile(F1);
	return 0;
}
sub bf_so_addtofile{
	($filename, $temp1) =@_;
	$lineblock = '';
	
	if(length($in{"add_line"}) < 1){
		return;
	}
	
	open(F1, $config{'bannerfilelocation'} .'/'. $filename);
	@data = <F1>;
	close(F1);
	
	foreach $line(@data){
		$lineblock = $lineblock . $line;
	}
	$lineblock = $lineblock . "\n" . $in{"add_line"};
	
	&open_tempfile(F1, ">".$config{'bannerfilelocation'} .'/'. $filename);
	&print_tempfile(F1, $lineblock);
	&close_tempfile(F1);
}
1;