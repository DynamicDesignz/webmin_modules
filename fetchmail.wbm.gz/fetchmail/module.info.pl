desc_pl=Fetchmail  - pobieranie poczty
longdesc_pl=Konfiguracja popularnego programu fetchmail do automatycznego pobierania e-maili z innych serwer�w
