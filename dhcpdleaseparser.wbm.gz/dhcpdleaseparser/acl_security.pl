#acl_security.pl
#Script that allows control over what parts of the module non-root/non-admin users can and cannot access

require 'dhcpdleaseparser-lib.pl';

sub acl_security_form
{
print "<tr> <td><b>Can do auto-capture?</b></td> <td nowrap>\n";
printf "<input type=radio name=lang value=1 %s> Yes\n",
	$_[0]->{'autoCapture'} ? 'checked' : '';
printf "<input type=radio name=lang value=0 %s> No</td>\n",
	$_[0]->{'autoCapture'} ? '' : 'checked';
}

sub acl_security_save
{
  $_[0]->{'autoCapture'} = $in{'autoCapture'};
}
