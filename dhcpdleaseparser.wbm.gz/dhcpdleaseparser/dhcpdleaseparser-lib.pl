# dhcpdleaseparser-lib.pl
# Functions for parsing IP addresses and locating them in DHCPD lease files
# Also need to write a function that deletes lease files from
# havok and polaris that are older than 12 weeks

# Be cognizant of the fact that dhcp leases are recorded in coordinated universal time (UTC), which is about 5 hours ahead of eastern time.  This does not matter so much here, as we are focusing more on date than time but this 5 hour difference is the reason a dhcpd.lease.date.02_00 file can contain a lease that has a start time of 05:00:00 (UTC).

BEGIN { push(@INC, ".."); };
use WebminCore;
&init_config();

%access = &get_module_acl();

=head2 checkDate($date)

Checks if date is properly formatted, returning 1 if yes and 0 if no.

=cut
sub checkDate
{
return $_[0] =~ /^(\d{4})\/(\d{2})\/(\d{2})$/ &&
	$1 >= 1000 && $2 >= 01 &&
	$2 <=12 && $3 >= 01 && $3 <= 31;
}

=head2 checkTime($time)

Checks if time is properly formatted, returning 1 if yes and 0 if no.

=cut
sub checkTime
{
return $_[0] =~ /^(\d{2})\:(\d{1,2})\:(\d{1,2})$/ &&
	$1 >= 00 && $2 >= 00 &&
	$2 <=59 && $3 >= 00 && $3 <= 59;
}

=head2 checkMac($mac)

Checks the Mac address given by the user to ensure that it is proper format.

=cut
sub checkMac
{
return (($_[0] =~ /^([a-zA-z0-9]{2})\:([a-zA-z0-9]{2})\:([a-zA-z0-9]{2})\:([a-zA-z0-9]{2})\:([a-zA-z0-9]{2})\:([a-zA-z0-9]{2})$/) or ($_[0] =~ /^([a-zA-z0-9]{12})/) );
}

=head2 checkOtherReason($text)

Ensures that the "other" category on the form contains only letters/spaces.

=cut
sub checkOtherReason
{
return $_[0] =~ /^(\D{0,15})$/;
}

=head2 read_leases_havok($date, $time)

Reads the lease of the date given, in addition to the leases assigned up to 2 lease periods (24 hrs) prior and 1 lease period (12 hrs) post the given date.  Returns a reference to an array containing the hashed leases.

Note: We have to check to see if current given date @ 1400 and/or post given date 0200 is either blank or current lease again.  This occurs when a mac address is trying to be found for the current date.  There are 2 cases: (a) User is trying to find Mac address for current date before 1400 (2pm) and (b) user is trying to find Mac address for same date but after 1400 (2pm).  In (a), $havokFiles[3] becomes dhcpd.leases.current.  This could result in a false positive because user is told Mac has been found, but program only checked 3 of the necessary files.  We don't have to check for (b) because $havokFiles[4] is empty so the program will only see 3 lease files and report "Mac not found."
This check is done for polaris files as well (see below).

=cut
sub read_leases_havok
{
  my ($date, $time, $auto_capture) = @_;
  @newdate = split(/\//, $date);
  @newtime = split(/:/, $time);
  $currdate = join("", @newdate);
  $currtime = join("", $newtime[0], $newtime[1]);

  # @leases is the array being returned by this subroutine
  # @leases includes hashes of all appropriate leases from
  # just havok so should return 3 leases
  my (@havokFiles,@hlease, @leases);
  my (@currLines, @curr02Lines, @curr14Lines, @preLines, @postLines);
  my ($havokdir) = $text{'havok'};
  opendir(HAVOK, $havokdir) or die "Ahh unable to open havok directory!";
  my (@havok) = readdir(HAVOK);
  closedir HAVOK;

  # HavokFiles array contains 4 items:
  # $havokFiles[0] = pre given date @ 1400
  # $havokFiles[1] = current given date @ 0200
  # $havokFiles[2] = current given date @ 1400
  # $havokFiles[3] = post given date @ 0200

  @havok = sort(@havok);
  my $newStr = $text{'havok'};
  for($i=0; $i< scalar(@havok); $i++) {
    if($havok[$i] =~ /$currdate/) {
      $tmp1 = $newStr.$havok[$i-1];
      $tmp2 = $newStr.$havok[$i];
      $tmp3 = $newStr.$havok[$i+1];
      $tmp4 = $newStr.$havok[$i+2];
      push(@havokFiles, $tmp1);
      push(@havokFiles, $tmp2);
      push(@havokFiles, $tmp3);
      push(@havokFiles, $tmp4);
      last;
    }
  }

  foreach (@havokFiles) {
    print $_."<br/>";
  }

  if(($havokFiles[3] =~ /(\/$)/)  && ($auto_capture == 0)) {
    die ("Not enough lease files to find Mac address.  Try again later!");
  }

  if($currtime < 1400) {
    if(($havokFiles[0] =~ /(\.$)/) && ($auto_capture == 0)) {
      die("Not enough leases to find Mac address.  Try again later!");
    } else {
      open(PRE, $havokFiles[0]) or die("Unable to find lease file for the day before this date");
    }
    open(CURR02_00, $havokFiles[1]) or die("Unable to find lease file for this date at 2:00am");
    open(CURR14_00, $havokFiles[2]) or die("Unable to find lease file for this date at 2:00pm");

    @preLines = <PRE>;
    @curr02Lines = <CURR02_00>;
    @curr14Lines = <CURR14_00>;

    close(PRE);
    close(CURR02_00);
    close(CURR14_00);
  } else {

    open(CURR02_00, $havokFiles[1]) or die("Unable to find lease file for the day before this date");
    open(CURR14_00, $havokFiles[2]) or die("Unable to find lease file for this date at 2:00am");
    open(POST, $havokFiles[3]) or die("Unable to find lease file for this date at 2:00pm");

    @curr02Lines = <CURR02_00>;
    @curr14Lines = <CURR14_00>;
    @postLines = <POST>;

    close(POST);
    close(CURR02_00);
    close(CURR14_00);
  }

  #my $currLease_ref = &parseFile(@currLines);
  #my %currLease = %$currLease_ref;
  #push @leases, {%currLease};

  my $curr02Lease_ref = &parseFile(@curr02Lines);
  my %curr02Lease = %$curr02Lease_ref;
  push @leases, {%curr02Lease};

  my $curr14Lease_ref = &parseFile(@curr14Lines);
  my %curr14Lease = %$curr14Lease_ref;
  push @leases, {%curr14Lease};

  if(@preLines) {
    my $preLease_ref = &parseFile(@preLines);
    my %preLease = %$preLease_ref;
    push @leases, {%preLease};
  }
  elsif(@postLines) {
    my $postLease_ref = &parseFile(@postLines);
    my %postLease = %$postLease_ref;
    push @leases, {%postLease};
  }

# The right way to access and print the array containing hashes of hashes.
#my $count = 1;
#foreach $entry (@leases) {
#  print "Lease #$count: <br/>";
#  %newEntry = %$entry;
#  foreach $ip_name (keys %newEntry) {
#    print "IP: $ip_name { ";
#    for $stuff (keys %{$newEntry{$ip_name}}) {
#      print "$stuff=$newEntry{$ip_name}{$stuff} ";
#    }
#    print "}<br/>";
#  }
#  $count++;
#}

  return \@leases;
}

=head2 read_leases_polaris($date, $time)

Reads the lease of the date given, in addition to the leases assigned up to 2 lease periods (24 hrs) prior and 1 lease period (12 hrs) post the given date.  Returns a reference to an array containing the hashed leases.

=cut
sub read_leases_polaris
{
  my ($date, $time, $auto_capture) = @_;
  @newdate = split(/\//, $date);
  @newtime = split(/:/, $time);
  $currdate = join("", @newdate);
  $currtime = join("", $newtime[0], $newtime[1]);

  # @leases is the array being returned by this subroutine
  # @leases includes hashes of all appropriate leases from
  # just polaris so should return 4 leases
  my (@polarisFiles,@please, @leases);
  my (@currLines, @curr02Lines, @curr14Lines, @preLines, @postLines);
  my ($polarisdir) = $text{'polaris'};
  opendir(POLARIS, $polarisdir) or die "Ahh unable to open polaris directory!";
  my (@polaris) = readdir(POLARIS);
  closedir POLARIS;

  # PolarisFiles array contains 4 items:
  # $polarisFiles[0] = pre given date @ 1400
  # $polarisFiles[1] = current given date @ 0200
  # $polarisFiles[2] = current given date @ 1400
  # $polarisFiles[3] = post given date @ 0200

  @polaris = sort(@polaris);
  my $newStr = $text{'polaris'};
  for($i=0; $i< scalar(@polaris); $i++) {
    if($polaris[$i] =~ /$currdate/) {
      $tmp1 = $newStr.$polaris[$i-1];
      $tmp2 = $newStr.$polaris[$i];
      $tmp3 = $newStr.$polaris[$i+1];
      $tmp4 = $newStr.$polaris[$i+2];
      push(@polarisFiles, $tmp1);
      push(@polarisFiles, $tmp2);
      push(@polarisFiles, $tmp3);
      push(@polarisFiles, $tmp4);
      last;
    }
  }

  foreach (@polarisFiles) {
    print $_."<br/>";
  }

  if(($polarisFiles[3] =~ /(\/$)/)  && ($auto_capture == 0)) {
    die ("Not enough lease files to find Mac address.  Try again later!");
  }

  if($currtime < 1400) {
    if(($polarisFiles[0] =~ /(\.$)/)  && ($auto_capture == 0)) {
      die("Not enough leases to find Mac address.  Try again later!");
    } else {
      open(PRE, $polarisFiles[0]) or die("Unable to find lease file for the day before this date");
    }
    open(CURR02_00, $polarisFiles[1]) or die("Unable to find lease file for this date at 2:00am");
    open(CURR14_00, $polarisFiles[2]) or die("Unable to find lease file for this date at 2:00pm");

    @preLines = <PRE>;
    @curr02Lines = <CURR02_00>;
    @curr14Lines = <CURR14_00>;

    close(PRE);
    close(CURR02_00);
    close(CURR14_00);
  } else {

    open(CURR02_00, $polarisFiles[1]) or die("Unable to find lease file for the day before this date");
    open(CURR14_00, $polarisFiles[2]) or die("Unable to find lease file for this date at 2:00am");
    open(POST, $polarisFiles[3]) or die("Unable to find lease file for this date at 2:00pm");

    @curr02Lines = <CURR02_00>;
    @curr14Lines = <CURR14_00>;
    @postLines = <POST>;

    close(POST);
    close(CURR02_00);
    close(CURR14_00);
  }

  my $curr02Lease_ref = &parseFile(@curr02Lines);
  my %curr02Lease = %$curr02Lease_ref;
  push @leases, {%curr02Lease};

  my $curr14Lease_ref = &parseFile(@curr14Lines);
  my %curr14Lease = %$curr14Lease_ref;
  push @leases, {%curr14Lease};

  if(@preLines) {
    my $preLease_ref = &parseFile(@preLines);
    my %preLease = %$preLease_ref;
    push @leases, {%preLease};
  }
  elsif(@postLines) {
    my $postLease_ref = &parseFile(@postLines);
    my %postLease = %$postLease_ref;
    push @leases, {%postLease};
  }

# The right way to access and print the array containing hashes of hashes.
#my $count = 1;
#foreach $entry (@leases) {
#  print "Lease #$count: <br/>";
#  %newEntry = %$entry;
#  foreach $ip_name (keys %newEntry) {
#    print "IP: $ip_name { ";
#    for $stuff (keys %{$newEntry{$ip_name}}) {
#      print "$stuff=$newEntry{$ip_name}{$stuff} ";
#    }
#    print "}<br/>";
#  }
#  $count++;
#}

  return \@leases;
}

=head2 parseFile(@lines)

Parses through lease file and puts each lease in a hash with the IP as a key for individual hashes that coddresntain the various other information associated with each lease.  Returns the hash of IPs.

=cut
sub parseFile
{
  my (@lines) = @_;
  my (%leases, $i, $tmp, $tmpLine);
  my ($IP) = '\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}';
  my ($DATE) = '\d{4}\/\d{2}\/\d{2}';
  my ($TIME) = '\d{2}\:\d{1,2}\:\d{1,2}';
  $tmpLine = shift(@lines);
  foreach $line (@lines) {
    if($line =~ /^[\#] (\w)/) {
     $tmpLine = shift(@lines);
     next;
    } else {
      #print "$tmpLine <br/>";
      next;
    }
  }
  $tmpLine = shift(@lines);
  $next = 'next';
  while($tmpLine ne undef) {
    if($tmpLine =~/^lease ($IP) {/) {
      my (%lease_info);
      $tmp = $1;
      until($tmpLine =~ /^[}]/) {
        $tmpLine = shift(@lines);
	if($tmpLine =~ /starts (\d+) ($DATE) ($TIME);/) {
	  $lease_info{starts} = $2;
	  $lease_info{startTime} = $3;
	}elsif($tmpLine =~ /ends (\d+) ($DATE) ($TIME);/ ) {
       	  $lease_info{ends} = $2;
	  $lease_info{endTime} = $3;
	}elsif($tmpLine =~ /[^($next)] binding state (.*);/) {
	  $lease_info{bindingState} = $1;
	}elsif($tmpLine =~ /hardware (\w+) (.*);/) {
       	  $lease_info{hardwareType} = $1;
    	  $lease_info{hardwareAddr} = $2;
	}elsif($tmpLine =~ /client-hostname \"(\S+)\";/) {
	  $lease_info{clientHost} = $1;
	}
      }  #end inner until loop
      # leases{tmp} = new hash that contains all
      # the relevant info associated with that ip.
      $leases{$tmp} = {%lease_info};
    }else {
      $tmpLine = shift(@lines);
    }
  }  #end outer while loop
  
  return \%leases;
}

=head2 find_MacAddr($ip,01 %lease)
Takes in references to hashes of the appropriate leases read by read_leases() and the ip and returns the mac address.

=cut
sub find_MacAddr
{
  my($ip, %lease, $auto_capture) = @_;

  #foreach $ip_name (keys %lease) {
  #  print "IP: $ip_name { ";
  #  for $stuff (keys %{$lease{$ip_name}}) {
  #    print "$stuff=$lease{$ip_name}{$stuff} ";
  #  }
  #  print "}<br/>";
  #}
  print "ip = ".$ip."<br/>";
  print "start date = ".$lease{$ip}{'starts'}." ".$lease{$ip}{'startTime'}."<br/>";
  print "end date = ".$lease{$ip}{'ends'}." ".$lease{$ip}{'endTime'}."<br/>";
  print "hw type = ".$lease{$ip}{'hardwareType'}."<br/>";
  print "hw address = ".$lease{$ip}{'hardwareAddr'}."<br/>";
  print "client-hostname = ".$lease{$ip}{'clientHost'}."<br/>";
  print "binding state = ".$lease{$ip}{'bindingState'}."<br/>";
  $hwAddr = 'hardwareAddr';
  if($auto_capture == 0) {
    if($lease{$ip}{'bindingState'} =~ /active/) {
      return $lease{$ip}{$hwAddr};
    } else {
      return "";
    }
  } else { # Admin access
    return $lease{$ip}{$hwAddr};
  }
}

=head2 edit_hostFile($hwAddr, $date, $reason, [$otherReason], [$releaseMac], $ip)

Reads/Writes/Appends bad hosts file.  Two optional arguments: a user-provided reason for capture and an option that indicates deletion of Mac address from file.

=cut
sub edit_hostFile
{
  my ($hwAddr, $ip, $date, $reason, $otherReason, $releaseMac) = @_;
  my (@hosts, @revisedHwAddr, @revisedDate, @revisedOther, $hostRecord, $mode, $mailMessage);
  my ($bad_hosts) = $text{'bad_hosts'};
  my ($bad_hosts_tmp) = $text{'bad_hosts_tmp'};
  open(READ_HOST, "/home/backup/bad_hosts") or die ("Unable to open bad hosts file!");

  # Reformats incoming data

  @revisedHwAddr = split(/:/, $hwAddr);
  my ($newHwAddr) = join("", @revisedHwAddr);

  @revisedDate = split(/\//, $date);
  my ($newDate) = join("", @revisedDate);

  @revisedOther = split(/\s/, $otherReason);
  my ($newOther) = join("", @revisedOther);

  if($newOther =~ /(^\/)(\s)*/) {
    $newOther = "";
  }

  # Checks to see if Mac address has already been captured.
  # Mode 0 means Mac Address was already captured in bad hosts file
  # Mode 1 means add new record to bad hosts file
  # Mode 2 means delete record from bad hosts file
  @hosts = <READ_HOST>;
  close (READ_HOST);

  foreach (@hosts) {
    chomp $_;
    if(/$hwAddr/) {
      $mode = 0;
      last;
    }
    else {
      $mode = 1;
    }
  }
  if($releaseMac eq "yes") { 
    # Checks if Mac was already released from file
      if($mode == 1) {
	die "Mac not found in file.<br/>";
      } else {
	$mode = 2;
      }
  }

  if($mode == 0) {
    $mailMessage = "The Mac Address '$hwAddr' was already captured on $date.";
    print $mailMessage;
  }
  elsif($mode == 1) {
    open(APPEND_HOST, ">>/home/backup/bad_hosts") or die("Unable to open bad hosts file!");
    if($reason eq 'other') { $reason = ""; }
    $hostRecord = "host $newHwAddr"."-".$reason.$newOther."_".$newDate." { hardware ethernet $hwAddr"."; }\n";

    print APPEND_HOST $hostRecord;
    close (APPEND_HOST);
    system("sort /home/backup/bad_hosts | uniq > /home/backup/bad_hosts_tmp");
    system("mv /home/backup/bad_hosts_tmp /home/backup/bad_hosts");
    print $hostRecord."<br/>";
    $mailMessage = "<br/>Mac Address added to bad hosts file.<br/>Mac captured.<br/>IP: $ip {<br/>hardware ethernet $hwAddr;<br/>}<br/>";
    print $mailMessage;
  }
  elsif($mode == 2) {
    my ($line, $match, $newline);
    my ($counter) = 0;

    # implementation for the following borrowed
    # from original macrelease.pl written by Adrianne
    foreach $line (@hosts) {
      chomp $line;
      if($line =~ /$hwAddr/) {
	$match = "$line";
        $counter = $counter + 1;
	next;
      } else {
	$newline .= "$line\n";
      }
    }

    if ($counter =~ /0/) {
	die "Mac address not found in bad hosts file.  Check address and try again.";
    } else {
      open(WRITE_HOST, ">/home/backup/bad_hosts") or die("Unable to open bad hosts file!");
      print WRITE_HOST $newline;
      close (WRITE_HOST);
      $mailMessage = 'The line '.$match.' has been deleted from bad hosts.<br/>';
      print $mailMessage;

      # To sort and delete duplicates from bad hosts
      # (again borrowed from original format_bad_hosts.pl
      # written by Adrianne)
    system("sort /home/backup/bad_hosts | uniq > /home/backup/bad_hosts_tmp");
    system("mv /home/backup/bad_hosts_tmp /home/backup/bad_hosts");
    }
  }

  return $mailMessage;

}
