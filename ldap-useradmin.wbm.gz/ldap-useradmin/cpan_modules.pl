
require 'ldap-useradmin-lib.pl';

sub cpan_recommended
{
return ( "Net::LDAP" );
}

