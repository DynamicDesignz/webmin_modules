#!/usr/bin/perl

my @av_actions_list = ( "disinfect", "delete", "copy-to-quarantine", "pipe", "move-to-quarantine", "ignore", "drop", "reject" );
my @av_actions_no = ( "0", "1", "2", "2", "3", "3", "3", "3");

my @as_actions_list = ( "copy-to-quarantine", "pipe", "move-to-quarantine", "ignore", "drop", "reject" );
my @as_actions_no = ("2", "2", "3", "3", "3", "3");

sub max {
    my($max) = shift(@_);

    foreach $temp (@_) {
        $max = $temp if $temp > $max;
    }
    return($max);
}

# This function tells which actions are going to be enabled.
# It returns the actions parameters which are sent to bdsafe.
# It receives three parameters: ALL actions, their source (antivirus
# or antispam) and the pipe program existance status
sub active_actions
{
my @actions_list;
my @actions_no;
my $actions_ref = shift;
my $actions_source = shift;
my $pipe_exists = shift;

my @actions = @$actions_ref;
my $level = 0;

if ( $actions_source eq "antivirus" )
	{
		@actions_list  = @av_actions_list;
		@actions_no = @av_actions_no;
		if ( $pipe_exists eq "false" )
		        {
		                $actions_list[3] = "";
		        }
	}
else 
	{
		@actions_list  = @as_actions_list;
		@actions_no = @as_actions_no;
		if ( $pipe_exists eq "false" )
		        {
		                $actions_list[1] = "";
		        }
	}


my $final_actions;
for $i ( 0 .. $#actions_list )
	{
		#$red[$i] = 0;
		for $x ( 0 .. $#actions_list )
			{
			if ( $actions_list[$x] eq $actions[$i] )
				{
					if ( ($actions_no[$x] lt $level) || ($level eq "3") )
						{
						#$red[$i] = 0;
						}
					else
						{
						#$red[$i] = 1;
						$final_actions = $final_actions.$actions[$i].";";
						}
					$level = &max( $actions_no[$x], $level);
				}

			}
	}
chop $final_actions;
return $final_actions;
}

sub parse_action_group
{
my $action_key = shift;
my $action_source = shift;
my $action_type = shift;
my $reg_actions = &group_getkey ( $group, $action_key );
my @actions  = split(/;/,$reg_actions);

if ( $in{'up'} ne "" )
	{
	my $moving = $in{'up'};
	my $temp_action = $actions[$moving-1];
	$actions[$moving-1] = $actions[$moving];
	$actions[$moving] = $temp_action;
	}
elsif ( $in{'down'} ne "" )
	{
	my $moving = $in{'down'};
	my $temp_action = $actions[$moving+1];
	$actions[$moving+1] = $actions[$moving];
	$actions[$moving] = $temp_action;
	}

my $all_actions_string = "";
for $i ( 0 .. $#actions )
        {
                $all_actions_string = $all_actions_string."$actions[$i];";
        }	
chop $all_actions_string;
# Set all the actions in their new order
&BDReg_SetKey($group_root.$action_key, "$all_actions_string");

# Find out if we have a pipe program enabled
my $pipe_key = "$group_root/Settings/Antivirus/PipeProgram";
if ( $action_source eq "antispam" )
	{
		 $pipe_key = "$group_root/Settings/Antispam/PipeProgram";
	}
my $pipe_existance = "false";
my $pipe_program = &BDReg_GetKeys($pipe_key);
if ( &validate_path($pipe_program) )
	{
		$pipe_existance = "true";	
	}
# Get the string to set the active actions
my $active_actions_string = &active_actions(\@actions, $action_source, $pipe_existance);
# Set the new active actions
&bdsafe_run("group configure \'$in{'group'}\' \'$action_source\' \'$action_type\' \'$active_actions_string\'");
}
