#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_quarantine.pl';

use Digest::MD5  qw(md5 md5_hex md5_base64);
use File::stat;
use Time::localtime;

my %q_data = (  fileqr_path       => "/BDUX/FileDaemon/Quarantine",
		mailqr_path       => "/BDUX/MailDaemon/Quarantine",
		monq_path         => "/BDUX/WatchDog/Quarantine",
		fileqr_email      => "/BDUX/FileDaemon/SubmitFrom",
		mailqr_email      => "/BDUX/MailDaemon/SubmitFrom",
		monq_email        => "/BDUX/WatchDog/SubmitFrom",
	      );

my $quar_base = "/BDUX/Quarantine/Directories/";

sub create_cache_file
{
my ($path, $query_type, $query_string, $file_name) = @_;
	if ( not -e "$bitdefender_dir/var/tmp/search_cache")
		{
			mkdir "$bitdefender_dir/var/tmp/search_cache";
		}
	if ( ($query_type eq "uuid") && ($query_string eq "*") )
		{
		# If the search was for * uuids then we list all the contents
		$command = "$bitdefender_dir/bin/bdsafe quar RAOsulist $path";
		}
	else
		{
		# Else, we perform the corresponding search
		$command = "$bitdefender_dir/bin/bdsafe quar RAOsufind $path $query_type \"$query_string\"";
		}
	my $command_results = `$command > $bitdefender_dir/var/tmp/search_cache/$file_name`;

}

sub clean_search_cache
{
opendir(DIR, "$bitdefender_dir/var/tmp/search_cache/");
my @files= readdir(DIR);
foreach $file (@files)
	{
	my $file_time = stat("$bitdefender_dir/var/tmp/search_cache/$file")->mtime;
	if (time - $file_time > 3600)
		{
		unlink("$bitdefender_dir/var/tmp/search_cache/$file");
		}
	}

}

sub clean_search_cache
{
# Remove cache file for a specific search
my ($path, $query_type, $query_string) = @_;
my $query_md5 = md5_hex("$query_type $query_string");
unlink("$bitdefender_dir/var/tmp/search_cache/${path}_${query_md5}");
}

sub page_items()
{
	# returneaza o lista de dimensiunea "items_per_page" cu numele fisierelor din
	# "path", corespunzatoare "page_number" (pentru items_per_page=10 si
	# page_number=3 returneaza o lista cu fisierele de la 21 la 30, in ordine
	# alfabetica)
	#$qpath, $items_per_page, $page_number, $query_string, $query_type
	
	my $path;
	my $items_per_page;
	my $page_number;
	my @files=();
	my %desired_files = ();
	my $desired_files_uuids = "";
	my $item = "";
	my $no = 0;
	my $i=0;
	my $command;
	my $line = "";


	if (! defined $_[0] || ! defined $_[1] || ! defined $_[2])
	{
		return %desired_files;
	}

	$path = $_[0];
	$items_per_page = $_[1];	
	$page_number = $_[2];   
	my $query_string = $_[3];
	my $query_type = $_[4];	
	$path =~ s/([ \t\n\r]+)$//;                                                                                          
        $path =~ s/^([ \t\n\r]+)//;

	
	if ($path eq "")
	{
		return %desired_files;
	}
	
	# We make a list with the UUIDs matching the rule we were given
	# $uuids contains all the matching uuids and $no their number
	
	my $query_md5 = md5_hex("$query_type $query_string");
	my $file_name = $path."_".$query_md5;
	# The cache filename is an md5sum on the query
	if ( not -e "$bitdefender_dir/var/tmp/search_cache/$file_name")
		{
			&create_cache_file($path, $query_type, $query_string, $file_name);
		}
	else
		{
		my $file_time = stat("$bitdefender_dir/var/tmp/search_cache/$file_name")->mtime;
		if (time - $file_time > 3600)
			{
				&clean_search_cache;
				&create_cache_file($path, $query_type, $query_string, $file_name);
			}
		}
	# We find out the number of all items
	$no = `wc -l $bitdefender_dir/var/tmp/search_cache/$file_name`;
	$no =~ s/^(.*) .*/$1/;

	$lower_limit = ($page_number - 1) * $items_per_page;
	if ( $lower_limit > $no )
		{
			# If the page number is too big return the last
			# possible page
			$page_number = int($no/$items_per_page)+1;
			$lower_limit = ($page_number - 1) * $items_per_page;
		}
	# Here we calculate for what UUIDs we show the infos and make up
	# a list with them for the RAOsuinfo command
	if ( $no > 0 )
	{
		my $upper_limit = $page_number * $items_per_page;
		if ($upper_limit > $no)
		{
			$upper_limit = $no;
		}
		# Go in the file to the first id we should show
		open(FILE, "< $bitdefender_dir/var/tmp/search_cache/$file_name") or die "can't open file: $!";
		if ( $lower_limit ne "0" )
		{
			do { $line = <FILE> } until $. == $lower_limit || eof;
		}
		do 
			{ 
			$line = <FILE>; 
			chomp($line);
			$desired_files_uuids = $desired_files_uuids."$line ";
			} 
		until $. == $upper_limit || eof;
		close(FILE);
	}
	
	# We run the command for finding out details on files and put the details into
	# %desired_files hash
	if ( $desired_files_uuids )
	{
		for ( `$bitdefender_dir/bin/bdsafe quar RAOsuinfo $path $desired_files_uuids` ) 
		{
	       		$_ =~ s|^([^:]*): ?(.*)$|\$desired_files{\'$1\'}\[\$idx_$1++\] = \'$2\';|mg; #'
		        no strict "vars";
			#print "$_";
		        eval "$_; return(1);";
	  	}
	}

	$pages_tmp = int($no/$items_per_page);
	if ( $pages_tmp*$items_per_page < $no )
		{$pages_tmp++;}
	return ($pages_tmp, %desired_files);
}

sub search_quarantine
{
	# poate primi trei argumente:
	# $subcat - ce carantina trebuie desenata (mailqr, fileqr, monq)
	# $items_per_page - numarul de fisiere din carantina care trebuie afisate pe
	# 	  pagina (daca nu e primit, default e 10)
	# $page_number - numarul paginii cu fisierele din carantina
	#		(daca nu e primit, default e 1)
	# 
	# trebuie sa afle urmatoarele variabile
	# (cu &BDReg_GetKeys ("cale_cheie") din bitdefender-lib.pl sau altcumva)
	# - qpath = "string" (quarantine location)
	# - qemail = "string" (email addres for submitting av quarantine)
	# - @files = ("string", "array"); (o lista de nume fisiere din carantina
	#   antivirus (&page_items(qpath, items_per_page, page_number)))
	
	my $subcat="bdmond";
	my $items_per_page = 10;
	my $page_number = 1;
	my $qpath = "";
	my $qemail;
	my $query_string = "*";
	my $query_type = "sender";
	my @files = ();
	my %files_info;
	my $pages = 0;
	if ( defined $_[0] )
	{
		$subcat = $_[0];
		if ( defined $_[1] )
		{
			$query_type = $_[1];
			if ( defined $_[2] )
			{
				$query_string = $_[2];
				if ( defined $_[3] )
				{
					$items_per_page = $_[3];
					if ( $items_per_page lt 1)
					{$items_per_page = 10;}
					if ( defined $_[4] )
					{
						$page_number = $_[4];
						if ( $page_number lt 1)
						{$page_number = 1;}
					}
				}
			}
		}
	}
	my $mbox_queue = &BDReg_GetKeys("/BDUX/Quarantine/MboxQueue");
	my $maildir_queue = &BDReg_GetKeys("/BDUX/Quarantine/MaildirQueue");
	my $queue = "";
	my $queue_size = 0;

	if ( ($maildir_queue ne "ERR_KEY_DOES_NOT_EXIST") && ($maildir_queue ne "0")
		&& ( -e "$bitdefender_dir/var/tmp/exported_maildir/" ) )
		{
			$queue = "maildir";
			$queue_size = $maildir_queue;
		}
	else
		{
			if ( -e "$bitdefender_dir/var/tmp/exported_maildir/")
			{
			use File::Path;
			rmtree("$bitdefender_dir/var/tmp/exported_maildir/", 0, 1);
			}
		}


	if ( ($mbox_queue ne "ERR_KEY_DOES_NOT_EXIST") && ($mbox_queue ne "0") 
		&& ( -e "$bitdefender_dir/var/tmp/exported_mbox") )
		{
			$queue = "mbox";
			$queue_size = $mbox_queue;

		}
	else 
		{
			if ( -e "$bitdefender_dir/var/tmp/exported_mbox" )
			{
				unlink("$bitdefender_dir/var/tmp/exported_mbox");
			}
		}	
#	$qpath = &BDReg_GetKeys($q_data{$subcat.'_path'});
#	if ( $qpath ne "ERR_KEY_DOES_NOT_EXIST" )
#	{
#		$qemail = &BDReg_GetKeys($q_data{$subcat.'_email'});
#
#		if ( $qemail eq "ERR_KEY_DOES_NOT_EXIST" )
#		{
#			$qemail = "";
#			my $email_text = &BDReg_GetKeys("/BDUX/Hostname");
#			if ($email_text ne "")
#			{
#				$qemail = "bitdefender@".$email_text;
#				&BDReg_SetKey($q_data{$subcat.'_email'}, $qemail);
#			}
#		}
		
		#($pages, @files) = &page_items($qpath, $items_per_page, $page_number);
		($pages, %files_info) = &page_items($subcat, $items_per_page, $page_number, $query_string, $query_type,);

		&draw_quarantine( $subcat, $qpath, $qemail, \%files_info, $pages, $page_number, 
			$items_per_page, $query_type, $query_string, $queue, $queue_size );
#	}
#	else
#	{
#		$subcat = "monq";
#		#$qpath = &BDReg_GetKeys($q_data{$subcat.'_path'});
#		$qpath = "/opt/BitDefender/var/quarantine/test";
#		$qemail = &BDReg_GetKeys($q_data{$subcat.'_email'});
#
#		if ( $qemail eq "ERR_KEY_DOES_NOT_EXIST" )
#		{
#			$qemail = "";
#			my $email_text = &BDReg_GetKeys("/BDUX/Hostname");
#			if ($email_text ne "")
#			{
#				$qemail = "bitdefender@".$email_text;
#				&BDReg_SetKey($q_data{$subcat.'_email'}, $qemail);
#			}
#		}
#		
#		($pages, @files) = &page_items($qpath, $items_per_page, $page_number);
#
#		&draw_quarantine( $subcat, $qpath, $qemail, \@files, $pages, $page_number, $items_per_page );
#	}
}

sub do_quarantine
{
	my $subcat = "bdmond";
	if ( defined $_[0] )
        {
                $subcat = $_[0];
	}
	# Draw initial status and search page
	my $command_results = `$bitdefender_dir/bin/bdsafe quarantine status $subcat noni`;
	my @stats = split(/\n/, $command_results) ;

	#&draw_status_quarantine($subcat, \@stats);
	&search_quarantine($subcat, "uuid", "*", "10", "1");
}

sub do_view_message
{
	my $subcat = "bdmond";
	my $uuid_pair = "1";
	my $content_type = "text";
	my $view_type = "stripped"; 
	if ( defined $_[0] )
	{
		$view_type = $_[0];
	}
	if ( defined $_[1] )
	{
		$subcat = $_[1];
	}
	if ( defined $_[2] )
	{
		$uuid_pair = $_[2];
	}
	my $command_results = `$bitdefender_dir/bin/bdsafe quarantine RAOsucopy $subcat $bitdefender_dir/var/tmp $uuid_pair`;
	my $uuid = $uuid_pair;
	$uuid =~ s/^.*://;
	my @contents = `$bitdefender_dir/bin/bdsafe mail explode $bitdefender_dir/var/tmp/${subcat}_${uuid}.eml`; 
	# Delete the temporary eml file
	unlink("$bitdefender_dir/var/tmp/${subcat}_${uuid}.eml");

	my @attachments=();
	while ( $contents[0] =~ /^Attachment: / )
	        {
	                my $attachment = shift(@contents);
	                $attachment =~ s/^Attachment: //;
	                push (@attachments, $attachment);
	        }
	if ($contents[0] =~ /BodyText/)
	{
		$contents[0] =~ s/^BodyText: //;
		$content_type = "text";
		
	}
	elsif ($contents[0] =~ /BodyHTML/)
	{
		$contents[0] =~ s/^BodyHTML: //;
		$content_type = "html";
	}

	if ( ($view_type ne "full") )
	{
	foreach $body_line ( @contents )
		{
			#$body_line =~ s/\<[^\<]+\>//g;
			$body_line = &html_escape($body_line);
			$body_line =~ s/\n/<br>\n/sg;
		}
	}
	my %file_info = ();
        for ( `$bitdefender_dir/bin/bdsafe quar RAOsuinfo $subcat $uuid_pair` )
        {
                $_ =~ s|^([^:]*): ?(.*)$|\$file_info{\'$1\'}\[\$idx_$1++\] = \'$2\';|mg; #'
                no strict "vars";
		#print "$_";
                eval "$_; return(1);";
        }
	if ($view_type eq "full")
	{&draw_view_html(\@contents); }
	else
	{&draw_view_message( $subcat, $uuid_pair, \@contents, $content_type, $file_info{'From'}[0], 
	$file_info{'To'}[0], $file_info{'Subject'}[0], $file_info{'Date'}[0], \@attachments);}

}

