#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_reports.pl';

my $basekey = "/BDUX/LoggerDaemon/Config/Messages/Enum/";

sub do_graphic
{
# $daemon - the daemon for which the graph is drawn $graph fields - which fields to be drawn
my ($daemon, $graph_fields, $graph_interval) = @_;
my $output = `$bitdefender_dir/bin/bdcharts -l "$bitdefender_dir/var/stats/$daemon.stats"`;
my @all_fields = split(/\n/,$output);
my %checked_fields;

foreach $field (@all_fields)
	{$checked_fields{$field} = "";}

my $graph_fields_string = "";
my $graph_field_names = "\"";
# Create graph arguments for fields and field names
if ($graph_fields eq "")
	{ 
	foreach $field ( @all_fields )
		{ 
		$graph_fields_string = $graph_fields_string."$field,";
		$checked_fields{$field} = "checked";
		my $temp_name = lc($field);
		$graph_field_names = $graph_field_names."$text{'stats_'.${temp_name}},";
		}
	chop $graph_fields_string;
	chop $graph_field_names;
	$graph_field_names = $graph_field_names."\"";
	# Add " for graph_field_names because it has spaces
	}
else
	{
	my @options = split(/\0/, $graph_fields);
	foreach $option (@options)
	        {
	                $graph_fields_string = $graph_fields_string."$option,";
			$checked_fields{$option} = "checked";
			my $temp_name = lc($option);
			$graph_field_names = $graph_field_names."$text{'stats_'.$temp_name},";
	        }
	chop $graph_fields_string;
	chop $graph_field_names;
	$graph_field_names = $graph_field_names."\"";
	# Add " for graph_field_names because it has spaces
	}

# We attach the time to the graph file name to make sure
# that the browser loads it again and doesn't take it from
# cache
my ($sec,$min,$hour,$mday,$mon,$year,$wday,
	$yday,$isdst)=localtime(time);
$year = $year + 1900;
$mon = $mon + 1;
my $graph_time = "$year-$mon-$mday-$hour-$min-$sec";
if ($graph_interval eq "")
	{
	$graph_interval = "1_week";
	}	
# Read the symling to the old graph file
$old_graph = readlink("images/graph_${daemon}.png");
if ( -e "images/$old_graph" )
{
	        unlink("images/$old_graph");
}
#print "Content-Type: text/html\n\n $bitdefender_dir/bin/bdcharts -d -i $bitdefender_dir/var/stats/$daemon.stats -o images/graph-$daemon-$graph_time.png -c $graph_fields_string -n $graph_field_names -t $graph_interval";
# Delete the symlink too
unlink("images/graph_${daemon}.png");
$output = `$bitdefender_dir/bin/bdcharts -d -i "$bitdefender_dir/var/stats/$daemon.stats" -o "images/graph-$daemon-$graph_time.png" -c $graph_fields_string -n $graph_field_names -t $graph_interval --ytitle $text{'stats_ygraph_'.$daemon}`;

# Make new symlink
symlink("graph-$daemon-$graph_time.png", "images/graph_${daemon}.png");
return ("graph-$daemon-$graph_time.png", \@all_fields, \%checked_fields);
}

sub do_statistics
{
my ($Mails_Scanned, $Mails_Infected, $Mails_Disinfected, $Mails_Quarantined,
	$Mails_Rejected, $Mails_Spam, $Mails_Ignored, $Mails_Dropped) = ( '0','0','0','0','0','0','0','0' );

my ($Files_Scanned, $Files_Infected, $Files_Disinfected, 
	$Files_Quarantined, $Files_Ignored, $Files_Deleted, 
	$Files_Denied, $Files_CacheHits, $Files_CacheSize) = ('0','0','0','0','0','0','0','0','0');

my ($maildaemon_enabled, $filedaemon_enabled) = ("0", "0");
# Check if there is MailDaemon
if ( -e "$bitdefender_dir/var/mail.inf" )
{
	$maildaemon_enabled = "1";
	#Get MailDaemon statistics
	(my $output = &BDReg_GetKeys ("/BDUX/MailDaemon/Stats/\n\n")) =~ s|/BDUX/MailDaemon/Stats||g;
	$output =~ s/.*\n//;
	# build a piece of perl code
	$output =~ s|/|Mails_|g;
	$output =~ s|(.*)<>(.*)|\$$1 = $2;|mg;

	# disable strict vars temporarly to not abort the script in case new registry keys appear
	no strict "vars";
	
	# "run" the little script we made to set the variables
	eval "$output; return(1);";
	use strict "vars";

}

# Check if there is Filedaemon
if ( -e "$bitdefender_dir/var/samba.inf" )
{
	$filedaemon_enabled = "1";
        #Get FileDaemon statistics
        (my $output = &BDReg_GetKeys ("/BDUX/FileDaemon/Stats/\n\n")) =~ s|/BDUX/FileDaemon/Stats||g;
        $output =~ s/.*\n//;
        # build a piece of perl code
        $output =~ s|/|Files_|g;
        $output =~ s|(.*)<>(.*)|\$$1 = $2;|mg;

        # disable strict vars temporarly to not abort the script in case new registry keys appear
        no strict "vars";
        
        # "run" the little script we made to set the variables
        eval "$output; return(1);";
        
        use strict "vars";	
	$Files_CacheSize = &BDReg_GetKeys ("/temp/bdfiled/CacheSize");
	$Files_CacheSize =~ s/ERR_KEY_DOES_NOT_EXIST/0/;
}
&draw_statistics($maildaemon_enabled, $filedaemon_enabled, $Mails_Scanned, $Mails_Infected, $Mails_Disinfected,
	$Mails_Quarantined, $Mails_Rejected, $Mails_Spam, $Mails_Ignored, $Mails_Dropped, 
	$Files_Scanned, $Files_Infected, $Files_Disinfected, $Files_Quarantined, $Files_Ignored, 
	$Files_Deleted, $Files_Denied, $Files_CacheHits, $Files_CacheSize);
}

sub do_charts
{
my ($File_Daemon, $Mail_Daemon) = ("no", "no");
my ($bdmaild_graph_fields, $bdfiled_graph_fields, $bdmond_graph_fields, 
	$bdmaild_graph_interval, $bdfiled_graph_interval, $bdmond_graph_interval) = @_;
if ($bdmaild_graph_interval eq "") 
	{ $bdmaild_graph_interval = "1_week";}
if ($bdfiled_graph_interval eq "")
	{ $bdfiled_graph_interval = "1_week";}
if ($bdmond_graph_interval eq "")
	{ $bdmond_graph_interval = "1_week";}

my ($bdmaild_graph_file, $bdmaild_graph_all_fields, $bdmaild_graph_checked_fields,
	$filed_graph_file, $filed_graph_all_fields, $filed_graph_checked_fields,
	$mond_graph_file, $mond_graph_all_fields, $mond_graph_checked_fields) = ("", "", "", "", "", "", "", "", "");

# Check if there is MailDaemon
if ( -e "$bitdefender_dir/var/mail.inf" )
{
	# Do MailDaemon statistics graph
	$Mail_Daemon="yes";
	($bdmaild_graph_file, $bdmaild_graph_all_fields, $bdmaild_graph_checked_fields) = &do_graphic("bdmaild", $bdmaild_graph_fields, $bdmaild_graph_interval);
}

# Check if there is Filedaemon
if ( -e "$bitdefender_dir/var/samba.inf" )
{
	# Do FileDaemon statistics graph
	$File_Daemon="yes";
	($filed_graph_file, $filed_graph_all_fields, $filed_graph_checked_fields) = &do_graphic("bdfiled", $bdfiled_graph_fields, $bdfiled_graph_interval);
}

# Do mond statistics graph
($mond_graph_file, $mond_graph_all_fields, $mond_graph_checked_fields) = &do_graphic("bdmond", $bdmond_graph_fields, $bdmond_graph_interval);

$graph_file = "graph.png";
&draw_charts($Mail_Daemon, $File_Daemon, $bdmaild_graph_file, $bdmaild_graph_all_fields, 
		$bdmaild_graph_checked_fields, $bdmaild_graph_interval, $filed_graph_file, 
		$filed_graph_all_fields, $filed_graph_checked_fields, $bdfiled_graph_interval,
	       	$mond_graph_file, $mond_graph_all_fields, $mond_graph_checked_fields, $bdmond_graph_interval);
}

sub do_advanced_file_logging
{
my $rule_names_ref = shift;
my @rule_names = @$rule_names_ref; #split(/\n/, &BDReg_GetKeys($basekey));
my @file_logs;
my $file_logs_index = 0;

for $i ( 0 .. $#rule_names )
	{
		my $filelog_enabled = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog");
		if ( $filelog_enabled ne "ERR_KEY_DOES_NOT_EXIST" )
			{
				$file_logs[$i][0] = $rule_names[$i];
				
				$file_logs[$i][1] = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/Path");
				$file_logs[$i][2] = &verify_check("$basekey"."$rule_names[$i]"."/filelog/LogRotate");
				my $loginterval = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/LogRotate/Interval");
				# Here we store interval size and type (hours, days, weeks, months) in separate variables
				($file_logs[$i][3], $file_logs[$i][4]) = $loginterval =~ /([0-9]*)([hdwm])/;
				my $logsize = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/LogRotate/Size");
				# Here we store log size and type (M or K) in separate variables
				($file_logs[$i][5], $file_logs[$i][6]) = $logsize =~ /([0-9]*)([MK])/;
				$file_logs[$i][7] = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/LogRotate/Entries");
				$file_logs[$i][7] =~ s/ERR_KEY_DOES_NOT_EXIST//;
				$file_logs[$i][8] = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/LogRotate/Count");
				$file_logs[$i][8] =~ s/ERR_KEY_DOES_NOT_EXIST//;
				$file_logs_index++;
			}
	}
	
&draw_advanced_file_logging(\@file_logs);
}

sub do_file_logging
{
my @rule_names = split(/\n/, &BDReg_GetKeys("$basekey"));
my @file_logs_enabled, @file_logs_disabled;;
my ($fl_enabled_index, $fl_disabled_index) = (0, 0);
for $i ( 0 .. $#rule_names )
	{
		my $filelog_enabled = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog");
		if ( $filelog_enabled eq "y" || $filelog_enabled eq "Y" || $filelog_enabled eq "yes" )
			{
				$file_logs_enabled[$fl_enabled_index][0] = $rule_names[$i];
				$file_logs_enabled[$fl_enabled_index][1] = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/Path");
				$file_logs_enabled[$fl_enabled_index][1] =~ s/ERR_KEY_DOES_NOT_EXIST//;
				$fl_enabled_index++;
			}
		elsif ( $filelog_enabled eq "n" || $filelog_enabled eq "N" || $filelog_enabled eq "no" )
			{
				$file_logs_disabled[$fl_disabled_index][0] = $rule_names[$i];
				$file_logs_disabled[$fl_disabled_index][1] = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/filelog/Path");
				$file_logs_disabled[$fl_disabled_index][1] =~ s/ERR_KEY_DOES_NOT_EXIST//;
				$fl_disabled_index++;
			}
	}
&draw_file_logging(\@file_logs_enabled, \@file_logs_disabled);
}

sub do_mail_logging
{
my @rule_names = split(/\n/, &BDReg_GetKeys("$basekey"));
my @mail_logs_enabled, @mail_logs_disabled;
my ($ml_enabled_index, $ml_disabled_index) = (0, 0);
for $i ( 0 .. $#rule_names )
	{
		my $maillog_enabled = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/smtp");
		if ( $maillog_enabled eq "y" || $maillog_enabled eq "Y" || $maillog_enabled eq "yes")
			{
				$mail_logs_enabled[$ml_enabled_index][0] = $rule_names[$i];
				my $mails = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/smtp/DestEmails/");
				$mails =~ s/\n/, /g;
				$mails =~ s/ERR_KEY_DOES_NOT_EXIST//;

				$mail_logs_enabled[$ml_enabled_index][1] = $mails; 
				$ml_enabled_index++;
			}
		elsif ( $maillog_enabled eq "n" || $maillog_enabled eq "N" || $maillog_enabled eq "no" )
			{
				$mail_logs_disabled[$ml_disabled_index][0] = $rule_names[$i];
				my $mails = &BDReg_GetKeys("$basekey"."$rule_names[$i]"."/smtp/DestEmails/");
				$mails =~ s/\n/, /g;
				$mails =~ s/ERR_KEY_DOES_NOT_EXIST//;

				$mail_logs_disabled[$ml_disabled_index][1] = $mails;
				$ml_disabled_index++;
			}
	}
&draw_mail_logging(\@mail_logs_enabled, \@mail_logs_disabled);
}

sub do_logging
{
my ($daemon, $event) = @_;
defined $daemon or $daemon = "*";
defined $event or $event = "license";

my $basekey = "$basekey"."$daemon"."."."$event"."/";

my $filelog_enable = &verify_check($basekey."filelog");
my $filelog_path = &BDReg_GetKeys($basekey."filelog/Path");
my $filelog_rotate = &verify_check($basekey."filelog/LogRotate");

my $mail_enable = &verify_check($basekey."smtp");
my $snmp_enable = &verify_check($basekey."snmp");
my $dblog_enable = &verify_check($basekey."dblog");

$filelog_path =~ s/ERR_KEY_DOES_NOT_EXIST//
&draw_logging($daemon, $event, $filelog_enable, $filelog_path, $filelog_rotate, $mail_enable, $snmp_enable, $dblog_enable);
}

sub do_notifications
{
my $notifications_enable = 	&verify_check("/BDUX/LoggerDaemon/Plugins/MNsmtp/Enable");
my $from = 			&BDReg_GetKeys ("/BDUX/LoggerDaemon/Plugins/MNsmtp/From");
my $server = 			&BDReg_GetKeys ("/BDUX/LoggerDaemon/Plugins/MNsmtp/SMTPServer");
my $administrator = 		&BDReg_GetKeys ("/BDUX/LoggerDaemon/Plugins/MNsmtp/Administrator");
my $postmaster = 		&BDReg_GetKeys ("/BDUX/LoggerDaemon/Plugins/MNsmtp/Postmaster");
my $alertsender_enable =	&verify_check("/BDUX/LoggerDaemon/Plugins/MNsmtp/AlertSender");
my $alertreceivers_enable = 	&verify_check("/BDUX/LoggerDaemon/Plugins/MNsmtp/AlertReceivers");

&draw_notifications($notifications_enable, $from, $server, $administrator, 
	            $postmaster, $alertsender_enable, $alertreceivers_enable);
}
