#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_maintenance.pl';

sub do_live
{
	my $live_updating = shift;
	my $main_location = &BDReg_GetKeys ("BDUX/LiveDaemon/UpdateServers/Default/Host");
	my $interval_s	  = &BDReg_GetKeys ("BDUX/LiveDaemon/CheckSecs");
	my $interval_h = $interval_s/3600;
	my $proxyon = &BDReg_GetKeys("BDUX/Proxy/Enabled");
	if ( $proxyon ne "true" )
	{
		$proxyon = "";
	}
	else
	{
		$proxyon = "checked";
	}

	my $proxy_setts   = &BDReg_GetKeys ("BDUX/Proxy/Host");	
	($proxy_addr, $proxy_port) = split(/:/,$proxy_setts);
	my $proxy_user = &BDReg_GetKeys ("BDUX/Proxy/User");
	my $proxy_domain = &BDReg_GetKeys ("BDUX/Proxy/Userdomain");
	my $proxy_pass = &BDReg_GetKeys ("BDUX/Proxy/Password");

	my $push_update = &verify_check("BDUX/MailDaemon/PushUpdate");

	my $tmp_update_locations = &BDReg_GetKeys ("BDUX/LiveDaemon/UpdateLocations/");
	my @update_locations = split(/\n/,$tmp_update_locations);
	my @insecure_update;
	for $i ( 0 .. $#update_locations )
	{
	$insecure_update[$i] = &verify_check("BDUX/LiveDaemon/UpdateLocations/$update_locations[$i]/AllowInsecureUpdate");
	}

	&draw_maintenance_live($main_location, $interval_h, $proxyon, $proxy_user, $proxy_domain, $proxy_pass,
			       $proxy_addr, $proxy_port, $push_update, \@update_locations, \@insecure_update, $live_updating);
}

sub do_signatures
{
	my $last_check =  &BDReg_GetKeys("BDUX/LiveDaemon/LastCheck");
	my $last_update = &BDReg_GetKeys("BDUX/LiveDaemon/LastUpdate");
	my $signatures_no =  &BDReg_GetKeys("BDUX/ScanDaemon/SigCount");
	$signatures_no =~ s/ERR_KEY_DOES_NOT_EXIST//;
	&draw_maintenance_signatures($last_check, $last_update, $signatures_no);
}
