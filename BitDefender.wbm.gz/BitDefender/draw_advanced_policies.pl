#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

sub draw_group_settings_header
{
$group = shift;

print <<EOF;
<table BORDER=0 cellpadding="0" cellspacing="0" width="100%">
    <tr>
EOF
}

sub draw_group_settings_footer
{
print <<EOF;
EOF
}

sub draw_adv_group_settings_antivirus
{

my ( $group_url, $virus_actions, $virus_actions_switch, $riskware_actions, $riskware_actions_switch,
      $suspected_actions, $suspected_actions_switch, $av_email_disclaimer_check, $av_scanning_enable_check, 
      $sameactions_enable_check, $av_email_header_check, $av_pipe_program, $av_pipe_arguments) = @_;

my $browse_pipe_program = &bd_file_chooser_button("av_pipe_program", 0, 0);
print <<EOF;	
    <td>
	<form action="parse_advanced_policies.cgi?group=$group_url&action=antivirus_apply#av" method="POST">
	<a name=av></a>
		<!--legend>$text{'group_advanced_antivirus'}</legend-->
    		    <input class="checkbox" type="checkbox" name="scan_enable" id="scan_enable" value="Y" $av_scanning_enable_check />
	    	    <label class="checkbox" for="scan_enable" >$text{'group_av_enable'}</label>
		    <input type="hidden" name="initial_scan_enable" value="$av_scanning_enable_check" />
		<br />
            	    <input class="checkbox" type="checkbox" name="sameactions_enable" id="sameactions_enable" value="Y" $sameactions_enable_check />
	            <label class="checkbox" for="sameactions_enable" >$text{'group_av_sameactions'}</label>
    	            <input type="hidden" name="initial_sameactions_enable" value="$sameactions_enable_check" />
                <br />
		<table>
		    <tr>
EOF
my $url="parse_advanced_policies.cgi?group=".$group_url."&";
if ( $sameactions_enable_check eq "checked" )
	{
		&draw_settings_actions($url,"virus", $virus_actions, $virus_actions_switch);
		&draw_settings_actions_disabled("suspected", $virus_actions, $virus_actions_switch);
		&draw_settings_actions_disabled("riskware", $virus_actions, $virus_actions_switch);
	}
else
	{
		&draw_settings_actions($url,"virus", $virus_actions, $virus_actions_switch);
		&draw_settings_actions($url,"suspected",$riskware_actions, $riskware_actions_switch);
		&draw_settings_actions($url,"riskware",$suspected_actions, $suspected_actions_switch);
	}

print <<EOF;
		</tr>
	    </table>
	<fieldset class="fieldset_1column" style="margin-top:10px;">
                <table>
                <tr><td>$text{'group_av_pipe_program'}</td>
                <td><input class="input_edit" type="text" name="av_pipe_program" size="25" value="$av_pipe_program" />&nbsp;
                $browse_pipe_program
		<input type="hidden" name="initial_av_pipe_program" value="$av_pipe_program" /></td></tr>
                <tr><td>$text{'group_av_pipe_arguments'}</td>
                <td><input class="input_edit" type="text" name="av_pipe_arguments" value="$av_pipe_arguments" />
                <input type="hidden" name="initial_av_pipe_arguments" value="$av_pipe_arguments" /></td></tr>
		</table>
		<br>
		<input class="checkbox" type="checkbox" name="av_email_header" 	id="av_email_header" value="Y" $av_email_header_check />
                <label class="checkbox" for="av_email_header" >$text{'group_add_header'}</label>
		<input type="hidden" name="initial_av_email_header" value="$av_email_header_check" /><br>

		<input class="checkbox" type="checkbox" name="disclaimer" id="disclaimer" value="Y" $av_email_disclaimer_check />
		<label class="checkbox" for="disclaimer" >$text{'group_add_disclaimers'}</label>
		<input type="hidden" name="initial_disclaimer" value="$av_email_disclaimer_check" /><br>
	</fieldset>
	</td>
	</tr>
	</table>
EOF

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td>
				    <input class="button" type="submit" value="$text{'apply_button'}" />
				</td>
				<td>&nbsp;</td>
				</form>
		                <form action="parse_policies.cgi?group=$group_url" method="POST">
				<td>
		                    <input class="button" type="submit" value="$text{'back_button'}" /> 
				</td>
		                </form>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

}

sub draw_adv_group_settings_antispam
{

my $group_url = shift;
my $checkbox_values = shift;
my $tmp_rbl_servers=shift;
my $tmp_rbl_servers_trust=shift;
my $tmp_rbl_dns = shift;
my @rbl_servers = @$tmp_rbl_servers;
my @rbl_servers_trust = @$tmp_rbl_servers_trust;
my @rbl_dns = @$tmp_rbl_dns;
my ($as_enable_check, $blacklist_enable_check, $urlfilter_enable_check, $imagefilter_enable_check,
 $bayesfilter_enable_check, $heurfilter_enable_check, $multifilter_enable_check, $pbayesfilter_enable_check,
 $rblfilter_enable_check, $signfilter_enable_check, $modifysubject_enable_check, $mailheader_enable_check, 
 $multi_asian_check, $multi_cyrillic_check, $rblfilter_cache_enable_check) = @{$checkbox_values};
my ( $rbl_timeout, $as_threshold, $subject_template, $spamheader_template, 
 $hamheader_template, $as_pipe_program, $as_pipe_arguments, $all_as_actions, $as_actions_switch,$whitelist, $blacklist) = @_;

my $user_disabled = "disabled";
if ( $group_url eq "Default" )
	{
		$user_disabled = "";
	}

my $browse_subject = &bd_file_chooser_button("subject_t", 0, 0);
my $browse_spamheader = &bd_file_chooser_button("spamheader_t", 0, 0);
my $browse_hamheader = &bd_file_chooser_button("hamheader_t", 0, 0);
my $browse_pipe_program = &bd_file_chooser_button("as_pipe_program", 0, 0);

print <<EOF;
<td>
        <form action="parse_advanced_policies.cgi?group=$group_url&action=antispam_apply#as" method="POST">
	<a name=av></a>
		<fieldset class="fieldset_1column">
                <legend>$text{'group_advanced_antispam'}</legend>
                <input class="checkbox" type="checkbox" name="antispam" id="antispam" value="Y" $as_enable_check />
                <label class="checkbox" for="antispam" >$text{'group_as_enable'}</label>
		<input type="hidden" name="initial_antispam" value="$as_enable_check" />
		<br />
		<table border=0>
		    <tr>
			<td valign="top">
				<table>
				    <tr>
EOF
my $url="parse_advanced_policies.cgi?group=".$group_url."&";
&draw_settings_actions($url,"antispam", $all_as_actions, $as_actions_switch);
print <<EOF;
				    </tr>
    				</table>
			<td>
			<td valign="top" width="60%">
			    <input type="hidden" name="initial_as_pipe_arguments" value="$as_pipe_arguments" />
			    <input type="hidden" name="initial_as_pipe_program" value="$as_pipe_program" />	                
				<table width="100%" border=0>
				    <tr>
				<td colspan=2><b>$text{'group_as_pipe_program'}</b></td>
			    </tr>
	            	    <tr>
				<td>$text{'group_as_pipe_program'}</td>	
	            		<td><input class="input_edit" type="text" name="as_pipe_program" size="25" value="$as_pipe_program" /> $browse_pipe_program</td>

			    </tr>
			    <tr>
	            		<td>$text{'group_as_pipe_arguments'}</td>
	            		<td><input class="input_edit" type="text" name="as_pipe_arguments" value="$as_pipe_arguments" /></td>
			    </tr>
			    <tr>
				<td><label class="checkbox" for="modifysubject" >$text{'group_as_modify_subject'}</label></td>
				<td><input class="checkbox" type="checkbox" name="modifysubject" id="modifysubject" value="Y" $modifysubject_enable_check />	<input type="hidden" name="initial_modifysubject" value="$modifysubject_enable_check" /></td>
			    </tr>
				<td><label class="checkbox" for="mailheader" >$text{'group_as_add_header'}</label></td>
				<td><input class="checkbox" type="checkbox" name="mailheader" id="mailheader" value="Y" $mailheader_enable_check />  <input type="hidden" name="initial_mailheader" value="$mailheader_enable_check" /></td>
			    </tr>
			</table>

			</td>
		    </tr>
		</table>
		</fieldset>
		<br/>
                <fieldset class="fieldset_1column">
		<legend>$text{'group_as_filters'}</legend>
		    <table border=0>
			<tr>
			    <td width="50%" valign="top">
                	<input class="checkbox" type="checkbox" name="multifilter" 
			id="multifilter" value="Y" $multifilter_enable_check />
                	<label class="checkbox" for="multifilter" >$text{'group_as_multifilter'}</label>
			<input type="hidden" name="initial_multifilter" value="$multifilter_enable_check" /><br />

			<input class="checkbox" type="checkbox" name="multiasian" 
			id="multiasian" value="Y" $multi_asian_check style="margin-left: 2em;" $user_disabled />
                	<label class="checkbox" for="multiasian" >$text{'group_as_multiasian'}</label>
			<input type="hidden" name="initial_multiasian" value="$multi_asian_check" /><br />

			<input class="checkbox" type="checkbox" name="multicyrillic" 
			id="multicyrillic" value="Y" $multi_cyrillic_check style="margin-left: 2em;" $user_disabled/>
                	<label class="checkbox" for="multicyrillic" >$text{'group_as_multicyrillic'}</label>
			<input type="hidden" name="initial_multicyrillic" value="$multi_cyrillic_check" /><br />

			<input class="checkbox" type="checkbox" name="blacklist" 
			id="blacklist" value="Y" $blacklist_enable_check />
		        <label class="checkbox" for="blacklist" >$text{'group_as_blacklist'}</label>
			<input type="hidden" name="initial_blacklist" value="$blacklist_enable_check" /><br />
			
			
                	<input class="checkbox" type="checkbox" name="rblfilter" 
			id="rblfilter" value="Y" $rblfilter_enable_check  onChange="toggleRBLCache(this.checked);" />
                	<label class="checkbox" for="rblfilter" >$text{'group_as_rblfilter'}</label>
			<input type="hidden" name="initial_rblfilter" value="$rblfilter_enable_check" /><br />
			
                	<input class="checkbox" type="checkbox" name="rblfilter_cache" 
			id="rblfilter_cache" value="Y" $rblfilter_cache_enable_check />
                	<label class="checkbox" for="rblfilter_cache" >$text{'group_as_rblfilter_cache'}</label>
			<input type="hidden" name="initial_rblfilter_cache" value="$rblfilter_cache_enable_check" />
			<input class="button" type="submit" id="rbl_cache" name="rbl_cache" value="$text{'group_as_rblfilter_cache_clear_button'}" $user_disabled />
			
			<br />
			<script language="Javascript">
			    toggleRBLCache(document.getElementById("rblfilter").checked);
			</script>
			    </td>
			    <td>&nbsp;</td>
			    <td width="50%" valign="top">
                	<input class="checkbox" type="checkbox" name="imagefilter" 
			id="imagefilter" value="Y" $imagefilter_enable_check />
                	<label class="checkbox" for="imagefilter" >$text{'group_as_imagefilter'}</label>
			<input type="hidden" name="initial_imagefilter" value="$imagefilter_enable_check" /><br />
			    
                	<input class="checkbox" type="checkbox" name="urlfilter" 
			id="urlfilter" value="Y" $urlfilter_enable_check />
                	<label class="checkbox" for="urlfilter" >$text{'group_as_urlfilter'}</label>
			<input type="hidden" name="initial_urlfilter" value="$urlfilter_enable_check" /><br />
                	<input class="checkbox" type="checkbox" name="bayesfilter" 
			id="bayesfilter" value="Y" $bayesfilter_enable_check />
                	<label class="checkbox" for="bayesfilter" >$text{'group_as_bayesfilter'}</label>
			<input type="hidden" name="initial_bayesfilter" value="$bayesfilter_enable_check" /><br />
                	<input class="checkbox" type="checkbox" name="pbayesfilter" 
			id="pbayesfilter" value="Y" $pbayesfilter_enable_check />
                	<label class="checkbox" for="pbayesfilter" >$text{'group_as_pbayesfilter'}</label>
			<input type="hidden" name="initial_pbayesfilter" value="$pbayesfilter_enable_check" /><br />
                	<input class="checkbox" type="checkbox" name="heurfilter" 
			id="heurfilter" value="Y" $heurfilter_enable_check />
                	<label class="checkbox" for="heurfilter" >$text{'group_as_heurfilter'}</label>
			<input type="hidden" name="initial_heurfilter" value="$heurfilter_enable_check" /><br />
			<input class="checkbox" type="checkbox" name="signfilter" 
			id="signfilter" value="Y" $signfilter_enable_check />
                	<label class="checkbox" for="signfilter" >$text{'group_as_signfilter'}</label>
			<input type="hidden" name="initial_signfilter" value="$signfilter_enable_check" />
			    </td>
			</tr>
		</table>
		</fieldset>
EOF

if ( $blacklist_enable_check eq "checked" )
{
print <<EOF;
                <fieldset class="fieldset_1column">
		<legend>$text{'group_as_wblist'}</legend>
		    <table>
			<tr>
			    <td width="50%">$text{'group_as_wlist_users'}</td>
			    <td width="50%">$text{'group_as_blist_users'}</td>
			</tr>
			<tr>
			    <td width="50%"><textarea name=whitelist_users style="width:320px; height:120px;" class="textarea">$whitelist</textarea></td>
			    <td width="50%"><textarea name=blacklist_users style="width:320px; height:120px;" class="textarea">$blacklist</textarea></td>
			</tr>
		    </table>			    
		</fieldset>
EOF
}
		
print <<EOF;
		<fieldset class="fieldset_1column">
		<legend>$text{'group_as_rblfilter_settings'}</legend>
		<a name=rbl_settings></a>
                <table>
            	    <tr>
			<td>$text{'group_as_rbltimeout'}</td>
	            	    <td><input class="input_edit" type="text" size="4" name="rbl_timeout" value="$rbl_timeout" $user_disabled />
    		            <input type="hidden" name="initial_rbl_timeout" value="$rbl_timeout" /></td>
	    	    </tr>
		</table>
		<table border=0>
		    <tr>
			<td valign=top width=50%>
				<font><b>$text{'group_as_rbldns'}</b></font>
				<table>
				    <tr>
					<td><input class='input_edit' type='text' name='new_rbldns' $user_disabled /></td>
					<td><input class="button" type="submit" name="rbl_dns" value="$text{'add_button'}" $user_disabled /></td>
				    </tr>
		    
		    
EOF
				    for $i ( 0 .. $#rbl_dns ) 
			            {
			            print "<tr><td><input class='input_edit' type='edit' name='edit_rbldns' value='$rbl_dns[$i]' $user_disabled /></td>";
			            print "<td><input class='checkbox' type='checkbox' name='check_rbldns' value='$rbl_dns[$i]' $user_disabled />";
			            print "<input type='hidden' name='initial_rbldns' value='$rbl_dns[$i]'></td></tr>";
			            }
	

print <<EOF;
				</table>
				<input class="button" type="submit" name="rbl_dns" value="$text{'remove_button'}" $user_disabled />
			</td>
			<td>&nbsp;</td>
			<td valign=top width=50%>
				<font><b>$text{'group_as_rblservers'}</b></font>
				<table border=0>
				    <tr>
					<td><input class='input_edit' type='text' size='20' name='new_rbl_server' $user_disabled style="float:none"; ></td>
					<td><input class='input_edit' type='text' size='3' name='new_rbl_server_trust' $user_disabled style="float:none";></td>
					<td><input class="button" type="submit" name="rbl_servers" value="$text{'add_button'}" $user_disabled style="float:none"; /></td>
				    </tr>

EOF
for $i ( 0 .. $#rbl_servers ) 
        {
print <<EOF;
		<tr>
		    <td><input class='input_edit' type='text' size='20' name='edit_rbl_servers' value='$rbl_servers[$i]' $user_disabled /></td>
		    <td><input class='input_edit' type='text' size='3' name='edit_rbl_servers_trust' value='$rbl_servers_trust[$i]' $user_disabled /></td>
		    <td>
			<input class='checkbox' type='checkbox' name='check_rbl_servers' value='$rbl_servers[$i]' $user_disabled />
			<input type='hidden' name='initial_rbl_servers_trust' value='$rbl_servers_trust[$i]'>
			<input type='hidden' name='initial_rbl_servers' value='$rbl_servers[$i]'>
		    </td>
		</tr>
EOF
        }

print <<EOF;
				</table>
		
				<input class="button" type="submit" name="rbl_servers" value="$text{'remove_button'}" $user_disabled />
	    		    </td>
			</tr>
		    </table>
		</fieldset>

		<fieldset class="fieldset_1column">
		<legend>$text{'group_as_threshold'}</legend>
		    <table border=0>
	    		<tr>
			    <td>$text{'group_as_threshold'}</td>
			    <td>
				<input class="input_edit" type="text" size="4" name="threshold" value="$as_threshold" />
				<input type="hidden" name="initial_threshold" value="$as_threshold" />
			    </td>
			</tr>
		    </table>
		</fieldset>	

		<fieldset class="fieldset_1column">
			<legend>$text{'group_as_templates'}</legend>
			<table border=0>
			<tr><td>$text{'group_as_subject'}</td>
			<td><input class="input_edit" type="text" style="width:300px;"  name="subject_t" size="25" value="$subject_template" />
			&nbsp; $browse_subject
			<input type="hidden" name="initial_subject_t" value="$subject_template" /></td>

 			<tr><td>$text{'group_as_spamheader'}</td>
			<td><input class="input_edit" type="text" style="width:300px;"  name="spamheader_t" size="25" value="$spamheader_template" />
			&nbsp; $browse_spamheader
			<input type="hidden" name="initial_spamheader_t" value="$spamheader_template" /></td></tr>
			
			<tr><td>$text{'group_as_hamheader'}</td>
			<td><input class="input_edit" type="text" style="width:300px;" name="hamheader_t" size="25" value="$hamheader_template" />
			&nbsp; $browse_hamheader
			<input type="hidden" name="initial_hamheader_t" value="$hamheader_template" /></td></tr>
			</table>
		</fieldset>
	    </td>
	</tr>
	</table>
EOF

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td>
		    		<input class="button" type="submit" value="$text{'apply_button'}" />
				</td>
				<td>&nbsp;</td>
				</form>
		                <form action="parse_policies.cgi?group=$group_url" method="POST">
				<td>
		                    <input class="button" type="submit" value="$text{'back_button'}" /> 
				</td>
		                </form>
			    </tr>
	    		</table>
		    </td>		
		</tr>
	
EOF

}
sub draw_group_settings_mf
{
my ($group_url, $mf_mail_forward, $mf_ip, $mf_helo, $mf_from, $mf_rcpt, $mf_forwardafter_check, 
    $mf_forwardbefore_check, $mf_forward) = @_;
print <<EOF;
<form action="parse_advanced_policies.cgi?group=$group_url&action=mf_apply#mf" method="POST">
<a name=mf></a>
<fieldset>
     <legend>$text{'group_mf'}</legend>
	<input class="checkbox" type="checkbox" name="mail_forward" id="mail_forward" value="Y" $mf_mail_forward />
        <label class="checkbox" for="mail_forward" >$text{'group_mf_enable'}</label>
	<input type="hidden" name="initial_mail_forward" value="$mf_mail_forward" />
	<br />
	<fieldset>
		<legend>$text{'group_mf_when'}</legend>
		<input class="radio" type="radio" name="mf_when"
		id="mf_after" value="AfterScan" $mf_forwardafter_check />
        	<label class="radio" for="mf_after" >$text{'group_mf_afterscan'}</label>
		<input type="hidden" name="initial_mf_when" value="$mf_forward" />
		<br />
        	<input class="radio" type="radio" name="mf_when"
		id="mf_before" value="BeforeScan" $mf_forwardbefore_check />
        	<label class="radio" for="mf_before" >$text{'group_mf_beforescan'}</label>
        	<br />
	</fieldset>
	<fieldset>
		<legend>$text{'group_mf_where'}</legend>
			<dl>
                        <dt>$text{'group_mf_ip'}</dt>
			<dd><input class="text" type="text" name="mailfw_ip" value="$mf_ip" />
			<input type="hidden" name="initial_mailfw_ip" value="$mf_ip" /></dd>
                        
			<dt>$text{'group_mf_helo'}</dt>
			<dd><input class="text" type="text" name="mailfw_helo" value="$mf_helo" />
			<input type="hidden" name="initial_mailfw_helo" value="$mf_helo" /></dd>
			
                        <dt>$text{'group_mf_from'}</dt>
			<dd><input class="text" type="text" name="mailfw_from" value="$mf_from" />
			<input type="hidden" name="initial_mailfw_from" value="$mf_from" /></dd>
			
                        <dt>$text{'group_mf_dest'}</dt>
			<dd><input class="text" type="text" name="mailfw_rcpt" value="$mf_rcpt" />
			<input type="hidden" name="initial_mailfw_rcpt" value="$mf_rcpt" /></dd>
			</dl>
		<legend>
	</fieldset>
<input class="submit" type="submit" value="$text{'apply_button'}" />
</fieldset>
</form>
EOF
}
sub draw_group_settings_users
{
my ( $group_url, $senders, $recipients ) = @_;
$senders = &html_escape($senders);
$recipients = &html_escape($recipients);
print <<EOF;
<form action="parse_policies.cgi?group=$group_url&action=users_apply#users" method="POST">
<fieldset>
     <legend>$text{'group_users'}</legend>
<table>
<tr>
<td><label class="text">$text{'group_senders'}</label></td>
<td><label class="text">$text{'group_recipients'}</label></td>
</tr>
<tr>
<td>
<textarea name="senders" cols=20 rows=6>$senders</textarea>
<input type="hidden" name="initial_senders" value="$senders" />
</td>
<td>
<textarea name="recipients" cols=20 rows=6 >$recipients</textarea>
<input type="hidden" name="initial_recipients" value="$recipients" /></td>
</tr>
</table>
<input class="submit" type="submit" value="$text{'apply_button'}" />
</fieldset>
</form>
EOF
}
sub draw_groups
{
my ( $groups, $groups_check ) = @_;
print <<EOF;             
                                <div id="content">
                                <h2>$text{'groups'}</h2>
				<form action="parse_groups.cgi?action=parse_groups" method="POST">
				<fieldset>
<input class="submit" type="submit" name=up_button value="$text{'up_button'}" />
<input class="submit" type="submit" name=down_button value="$text{'down_button'}" />

EOF
for $i ( 0 .. $#{$groups} )
	{
	my $groups_url = &urlize(${$groups}[$i][0]);
        print "<input class='checkbox' type='checkbox' name='check_group' value='$groups_url' ${$groups_check}[$i] />\n";
        print "<input class='text' type='text' name='groupname' value='${$groups}[$i][0]' />\n";
	print "<a href=parse_policies.cgi?group=$groups_url>$text{'groups_edit'}</a>\n";
	print "<input type='hidden' name='priority' value='${$groups}[$i][1]'>\n";
        print "<input type='hidden' name='initial_groupname' value='$groups_url'><br>\n";

	}
print <<EOF;
<br />
<input class="submit" type="submit" name=remove_button value="$text{'remove_button'}" />
<input class="submit" type="submit" name=rename_button value="$text{'rename_button'}" />
</form>
<br />
<form action="parse_groups.cgi?action=add_group" method="POST">
<input class="text" type="text" name=newgroup value="" />
<input class="submit" type="submit" value="$text{'add_button'}" />
				</fieldset>
				</form>
                                </div> <!-- id="content" -->
EOF
}
