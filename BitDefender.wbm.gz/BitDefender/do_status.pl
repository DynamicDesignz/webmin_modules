#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_status.pl';

$bitdefender_pid_path = "/var/run/BitDefender/";
@bd_corecomponents = ( "bdregd", "bdlogd", "bdlived", "bdmond", "bdscand", "bdmaild", "bdfiled", "bdemclientd", "bdemagentd" );
%bd_agents = ("bdcgated"  => "/BDUX/Agents/CommuniGate/CommuniGateAgentEnabled",
	      "bdcourier" => "/BDUX/Agents/Courier/CourierAgentEnabled",
	      "bdmilterd" => "/BDUX/Agents/Milter/MilterAgentEnabled",
	      "bdqmail"   => "/BDUX/Agents/Qmail/QmailAgentEnabled",
	      "bdsmtpd"   => "/BDUX/Agents/SmtpProxy/SMTPAgentEnabled",
	      );
sub check_if_running()
{
# Checks if a process passed through the first
# argument is running or not and returns accordingly

	$cmd = `ps ax | grep $_[0] |grep -v grep`;
	if ( $cmd eq "" )
	{
		return "stopped";
	}
	else
	{
		return "running";
	}
}

sub check_uptime()
{
# The first argument is the path to the binary's pid file
my $path = shift;

if ( -f $path )
	{
		# The pid file exists, we try to find out the uptime
		($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
			$atime,$mtime,$ctime,$blksize,$blocks)
	 		= stat($path);
		$interval = time() - $mtime;
		if ($interval > 0)
		{
			# The uptime is >0
			$days = 0;
			$hours = 0;
			$min = 0;
			$sec = 0;
			if ($interval > 86400)
			{
				$days = int($interval/86400);
				$interval = $interval%86400;
			}
			if ($interval > 3600)
			{
				$hours = int($interval/3600);
				$interval = $interval%3600;
			}
			if ($interval > 60)
			{
				$min = int($interval/60);
				$interval = $interval%60;
			}
			$sec = $interval;
			# Return the uptime
			return( $days, $hours, $min, $sec );
		}	
		else
		{
			# The uptime <0
			# Return the uptime as 0
			return( "0", "0", "0", "0" );
		}
	}	
	else
	{
		# We can't find the pid file
		# return the uptime as 0
		return( "0", "0", "0", "0" );
	}
}

sub version_info()
{
	# Find out the product versions from inf files
	# the only argument is the file path
	my $path=shift;
	my @version;
	open(FILE, $path);

	while(<FILE>) {
		my ($name, $number) = split(/=/, $_);
		chomp $number;
		push (@version, $number);
		}

	close(FILE);

	return $version[0].".".$version[1].".".$version[2];
}

sub do_services
{
# Checks which services are running and which are stopped. It creates:
# an array which contains the names of the stopped binaries - @notrunning
# and an array which contains the names of the running processes together
# with their uptime (if available) - @running.
#
# These arrays are passed to draw_services, which draws the final page.
my @notrunning;
my @running;

# We check the core components
foreach $binary (@bd_corecomponents)
{
	# Check if the binary exists
	if ( -x "$bitdefender_dir/bin/$binary" )
	{
		# Check if the process is running
		my $process_is = &check_if_running($binary);
		if ( $process_is eq "stopped" )
		{
			# The process is stopped, so we add it to @notrunning
			push(@notrunning, $binary);
		}
		else
		{
			# The process seems to be running, so we check for 
			# the uptime of the process
			my ( $d, $h, $m, $s) = &check_uptime("$bitdefender_pid_path$binary.pid");
			push(@running, [ $binary, $d, $h, $m, $s]);
			
		}
	}	
	# The binary doesn't exist here
}
# Closing foreach

# We have to check now for daemon agents
my @daemon_agents = ( "bdcgated", "bdmilterd", "bdsmtpd" );
foreach $binary (@daemon_agents)
{
	# Check if the binary exists
	if ( -x "$bitdefender_dir/bin/$binary" )
	{
		# Check if the process is running
		my $process_is = &check_if_running($binary);
		if ( $process_is eq "stopped" )
		{
			# The process is stopped, we check if the agent is enabled
			my $enable_verify = &verify_check($bd_agents{$binary});
			if ( $enable_verify eq "checked"  )
				{
				# the agent is enabled so we add it to the notrunning array
				push(@notrunning, $binary);
				}
		}
		else
		{
			# The process seems to be running, so we check for 
			# the uptime of the process
			my ( $d, $h, $m, $s) = &check_uptime("$bitdefender_pid_path$binary.pid");
			push(@running, [ $binary, $d, $h, $m, $s]);
			
		}
	}	
	# The binary doesn't exist here
}

# Draw the services page
&draw_services(\@running, \@notrunning);	
}

sub license_get_proprieties
{
	my ($License_Type, $License_Count, $License_RemainingDays, $License_KeyStatus) = @_;
	my $remaining_days;
	my $expiration_date = "";
	my $licensed_domains = "";
	my $licensed_users = "";
	my $license_status_string = "Invalid";
	my $license_key_button = "reset_button";

	if ($License_Type =~ /user/)
	{
		$licensed_users = $License_Count;
		$licensed_domains = "0";
	}
	elsif ($License_Type =~ /domain/)
	{
		$licensed_domains = $License_Count;
		$licensed_users = "0";
	}
	else
	{
		$licensed_domains = "0";
		$licensed_users = "0";
	}

	$remaining_days = $License_RemainingDays;

	$expiration_date = localtime (time() + $remaining_days*3600*24);
	$expiration_date =~ s/\d\d:\d\d:\d\d//;
	$expiration_date =~ s/  / /;

	if ( $License_KeyStatus  =~ "^valid" )
	{
	# The license is valid
		if ( $License_KeyStatus =~ "trial" )
		{
		#It's a valid evaluation version
		$license_status_string = "license_evaluation_valid";
		$license_key_button = "submit_button";
		$License_Key = "";
		}
		else
		{
                $license_status_string = "license_valid";
		}
	}
	elsif ( $License_KeyStatus  =~ "expired" )
	{
	# The license has expired
		if ( $License_KeyStatus =~ "trial" )
		{
		#It's a valid evaluation version
		$license_status_string = "license_evaluation_expired";
		$license_key_button = "submit_button";
		$License_Key = "";
		}
		else
		{
                $license_status_string = "license_expired";
		}
	}
	elsif ( $License_KeyStatus  =~ "checking" )
		{
		$license_status_string = "license_checking";
		$licensed_domains = "0";
		$licensed_users = "0";
		}
	else
		{
		$license_status_string = "license_invalid";
		$licensed_domains = "0";
		$licensed_users = "0";
		}
	return ($remaining_days, $expiration_date, $licensed_domains, $licensed_users, 
		$license_status_string, $license_key_button);
}

sub do_license
{
my $myaccount_output = shift;
my $mail_daemon = "no";
my $file_daemon = "no";
my ( $mail_license_key, $mail_remaining_days, $mail_expiration_date, $mail_licensed_domains,   
        $mail_licensed_users, $mail_license_status_string, $mail_license_key_button) =
	( "", "", "", "", "", "", "", "");
my ( $file_license_key, $file_remaining_days, $file_expiration_date, $file_licensed_domains, 
		$file_licensed_users, $file_license_status_string, $file_license_key_button) = 
	( "", "", "", "", "", "", "", "");


# Check if there is MailDaemon
if ( -e "$bitdefender_dir/var/mail.inf" )
{
	my $keys = "/BDUX/MailDaemon/License/Key\n/BDUX/MailDaemon/License/KeyStatus\n/BDUX/MailDaemon/License/RemainingDays\n/BDUX/MailDaemon/License/Type\n/BDUX/MailDaemon/License/Count";
	my $prefix = "/BDUX/MailDaemon/License";
	($output = &BDReg_GetKeys ("$keys")) =~ s|$prefix||g;
	$output =~ s|/|License_|g;
	$output =~ s|(.*)<>(.*)|\$$1 = "$2";|mg;
	my $License_Key = "";
	my $License_KeyStatus = "";
	my $License_RemainingDays = "";
	my $License_Type = "0";
	my $License_Count = "0";
	no strict "vars";
	eval "$output; return(1);";
	use strict "vars";
	
( $mail_remaining_days, $mail_expiration_date, $mail_licensed_domains, 
	$mail_licensed_users, $mail_license_status_string, $mail_license_key_button) = 
	&license_get_proprieties($License_Type, $License_Count, $License_RemainingDays, $License_KeyStatus);
	$mail_license_key = $License_Key;
	$mail_daemon="yes";
}

# Check if there is filedaemon
if ( -e "$bitdefender_dir/var/samba.inf" )
{
	my $keys = "/BDUX/FileDaemon/License/Key\n/BDUX/FileDaemon/License/KeyStatus\n/BDUX/FileDaemon/License/RemainingDays\n/BDUX/FileDaemon/License/Type\n/BDUX/FileDaemon/License/Count";
	my $prefix = "/BDUX/FileDaemon/License";
	($output = &BDReg_GetKeys ("$keys")) =~ s|$prefix||g;
	$output =~ s|/|License_|g;
	$output =~ s|(.*)<>(.*)|\$$1 = "$2";|mg;
	my $License_Key = "";
	my $License_KeyStatus = "";
	my $License_RemainingDays = "";
	my $License_Type = "0";
	my $License_Count = "0";
	no strict "vars";
	eval "$output; return(1);";
	use strict "vars";
	
( $file_remaining_days, $file_expiration_date, $file_licensed_domains, 
	$file_licensed_users, $file_license_status_string, $file_license_key_button) = 
	&license_get_proprieties($License_Type, $License_Count, $License_RemainingDays, $License_KeyStatus);
	$file_license_key = $License_Key;
	$file_daemon="yes";

}

#	&draw_license($mail_daemon, $file_daemon, $mail_license_status_string, $mail_remaining_days, $mail_expiration_date, 
#		$mail_licensed_domains, $mail_licensed_users, $mail_license_key, $mail_license_key_button,
#		$file_license_status_string, $file_remaining_days, $file_expiration_date,
#		$file_licensed_domains, $file_licensed_users, $file_license_key, $file_license_key_button);

# Added by Lucian Maxim (19.02.2008)
# MyAccount feature
# TODO: Get info from bdsafe
my $myaccount_registered 	= lc(&BDReg_GetKeys("/BDUX/MyAccount/Enable"));
my $myaccount_email 		= &BDReg_GetKeys("/BDUX/MyAccount/EMail");

my $myaccount_error = "";
if ( $myaccount_output =~ /Error/ ){
    $myaccount_error = $myaccount_output;
}

	&draw_license($mail_daemon, $file_daemon, $mail_license_status_string, $mail_remaining_days, $mail_expiration_date, 
		$mail_licensed_domains, $mail_licensed_users, $mail_license_key, $mail_license_key_button,
		$file_license_status_string, $file_remaining_days, $file_expiration_date,
		$file_licensed_domains, $file_licensed_users, $file_license_key, $file_license_key_button,$myaccount_registered, $myaccount_email, $myaccount_error);

}

sub do_about
{
	my @corecomponents_versions;
	my @agents_versions;
	my @product_info;
	my $bdregd_status = &check_if_running("bdregd");

	my $enable_verify = "";

	# Find out the components and their versions
	if (-e "$bitdefender_dir/var/mail.inf" )
		{
			my $mpe_version = &version_info("$bitdefender_dir/var/mail.inf");
			push ( @product_info, [ "mpe", $mpe_version ]);
		}

	if (-e "$bitdefender_dir/var/samba.inf" )
		{
			my $fpe_version = &version_info("$bitdefender_dir/var/samba.inf");
			push ( @product_info, [ "fpe", $fpe_version ]);
		}

	
	# Find out the versions for binaries
	foreach $binary (@bd_corecomponents)
	{
		if (-x "$bitdefender_dir/bin/$binary" )
			{
			($output = `$bitdefender_dir/bin/$binary --version`) =~ s/.* (.* .*)$/$1/;
			chomp $output;
			push(@corecomponents_versions, [ $binary, $output ]);
			}
	}

	foreach $binary (keys %bd_agents)
	{
		if (-x "$bitdefender_dir/bin/$binary" )
			{
			($output = `$bitdefender_dir/bin/$binary --version`) =~ s/.* (.* .*)$/$1/;
			chomp $output;
			# We check if the agent is enabled - 
			# if it's enabled, $enable_verify will contain "checked"
			# otherwise it will be empty
			if ($bdregd_status eq "running")
				{
	                        $enable_verify = &verify_check($bd_agents{$binary});
					if ( $enable_verify eq "" )
					{
						$enable_verify = "disabled";
					}
				}
			push(@agents_versions, [ $binary, $output, $enable_verify ]);
			}
	}

	
	&draw_about(\@product_info, \@corecomponents_versions, \@agents_versions);
}

