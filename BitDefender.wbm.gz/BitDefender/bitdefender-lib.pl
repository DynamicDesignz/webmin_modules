#!/usr/bin/perl
do '../web-lib.pl';
&init_config();

$bitdefender_dir=$config{'bitdefender_dir'};
$groups_root = "BDUX/GroupManagement/Groups/";
$patch_dir = "$bitdefender_dir/var/patches";
$executable_files_extensions = "exe;com;dll;ocx;scr;bin;dat;386;vxd;sys;wdm;cla;class;ovl;ole;hlp;doc;dot;xls;ppt;wbk;wiz;pot;ppa;xla;xlt;vbs;vbe;mdb;rtf;htm;hta;html;xml;xtp;php;asp;js;shs;chm;lnk;pif;prc;url;smm;pfd;msi;ini;csc;cmd;bas;";

use File::Temp qw(tempfile unlink0);

sub BDReg_GetKeys {

# function to get some keys from registry
# Arguments:
#	* a list of keys to be queried
# Return Value:
#	* the return value as given by bdsetup --getkeys or "" if some (non-fatal)
#         error occurs

	return "" if (! defined $_[0] || $_[0] eq "");
	
	my $output;
	
	# check if we have only one key
	if ($_[0] =~ tr/\n// == 0) {
		$output = `$bitdefender_dir/bin/bdsafe registry getkey "$_[0]" 2>/dev/null`;
		chomp $output;
	} else {
		$output = `echo "$_[0]" | $bitdefender_dir/bin/bdsafe registry getkeys 2>/dev/null`;
	}
	if ($? >> 8 == 1) {
		#"BitDefender Registry is not running. Please start at least the bdregd service\n";
		#"and then try again.\n";
		$output = ERR_BDREGD_NOT_RUNNING;
	} elsif ($? >> 8 == 2) {
		#"The current user is not allowed to connect to the bdregd service.\n";
		#"Please run the same command as a privileged user or add the current user\n";
		#"to the /BDUX/Registry/LocalUsers/ subtree.\n";
		$output = ERR_BDREGD_NOT_ALLOWED;
	} elsif ($? >> 8 == 3) {
		# The key doesn't exist
		$output = ERR_KEY_DOES_NOT_EXIST;
	}
	
	return $output;

}
sub BDReg_EncodeKey {
	$key = shift;
	$key =~ s/\'/\\\'/g;
	if ($key eq "") {return "";}
	$output = `$bitdefender_dir/bin/bdsafe registry encode \'$key\' `;
	return $output;
	}


sub BDReg_SetKey {
	$key = shift;
	$value = shift;
	$value=~ s/\'/\\\'/g;
	$key =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe registry setkey \'$key\' \'$value\' 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}

sub BDReg_DelKey {
	$key = shift;
	$key =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe registry delkey \'$key\' 2>/dev/null |";
        open(bdsetup,$command);
        close(bdsetup);
	}

sub BDReg_AddGroup {
	$newgroup = shift;
	$newgroup =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe group append \'$newgroup\' 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}

sub BDReg_RemoveGroup {
	$oldgroup = shift;
	$oldgroup =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe group purge \'$oldgroup\' 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}
sub BDReg_RenameGroup {
	my ($oldname, $newname) = @_;
	$oldname =~ s/\'/\\\'/g;
	$newname =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe group rename \'$oldname\' \'$newname\' 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}
sub BDReg_SetPGroup {
	my ($group, $priority) = @_;
	$group =~ s/\'/\\\'/g;
	$priority =~ s/\'/\\\'/g;
	my $command = "$bitdefender_dir/bin/bdsafe group priority \'$group\' \'$priority\' 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}
sub bdsafe_run {
	$arguments = shift;
	my $command = "$bitdefender_dir/bin/bdsafe $arguments  2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}
sub bd_reloadsettings {
	my $daemon = shift;
	my $command = "$bitdefender_dir/bin/bdsafe reloadsettings $daemon 2>/dev/null |";
	open(bdsetup, $command);
	close(bdsetup);
	}
sub bdsafe_run_output {
	my $output = `$bitdefender_dir/bin/bdsafe $_[0] 2>&1`;
	return $output
	}

# Policies subroutines
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
sub group_getkey
{
# Verifies if the key of o given group is set
# if is set returns it, otherwise it returns
# the default group key
my ($group, $key) = @_;
my $output = &BDReg_GetKeys ($groups_root.$group.$key);
if ( $output eq "ERR_KEY_DOES_NOT_EXIST" )
        {
                $output = &BDReg_GetKeys ($groups_root."Default".$key);
        }
return $output;
}

sub verify_group_check
{
# Verifies if a group option is checked (eq to "Y")
# and returns "checked" or "". If the group
# setting is not present it takes the default one
my ($group, $key) = @_;
if ( &group_getkey ($group, $key) eq "Y" )
        {my $output = "checked" ;}
        else
        {my $output = "";}
}

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
sub validate_domain
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $domain = $_[0];
	my $retcode = 0;
	$domain =~ s/([ \t\n\r]+)$//;
	$domain =~ s/^([ \t\n\r]+)//;

	if ($domain =~ /^([a-zA-Z0-9-_]+)((\.[a-zA-Z0-9-_]+)*(\.[a-zA-Z0-9]{2,6}){1}){0,1}$/ && (not $domain=~ /^[0-9\.]*$/))
		{$retcode=1;}
	return $retcode;
}

sub validate_email
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $email = $_[0];
	my $name = "";
	my $domain = "";
	my $retcode = 0;
	$email =~ s/([ \t\n\r]+)$//;
	$email =~ s/^([ \t\n\r]+)//;

	($name,$domain,$empty_field)=split(/@/,$_[0]);
	
	if ($name ne "" && $domain ne "" && $empty_field eq "")
	{
		if ( $name =~ /^([a-zA-Z0-9_\-\.]+)$/ && &validate_domain($domain))
		{
			$retcode = 1;
		}
	}
	
	return $retcode;
}

sub validate_ip
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $ip = $_[0];
	my $retcode = 0;
	$ip =~ s/([ \t\n\r]+)$//;
	$ip =~ s/^([ \t\n\r]+)//;
	
	if ($ip =~ /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/)
	{
		($ip1,$ip2,$ip3,$ip4) = split (/\./,$ip);
		if ( $ip1>=0 && $ip1<256 &&
			$ip2>=0 && $ip2<256 &&
			$ip3>=0 && $ip3<256 &&
			$ip4>=0 && $ip4<256
		)
		{
			$retcode=1;
		}
	}
	return $retcode;
}

sub validate_number
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $number= $_[0];
	my $retcode = 0;
	$number =~ s/([ \t\n\r]+)$//;
	$number =~ s/^([ \t\n\r]+)//;
	
	if ($number =~ /^[0-9]+$/)
	{
		$retcode=1;
	}

	return $retcode;
}

sub validate_float_number
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $number= $_[0];
	my $retcode = 0;
	$number =~ s/([ \t\n\r]+)$//;
	$number =~ s/^([ \t\n\r]+)//;
	
	if ($number =~ /^[0-9]*\.?[0-9]+$/)
	{
		$retcode=1;
	}

	return $retcode;
}

sub validate_path
{
	my $path = $_[0];
	my $retcode = 0;
	if ( -e $path )
	{
		$retcode = 1;
	}
	return $retcode;
}

sub validate_url
{
	# returns 1 if ok
	# returns 0 if condition failed 
	my $url = $_[0];
	my $retcode = 0;
	$url =~ s/([ \t\n\r]+)$//;
	$url =~ s/^([ \t\n\r]+)//;
	if ($url =~ /^https?:\/\/([a-zA-Z0-9-_]+)((\.[a-zA-Z0-9-_]+)*(\.[a-zA-Z0-9]{2,6}){1}){0,1}(\/[a-zA-Z0-9-_]+\/?)*$/)
		{$retcode=1;}
	return $retcode;
}

sub verify_check
{
# Verifies if an option is checked (eq to "Y")
# and returns "checked" or "".
my $key = shift;
my $value = &BDReg_GetKeys($key);
if ( ($value eq "Y") || ($value eq "y") || ($value eq "yes") )
	{my $output = "checked" ;}
	else
	{my $output = "";}
}

sub verify_check_with_value
{
# Verifies if an option is checked
# and returns "checked" or "".
my ( $key, $checked_value) = @_;
if ( &BDReg_GetKeys($key) eq $checked_value )
	{my $output = "checked" ;}
	else
	{my $output = "";}
}

sub Get_Sorted_Patches {

# parse the config files and populate the
# patches data structures @pi and @pa
	my @pa;
	my @pi;

	my $action = shift;
	defined $action or $action = "available";
	
	# the list of meta files
	my @meta_list_installed,@meta_list_available;

	@meta_list_installed = glob "$patch_dir/installed/*meta";
	@meta_list_available = glob "$patch_dir/*meta";
	
	our ($type, $patch_number, $release_date, $summary, $description);
	
	# parse each installed patch
	foreach my $patch (@meta_list_installed) {
	
		require $patch;
	
		my %patch = (
			meta => $patch,
			type => $type,
			number => $patch_number,
			release => $release_date,
			summary => $summary,
			description => $description 
		);
		push @pi, \%patch;

	}

	# parse each available patch
	foreach my $patch (@meta_list_available) {
	
		require $patch;
	
		my %patch = (
			meta => $patch,
			type => $type,
			number => $patch_number,
			release => $release_date,
			summary => $summary,
			description => $description 
		);

		# check if the available pacthes were already installed or not
			my $found = "no";
			foreach my $p ( @pi ) {
				if ( $p->{number} == $patch_number ) {
					$found = "yes";
					last;
				}
			}
			push @pa, \%patch if ($found eq "no");
		}
	# sort the patches arrays
	@pa = sort { $a->{number} <=> $b->{number} } @pa;
	@pi = sort { $a->{number} <=> $b->{number} } @pi;
	return (\@pa, \@pi);	
}


sub Get_Quarantine_Size {

# get the size of a quarantine directory (including slack space)
#
# Arguments:
# 	$quar_dir - the quarantine directory
#
# Return value:
#	( 
#	  $q_size = total size of the quarantined files
#	  $q_files = the number of quarantined files
#	)

	use File::Find ();

	# for the convenience of &wanted calls, including -eval statements:
	use vars "*name";
	*name = *File::Find::name;
	
	my $quar_dir = shift;
	defined $quar_dir or return (0, 0, 0, 0);
	
	our ($q_size, $q_files) = (0, 0);
	
	sub wanted {
	
		if (-f) {
			
			my ($size,$blocks);

			(undef, undef, undef, undef, undef, undef, undef, $size, undef, undef, undef, undef, $blocks) = stat($_);
			
			$q_size += $blocks * 512;
			$q_files++;
			
		}
	}
	
	return (0, 0, 0, 0) if (! -d "$quar_dir");
	
	File::Find::find(\&wanted, $quar_dir);
	
	return ($q_size, $q_files);

}

sub no_registry
{
	# This function checks if bdregd is running
	# it returns 0 if it's running and 1 if it's not running
	$cmd = `ps ax | grep bdregd |grep -v grep`;
        if ( $cmd eq "" )
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

sub readFile
{
    my $file_name = shift;
    open (MYFILE, $file_name);
    $line = "";
    while (<MYFILE>) {
	chomp;
        $line .= "$_\n";
    }
    close (MYFILE);
    return $line;
}

sub writeFile
{
    my ($file_name, $string) = @_;
    open (MYFILE, '> '.$file_name);
    print MYFILE $string;
    close (MYFILE);
}

