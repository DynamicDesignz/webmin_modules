#!/usr/bin/perl
my %actions_orders = ( "antivirus" => [ "disinfect", "delete", "move-to-quarantine", "drop",
				       "copy-to-quarantine", "reject", "ignore", "pipe" ] ,
		       "antispam"  => [ "ignore", "move-to-quarantine", "drop", 
		      		       "copy-to-quarantine",  "reject",  "pipe" ],
		       "samba"	   => [ "disinfect", "delete", "move-to-quarantine", 
		                       "deny", "copy-to-quarantine", "ignore" ] );

my %actions_no = ( "antivirus" => "7",
		   "antispam"  => "5",
		   "samba"     => "5");

my %actions_delimiter = ( "antivirus" => ";",
			  "antispam"  => ";",
			  "samba"     => ",");
sub complete_actions
{
# This function completes the actions found in xml
# and returns an array with all the completed actions
	my $active_actions_ref = shift;
	my @active_actions = @$active_actions_ref;
	my $actions_source = shift;
	my @all_actions;


	my $actions_order_ref = $actions_orders{$actions_source};
	my @actions_order = @$actions_order_ref;

	# The first actions are those found in xml
	for $i ( 0 .. $#active_actions )
	{
		$all_actions[$i] = $active_actions[$i];
	}

	my $all_index = $#active_actions + 1;
	for $i ( 0 .. $#actions_order )
	{

		my $flag = "absent";
		for $j ( 0 .. $#active_actions )
		{
			if ( $actions_order[$i] eq $active_actions[$j] )
			{
				$flag = "present";
				last;
			}
		}
		if ( $flag eq "absent" )
		{
			$all_actions[$all_index] = $actions_order[$i];
			$all_index++;
		}	

	}
	return @all_actions;
}

sub check_all_action_order
{
# This function checks if the order of all actions respects
# the order of action (this could have been changed with bdsafe).
# If they are in the wrong position it returns 1
my ($all_actions_ref, $actions_ref) = @_;
my @all_actions = @$all_actions_ref;
my @actions = @$actions_ref;
my ($retcode, $i_action, $a_action, $right_position) = ( 0, 0, 0, 0 );
while ( $i_action <= $#actions )
{

        while ( $a_action <= $#all_actions )
        {
        if ( $actions[$i_action] eq $all_actions[$a_action])
                { 
                $right_position++;
                $i_action++;
                }
        $a_action++;
        }
	$i_action++;
}

if ( $right_position < $#actions+1 )
	{
	$retcode = 1;
	}
return $retcode;
}

sub switch_antivirus_actions
{
# It switches on the functions that are active in xml
# and returns a hash with all actions and their corresponding
# switch
my $active_actions_ref = shift;
my @active_actions = @$active_actions_ref;
my %actions_switch = ( "disinfect" => "off",
                      "delete" => "off",
                      "copy-to-quarantine" => "off",
                      "move-to-quarantine" => "off",
                      "drop" => "off",
                      "reject" => "off",
                      "ignore" => "off",
                      "pipe" => "off" );

for $i ( 0 .. $#active_actions )
	{
	$actions_switch{$active_actions[$i]} = "on";
	}

return %actions_switch;
}

sub switch_antispam_actions
{
# It switches on the functions that are active in xml
# and returns a hash with all actions and their corresponding
# switch
my $active_actions_ref = shift;
my @active_actions = @$active_actions_ref;
my %actions_switch = ( "copy-to-quarantine" => "off",
                      "move-to-quarantine" => "off",
                      "drop" => "off",
                      "reject" => "off",
                      "ignore" => "off",
                      "pipe" => "off" );

for $i ( 0 .. $#active_actions )
	{
	$actions_switch{$active_actions[$i]} = "on";
	}

return %actions_switch;
}

sub switch_samba_actions
{
# It switches on the functions that are active in xml
# and returns a hash with all actions and their corresponding
# switch
 
my $active_actions_ref = shift;
my @active_actions = @$active_actions_ref;
my %actions_switch = ( "copy-to-quarantine" => "off",
                      "move-to-quarantine" => "off",
                      "disinfect" => "off",
                      "delete" => "off",
                      "ignore" => "off",
                      "deny" => "off" );

for $i ( 0 .. $#active_actions )
	{
	$actions_switch{$active_actions[$i]} = "on";
	}

return %actions_switch;
}

sub get_actions_data
{
# It returns all necessary action data, all ordered actions and a hash that says
# which are active and which are not. If the ordered action data is not available 
# it calculates it with the complete_actions function based on the order from
# $ordered_actions
my ($actions_key, $all_actions_key, $actions_source, $group) = @_;
my ($tmp_actions, $tmp_all_actions) = ("", "");

if ( $group eq "" )
{
	$tmp_actions = &BDReg_GetKeys ($actions_key);
	$tmp_all_actions = &BDReg_GetKeys ($all_actions_key);
	$all_actions_setkey = $all_actions_key;
}
else
{
	$tmp_actions = &BDReg_GetKeys($groups_root.$group.$actions_key);
	if ( $tmp_actions ne "ERR_KEY_DOES_NOT_EXIST" )
		{
			$tmp_all_actions = &BDReg_GetKeys($groups_root.$group.$all_actions_key);
			$all_actions_setkey = $groups_root.$group.$all_actions_key; 
		}
	else
		{
			$tmp_actions = &BDReg_GetKeys($groups_root."Default".$actions_key);
			$tmp_all_actions = &BDReg_GetKeys($groups_root."Default".$all_actions_key);
			$all_actions_setkey = $groups_root."Default".$all_actions_key;
		}
}

my $actions_comma = $actions_delimiter{$actions_source};

# Replace any quarantine with the new move-to-quarantine.
$tmp_actions =~ s/^quarantine/move-to-quarantine/;
#$tmp_actions =~ s/;quarantine/;move-to-quarantine/;
$tmp_actions =~ s/${actions_comma}quarantine/${actions_comma}move-to-quarantine/;

# The actions for antivirus and antispam are separated with ";"
# while the samba ones are separated with ","
my @actions  = split(/$actions_comma/,$tmp_actions);
my @all_actions = split(/$actions_comma/,$tmp_all_actions);
my $actions_number = $actions_no{$actions_source};

if ( $#all_actions lt $actions_number )
	{
		my $all_actions_string;
		@all_actions = &complete_actions(\@actions, $actions_source);
		# Write the key that contains all actions
		for $i ( 0 .. $#all_actions )
        	{
                	$all_actions_string = $all_actions_string."$all_actions[$i]$actions_comma";
        	}
		chop $all_actions_string;
		&BDReg_SetKey($all_actions_setkey, $all_actions_string);
	}
else
	{
		# Check if the actions order is the same in all actions
		if (&check_all_action_order(\@all_actions, \@actions))
		{
			# All actions key are not ordered, so we rewrite them
			my $all_actions_string;
			@all_actions = &complete_actions(\@actions, $actions_source);
			# Write the key that contains all actions
			for $i ( 0 .. $#all_actions )
	        	{
	                	$all_actions_string = $all_actions_string."$all_actions[$i]$actions_comma";
	        	}
			chop $all_actions_string;
			&BDReg_SetKey($all_actions_setkey, $all_actions_string);
		}
	}
my $switch_function = "switch_".$actions_source."_actions";
my %actions_switch = &$switch_function(\@actions);
return ( \@all_actions, \%actions_switch );
}

sub group_existance
{

my $group = shift;
my $group_exists = "no";

my $groups_entries = &BDReg_GetKeys ( "BDUX/GroupManagement/Groups/");
my @registered_groups =  split(/\n/, $groups_entries );
# Check if the group exists
foreach $registered_group ( @registered_groups )
	{
		if ( $group eq $registered_group ) 
		{
			$group_exists = "yes";
			last;
		}
	}

if ( $group_exists eq "no" )
{
	return 0;
}
return 1;

}
