#!/usr/bin/perl
my @menus_order = ( "status", "policies", "quarantine", "protocols", "maintenance", "reports");

my %menus = ( status =>     [  "", "services", "license", "news", "about" ],
	      policies =>   [  "",  "defsett", "groups" ],
	      quarantine => [ "", "deferred_quar", "spam_quar", "malware_quar", "samba_quar" ],
	      filters =>    [ "", "antivirus", "antispam", "antispy" ],
	      protocols =>  [ "", "smtp", "samba", "file" ],
	      maintenance =>[ "", "packages", "updates", "signatures", "live", "tests" ],
	      reports =>    [ "", "statistics", "charts", "logging","notifications", "smnp" ]
	     );
my %menus_links =  (
	      status 		=> "status.cgi",
	      policies 		=> "policies.cgi?subcat=settings",
	      quarantine 	=> "quarantine.cgi?subcat=deferred",
	      filters 		=> "filters.cgi",
	      protocols 	=> "protocols.cgi",
	      maintenance 	=> "maintenance.cgi?subcat=updates",
	      reports 		=> "reports.cgi?subcat=statistics"
	    );
my %submenus = (
		services 	=> [ "", "status.cgi?subcat=services" ],
		license		=> [ "", "status.cgi?subcat=license" ],
		about		=> [ "", "status.cgi?subcat=about"],
		groups		=> [ "", "policies.cgi?subcat=groups" ],
		defsett		=> [ "", "policies.cgi?subcat=settings" ],
		settings	=> [ "", "policies.cgi" ],
		antivirus	=> [ "", "filters.cgi?subcat=antivirus" ],
		antispam	=> [ "", "filters.cgi?subcat=antispam" ],
		antispy		=> [ "", "filters.cgi?subcat=antispy" ],
		smtp		=> [ "", "protocols.cgi?subcat=smtp" ],
		samba		=> [ "", "protocols.cgi?subcat=samba" ],
		updates		=> [ "", "maintenance.cgi?subcat=updates" ],
		signatures	=> [ "", "maintenance.cgi?subcat=signatures" ],
		patches		=> [ "", "maintenance.cgi?subcat=patches" ],
		live		=> [ "", "maintenance.cgi?subcat=live" ],
		logging		=> [ "", "reports.cgi?subcat=logging" ],
		statistics	=> [ "", "reports.cgi?subcat=statistics" ],
		charts		=> [ "", "reports.cgi?subcat=charts" ],
		notifications	=> [ "", "reports.cgi?subcat=notifications" ]
	      );	       
	      
sub draw_menu_tabs
{
	my $selected_menu = shift;
	my $selected_submenu = shift;
	# Mark the current menu and submenu
	
	#$menus{$selected_menu}[0] = "class=tab_off";
	#$submenus{$selected_submenu}[0] = "class=tab_on";

	for $i ( 1 .. $#{$menus{$selected_menu}} )
	{
	    if (exists $submenus{$menus{$selected_menu}[$i]})
	    {
		    if ($text{$menus{$selected_menu}[$i]}) {
		        if ($selected_submenu eq $menus{$selected_menu}[$i]){
			    $class_name = "class=\"tab_on\"";
			    $id = "id=tab_on";
			} else {
			    $class_name = "class=\"tab_off\"";
			    $id = "";
			}
			print "<div ".$id." ".$class_name."><a href='$submenus{$menus{$selected_menu}[$i]}[1]'>$text{$menus{$selected_menu}[$i]}</a></div>\n";
		    }
	    }
	}
}


sub create_menu_tabs
{
my $selected_menu = shift;
my $selected_submenu = shift;	

# Create quarantine submenus
my @quar_submenus = split(/\n/, &BDReg_GetKeys("/BDUX/Quarantine/Directories/"));
for ( @quar_submenus )
	{
		$submenus{$_."_quar"} = ([ "", "quarantine.cgi?subcat=$_" ]);
	}

# Check if there is filedaemon to disable the samba submenu and file quarantine
# submenu
if ( (not -e "$bitdefender_dir/var/samba.inf") || (&BDReg_GetKeys("/BDUX/FileDaemon") eq "ERR_KEY_DOES_NOT_EXIST") ){
    delete($submenus{'samba'});
    delete($submenus{'fileqr'});
}

# Check if there is MailDaemon to disable smtp submenu, mail quarantine submenu
# and policies menu
if ( (not -e "$bitdefender_dir/var/mail.inf") || (&BDReg_GetKeys("/BDUX/MailDaemon/") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
	delete($submenus{'smtp'});
	#delete($submenus{'mailqr'});
	}
# Check if the Enterprise Management is enabled to remove the license submenu
if ( &BDReg_GetKeys("/BDUX/Agents/Enterprise/EnterpriseAgentEnabled") eq "Y" )
	{
	delete($submenus{'license'});
	}
# Check if bdreg is running, if not keep only the services menu
        if ( &no_registry )
        {
	delete($submenus{'license'});
        }
# Begin menu
&draw_menu_tabs($selected_menu, $selected_submenu);

}

sub create_menu
{
    my $selected_menu = shift;
    my $header = "";

	# Check if there is MailDaemon to disable smtp submenu, mail quarantine submenu
	# and policies menu
	if ( (not -e "$bitdefender_dir/var/mail.inf") || (&BDReg_GetKeys("/BDUX/MailDaemon/") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
	@menus_order = ( "status", "quarantine", "protocols", "maintenance", "reports");
	}

	# Check if bdreg is running, if not keep only the services menu
        if ( &no_registry )
        {
	@menus_order = ( "status" );
        }

    for $i ( 0 .. $#menus_order ){
	if ($text{$menus_order[$i]}){
	    my $class_name = "";
	    if ($selected_menu eq $menus_order[$i]){
		$class_name = "class=\"link_active\"";
	    }
		
	    if ($i){
		$header = $header."&nbsp;&nbsp;|&nbsp;&nbsp;";
	    }
	    $header = $header."<a $class_name href=\"$menus_links{$menus_order[$i]}\">$text{$menus_order[$i]}</a>";
	    
	}
    }
    
    print $header;

}

1;
