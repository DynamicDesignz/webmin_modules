#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_advanced_policies.pl';
require 
	'./do_common_policies.pl';

sub do_adv_antivirus_settings
{
# Get and draw advanced antivirus settings for a given group
	
my $group = shift;
my $group_url = &urlize($group);
if (&group_existance($group))
	{
	if ( $group eq "Default" )
		{ 
		    	&draw_header("policies","defsett");
			&draw_tabs($text{'policies'},'policies',"defsett");
		}
	else
		{ 
		    	&draw_header("policies","settings");
			&draw_tabs($text{'policies'},'policies',"groups");
		}
	
	&draw_group_settings_header($group);

	# Get the pipe in settings
	my $av_pipe_program = &group_getkey ($group, "/Settings/Antivirus/PipeProgram");
	$av_pipe_program =~ s/ERR_KEY_DOES_NOT_EXIST//;
	my $av_pipe_arguments = &group_getkey ($group, "/Settings/Antivirus/PipeProgramArguments");
	$av_pipe_arguments =~ s/ERR_KEY_DOES_NOT_EXIST//;
	
	# Checkbox for enabling a single control for all actions
	my $sameactions_enable_check = &group_getkey( $group, "/Settings/Antivirus/UseVirusActionsOnAll");
	if ( $sameactions_enable_check eq "ERR_KEY_DOES_NOT_EXIST" )
	{
	# We check if all the malware actions are the same
	my $virus_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnVirus" );
	my $riskware_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnRiskware" );
	my $suspected_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnSuspected" );
	# If they are the same then we use by default all virus actions for all malware
	if ( ( $virus_actions eq $riskware_actions ) && ( $riskware_actions eq $suspected_actions ) )
		{
		&BDReg_SetKey($groups_root.$group."/Settings/Antivirus/UseVirusActionsOnAll", "Y");
		$sameactions_enable_check = "checked";
		}
	else
		{
		&BDReg_SetKey($groups_root.$group."/Settings/Antivirus/UseVirusActionsOnAll", "N");
		$sameactions_enable_check = "";
		}
	}
	elsif ( ( $sameactions_enable_check eq "y" ) || ( $sameactions_enable_check eq "Y" ) )
	        {
	                $sameactions_enable_check = "checked";
	        }
	else
	        {
	                 $sameactions_enable_check = "";
	        }

	# Get group antivirus and footer settings from registry
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#
	# Get actions settings and determine which action is active and which not
	# Virus actions
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	my $all_virus_actions, $virus_actions_switch, $all_suspected_actions, 
	$suspected_actions_switch, $all_riskware_actions, $riskware_actions_switch;
	# If the there are used the same actions for all the malware
	# we don't get the data for the Suspected and Riskware
	if ( $sameactions_enable_check eq "checked" )
	{
	($all_virus_actions, $virus_actions_switch) = &get_actions_data("/Settings/Antivirus/ActionsOnVirus", 
			  "/Settings/Antivirus/AllActionsOnVirus", "antivirus", $group);
	
	($all_suspected_actions, $suspected_actions_switch, $all_riskware_actions, $riskware_actions_switch) = 
	    ("", "", "", "");
    	}
	else
	{
	# The actions are different for every malware
	($all_virus_actions, $virus_actions_switch) = &get_actions_data("/Settings/Antivirus/ActionsOnVirus", 
			  "/Settings/Antivirus/AllActionsOnVirus", "antivirus", $group);
	($all_suspected_actions, $suspected_actions_switch) = &get_actions_data("/Settings/Antivirus/ActionsOnSuspected",
	       		  "/Settings/Antivirus/AllActionsOnSuspected", "antivirus", $group);
	($all_riskware_actions, $riskware_actions_switch) = &get_actions_data("/Settings/Antivirus/ActionsOnRiskware", 
			  "/Settings/Antivirus/AllActionsOnRiskware", "antivirus", $group);
	}

	# Get the other antivirus settings (checkboxes)
	my $av_scanning_enable_check = 	&verify_group_check( $group, "/Settings/Antivirus/Enable"); 
	my $av_email_header_check =  	&verify_group_check( $group, "/Settings/Antivirus/AddHeaders");
	my $av_email_disclaimer_check = &verify_group_check( $group, "/Settings/AddFooters");

	&draw_adv_group_settings_antivirus($group_url, $all_virus_actions, $virus_actions_switch, 
		$all_suspected_actions, $suspected_actions_switch, $all_riskware_actions, $riskware_actions_switch, 
		$av_email_disclaimer_check, $av_scanning_enable_check, $sameactions_enable_check, 
		$av_email_header_check, $av_pipe_program, $av_pipe_arguments);
	#&draw_group_settings_footer($group_url);
	&draw_footer();
	}
else
{

	&do_groups();
	return 0;
}
}

sub do_adv_antispam_settings
{
my $group = shift;
my $group_url = &urlize($group);
if (&group_existance($group))
	{
	if ( $group eq "Default" )
		{ 
		    	&draw_header("policies", "defsett");
			&draw_tabs($text{'policies'},'policies',"defsett");
		}
	else
		{ 
		    	&draw_header("policies", "settings");
			&draw_tabs($text{'policies'},'policies',"groups");
		}
	
	&draw_group_settings_header($group);

	# Get group antispam settings from registry
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	my @checkbox_values;
	my @checkbox_keys = ( "/Settings/Antispam/Enable", 		"/Settings/Antispam/Engines/UseBWFilter", 
			   "/Settings/Antispam/Engines/UseURLFilter",   "/Settings/Antispam/Engines/UseIMGFilter",
			   "/Settings/Antispam/Engines/UseBayesFilter", "/Settings/Antispam/Engines/UseHeurFilter",
			   "/Settings/Antispam/Engines/UseMultiFilter", "/Settings/Antispam/Engines/UsePBayesFilter",
			   "/Settings/Antispam/Engines/UseRblFilter", 	"/Settings/Antispam/Engines/UseSigFilter",	
			   "/Settings/Antispam/ModifySubject", 		"/Settings/Antispam/AddHeaders");
	# The checkbox keys are read in checkbox_values in the following order:
	# $as_enable_check, $blacklist_enable_check, $urlfilter_enable_check, $imagefilter_enable_check
	# $bayesfilter_enable_check, $heurfilter_enable_check, $multifilter_enable_check, $rblfilter_enable_check,
	# $signfilter_enable_check, $modifysubject_enable_check, $mailheader_enable_check 
	my $checkbox_count = $#checkbox_keys;
	for $i ( 0 .. $checkbox_count )
		{
		$checkbox_values[$i] = &verify_group_check($group, $checkbox_keys[$i]);
		}

	$checkbox_values[$checkbox_count+1] = &verify_check_with_value( 
		"/BDUX/MailDaemon/Antispam/eml/filter/multi/AsianCharsets","1");
	$checkbox_values[$checkbox_count+2] = &verify_check_with_value(
		"/BDUX/MailDaemon/Antispam/eml/filter/multi/CyrilicCharsets","1");
	$checkbox_values[$checkbox_count+3] = &verify_check_with_value(
		"/BDUX/MailDaemon/Antispam/eml/filter/rbl/CacheEnabled","1");

	my @rbl_servers_trust;
	
	
	
	my $rbl_timeout = 	  &BDReg_GetKeys("/BDUX/MailDaemon/Antispam/RblTimeout");
	$rbl_timeout =~ s/ERR_KEY_DOES_NOT_EXIST//;
	
	my $rbl_tmp_dns =	  &BDReg_GetKeys("/BDUX/MailDaemon/Antispam/DnsServers/");
	$rbl_tmp_dns =~ s/ERR_KEY_DOES_NOT_EXIST//;
	my @rbl_dns = split(/\n/, $rbl_tmp_dns);
	
	my $rbl_tmp_servers =	  &BDReg_GetKeys("/BDUX/MailDaemon/Antispam/RblServers/");
	$rbl_tmp_servers =~ s/ERR_KEY_DOES_NOT_EXIST//;
	my @rbl_servers = split(/\n/, $rbl_tmp_servers);

	for $i ( 0 .. $#rbl_servers )
		{
			$rbl_servers_trust[$i] = &BDReg_GetKeys ("/BDUX/MailDaemon/Antispam/RblServers/$rbl_servers[$i]");
		}
	
	my $subject_template =    &group_getkey( $group, "/Settings/Antispam/SubjectTemplate");
	my $spamheader_template = &group_getkey( $group, "/Settings/Antispam/HeaderTemplateSpam");
	my $hamheader_template =  &group_getkey( $group, "/Settings/Antispam/HeaderTemplateHam");
	my $as_threshold =  	  &group_getkey( $group, "/Settings/Antispam/Aggressivity");
        # Get the pipe in settings
	my $as_pipe_program = &group_getkey ($group, "/Settings/Antispam/PipeProgram");
	$as_pipe_program =~ s/ERR_KEY_DOES_NOT_EXIST//;
	my $as_pipe_arguments = &group_getkey ($group, "/Settings/Antispam/PipeProgramArguments");
	$as_pipe_arguments =~ s/ERR_KEY_DOES_NOT_EXIST//;
	# Get the actions data
	my ($all_as_actions, $as_actions_switch) = &get_actions_data("/Settings/Antispam/Actions", 
			  "/Settings/Antispam/AllActions", "antispam", $group);


	
	$whitelist_file = &group_getkey( $group, "/Settings/Antispam/WhiteList");
	$blacklist_file = &group_getkey( $group, "/Settings/Antispam/BlackList");
	
	$whitelist = "";
	if ($whitelist_file ne ""){
	    $whitelist = &readFile($whitelist_file);
	}
	
	$blacklist = "";
	if ($blacklist_file ne ""){
	    $blacklist = &readFile($blacklist_file);
	}
	
	&draw_adv_group_settings_antispam($group_url, \@checkbox_values, \@rbl_servers, \@rbl_servers_trust,
		\@rbl_dns, $rbl_timeout, $as_threshold, $subject_template, $spamheader_template, $hamheader_template, 
		$as_pipe_program, $as_pipe_arguments, $all_as_actions, $as_actions_switch, $whitelist, $blacklist);
  
	#&draw_group_settings_footer($group_url);
	&draw_footer();
	}
else
{

	&do_groups();
	return 0;
}
}

