function adjustTabs(){
	document.getElementById("tab_on").className = "tab_on";
}

// Display (and hide all the others) or hide a submenu when the parent is onclick
function switchmenu (object)
{
        if (document.getElementById)
        {       
                var submenu = object.parentNode.getElementsByTagName('ul')[0];
                var all_submenus = object.parentNode.parentNode.getElementsByTagName('ul');
                if (submenu.style.display == 'none' || submenu.style.display == '')
                {       
                        for (var i=0; i<all_submenus.length; i++)
                        {       
                                all_submenus[i].style.display = 'none'
                        }       
                        submenu.style.display = 'block';
                }       
                else    
                {       
                        submenu.style.display = 'none'; 
                }       
        }       
        return false;
}

function addEvent()
{
        var ni = document.getElementById('myDiv');
        var numi = document.getElementById('theValue');
        var num = (document.getElementById("theValue").value -1)+ 2; 
        numi.value = num;
        var divIdName = "my"+num+"Div";
        var newdiv = document.createElement('div');
        newdiv.setAttribute("id",divIdName);
	newdiv.innerHTML = "<input class=\"text\" type=\"text\" id=\"txt_"+divIdName+"\" name=\""+divIdName+"\" value=\"\" />  <a href=\"javascript:;\" onclick=\"removeEvent(\'"+divIdName+"\')\">Remove</a><br>";
        ni.appendChild(newdiv);
}       

function removeEvent(divNum)   
{        
        var d = document.getElementById('myDiv');
        var olddiv = document.getElementById(divNum);
        //alert(divNum);
        document.getElementById(divNum).innerHTML = "";//document.getElementById('txt_'+divNum).value;
        //d.removeChild(olddiv);
}

function doCondition(v){
    if (v.toLowerCase()=='exists' || v.toLowerCase()=='!exists'){
	document.getElementById("fe_value").disabled = true;
	document.getElementById("fe_value").value = "";
    } else {
	document.getElementById("fe_value").disabled = false;
    }
}

function updateContentFilterFormFields(cond){

    var select = document.getElementById("fe_type").value;
    var disable_header_name = 'none';
    
    var types = new Array("header", "body", "attachment-name", "attachment-type", "attachment-size", "filesize");
    
    var conditions = new Array();
    var values = new Array();
    conditions[0] = new Array("match","doesn't match","exists","doesn't exist");
    values[0] = new Array("match","!match","exists","!exists");
    
    conditions[1] = new Array("match","doesn't match");
    values[1] = new Array("match","!match");

    conditions[2] = new Array("match","doesn't match");
    values[2] = new Array("match","!match");
    
    conditions[3] = new Array("match","doesn't match");
    values[3] = new Array("match","!match");

    conditions[4] = new Array("greater than","not greater than");
    values[4] = new Array("greater-than","!greater-than");
    
    conditions[5] = new Array("greater than","not greater than");
    values[5] = new Array("greater-than","!greater-than");
    
    show_units = false;

    switch (select){
	case "header": 
	    i = 0;
	    disable_header_name = 'inline';
	    field_name = document.getElementById("fe_header_name_value").value;
	break;
	
	case "body": 
	    i = 1;
	    field_name = "body";
	break;
	
	case "attachment-name": 
	    i = 2;
	    field_name = "attachment-name";
	break;
	
	case "attachment-type": 
	    i = 3;
	    field_name = "attachment-type";
	break;
	
	case "attachment-size": 
	    i = 4;
	    field_name = "attachment-size";
	    show_units = true;
	break;
	
	case "mailsize": 
	    i = 5;
	    field_name = "mail size";
	    show_units = true;
	break;
	case "filesize": 
	    i = 5;
	    field_name = "mail size";
	    show_units = true;
	break;

	default:
	    i=0;
	    field_name= "header";
	break;
    
    
    }
    document.getElementById("fe_units").style.display = show_units?'':'none';
    var OptionList = document.getElementById("fe_condition");
    for (x = OptionList.length; x >= 0; x--) {
	OptionList[x] = null;
    }
    
    for (k=0;k<conditions[i].length;k++){
	t = new Option(conditions[i][k],values[i][k]);
	OptionList[k+1] = t;
	if (cond.toLowerCase()==values[i][k]){
	    t.selected = true;
	}
						      
    }
										 
    t = new Option("--------------","");
    OptionList[0] = t;
										     
    document.getElementById("fe_header_name").style.display = disable_header_name;
    document.getElementById("fe_field_name").innerHTML = field_name;

}

var reFloat = /^((\d+(\.\d*)?)|((\d*\.)?\d+))$/;

function isEmpty(s){   
    return ((s == null) || (s.length == 0))
}


function isFloat (s){   
    if (isEmpty(s)) 
	if (isFloat.arguments.length == 1) 
	    return false;
        else 
	    return (isFloat.arguments[1] == true);
	      
     return reFloat.test(s)
}
		  
    function toggleMessageVisibility(p){
	if  (p=='reject' || p=='replace'){
	    if (p=='reject'){
    		document.getElementById("mtext_reject").style.display = 'block';
    		document.getElementById("mtext_replace").style.display = 'none';
	    }
	    
	    if (p=='replace'){
    		document.getElementById("mtext_reject").style.display = 'none';
    		document.getElementById("mtext_replace").style.display = 'block';
	    }
	    
	    document.getElementById("mtextarea").style.display = 'block';
	} else {
	  document.getElementById("mtext_reject").style.display = 'none';
	  document.getElementById("mtext_replace").style.display = 'none';
	  document.getElementById("mtextarea").style.display = 'none';
	}
  }

    function selectRadioButton(){
	document.getElementById("ext_custom").checked = true;
	document.getElementById("ext_exe").checked = null;
	document.getElementById("ext_all").checked = null;
    }
function switchFormFields(b){
    if (b){
	document.getElementById("account_login_email").disabled 	= true;    
	document.getElementById("account_login_password").disabled	= true;    
	document.getElementById("account_register_email").disabled 	= false;    
	document.getElementById("account_register_password").disabled 	= false;    
	document.getElementById("account_register_password2").disabled 	= false;    
	document.getElementById("account_register_fname").disabled 	= false;    
	document.getElementById("account_register_lname").disabled 	= false;    
	document.getElementById("account_register_country").disabled 	= false;    
    } else {
	document.getElementById("account_login_email").disabled 	= false;    
	document.getElementById("account_login_password").disabled 	= false;    
	document.getElementById("account_register_email").disabled 	= true;    
	document.getElementById("account_register_password").disabled 	= true;    
	document.getElementById("account_register_password2").disabled 	= true;    
	document.getElementById("account_register_fname").disabled 	= true;    
	document.getElementById("account_register_lname").disabled 	= true;    
	document.getElementById("account_register_country").disabled 	= true;    
    
    }


}

function toggleRBLCache(v){
    if (v){
	document.getElementById("rbl_cache").disabled 		= false;
	document.getElementById("rblfilter_cache").disabled 	= false;
    } else {
    	document.getElementById("rbl_cache").disabled 		= true;
	document.getElementById("rblfilter_cache").disabled 	= true;
    }
}

function disablePassword(v){
    if (v)
	document.getElementById("ldap_password").disabled = true;
    else
	document.getElementById("ldap_password").disabled = false;
	
}

function ValidateImportFromLdap(n){
    if (!document.getElementById("senders").checked && !document.getElementById("recipients").checked){
	alert("Please select where do you want to import the users");
	return false;
    }


    for (var i=3;i<=n+3;i++){
	if (document.getElementById("label_"+i).checked){
	    return true;
	}
    }
    
    alert("Please choose the groups you want to import");
    return false;
}

function ValidateQuarantineForm(){
    return true;
}

function echeck(str){
    if(!str.match(/^[a-zA-Z\._\-0-9]{1,}@[a-zA-Z0-9\-_\.]{1,}\.[a-zA-Z]{2,}$/)){
	alert("Please enter a valid e-mail address.");
	return false;
    }
    return true;
}

function echeck2(str) {
    var at="@"
    var dot="."
    var lat=str.indexOf(at)
    var lstr=str.length
    var ldot=str.indexOf(dot)
    if (str.indexOf(at)==-1){
	alert("Invalid E-mail ID")
	return false
    }
									
    if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
	alert("Invalid E-mail ID")
	return false
    }
													
    if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
	alert("Invalid E-mail ID")
	return false
    }
																		
    if (str.indexOf(at,(lat+1))!=-1){
	alert("Invalid E-mail ID")
	return false
    }
																							 
    if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
        alert("Invalid E-mail ID")
        return false
     }
																												 
    if (str.indexOf(dot,(lat+2))==-1){
        alert("Invalid E-mail ID")
        return false
     }
																																	
    if (str.indexOf(" ")!=-1){
        alert("Invalid E-mail ID")
        return false
     }
     return true					
}
																																							    

function ValidateMyAccountForm(){
    var ac1 = document.getElementById("radio1").checked;
    var ac2 = document.getElementById("radio2").checked    
    
    if (ac1){
	if (!echeck(document.getElementById("account_login_email").value)){
	    return false;
	}    
	
	if (isEmpty(document.getElementById("account_login_password").value)){
	    alert("Please type your password");
	    return false;
	}
	var pass1 = document.getElementById("account_login_password").value;

	if(pass1.length<4||pass1.length>16){
	    alert("Password must be 4-16 characters long.");
	    return false;
	}
	        
    }
    
    if (ac2){
	if (!echeck(document.getElementById("account_register_email").value))
	    return false;
	    
	if (isEmpty(document.getElementById("account_register_password").value)){
	    alert("Please type your password");
	    return false;
	}
	
	if (isEmpty(document.getElementById("account_register_password2").value)){
	    alert("Please type your password confirmation");
	    return false;
	}
	
	var pass1 = document.getElementById("account_register_password").value;
	
	if(pass1.length<4||pass1.length>16){
	    alert("Password must be 4-16 characters long.");
	    return false;
	}
	
	if (document.getElementById("account_register_password2").value!=document.getElementById("account_register_password").value){
	    alert("Please make sure your password confirmation matches your password");
	    return false;
	}
	
	if (isEmpty(document.getElementById("account_register_fname").value)){
	    alert("Please type your first name");
	    return false;
	}
	
	if (isEmpty(document.getElementById("account_register_lname").value)){
	    alert("Please type your last name");
	    return false;
	}

	
    }

    return true;
}

function selectOption(select_id, string){
    var o = document.getElementById(select_id).options;
    for (var i=0; i<o.length; i++){
	if (o[i].value==string){
	    o[i].selected = true;
	    return true;
	}
    }
}
