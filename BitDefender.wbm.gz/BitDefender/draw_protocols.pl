#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

sub draw_smtp_header
{
&draw_header("protocols","smtp");
&draw_tabs($text{'smtp'},"protocols","smtp");

print <<EOF;             
EOF
}

sub draw_smtp_footer
{

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

&draw_footer;
}

sub draw_protocols_communigate
{
my ($cgt_path, $cgt_threads, $cgt_timeout) = @_;
$browse_cgate_path = &bd_file_chooser_button("cgate_path", 1, 0);

print <<EOF;
<form action="parse_protocols.cgi?action=communigate#communigate" method="POST">
<a name=communigate></a>
<fieldset class="fieldset_1column">
<legend>$text{'communigate'}</legend>

<table border=0>
    <tr>
	<td width=140>$text{'communigate_path'}</td>
	<td><input class="input_edit" type="text" name="cgate_path" value="$cgt_path" />&nbsp; $browse_cgate_path
	    <input type="hidden" name="initial_cgate_path" value="$cgt_path" /> </td></tr>

    <tr>
	<td>$text{'communigate_threads'}</td>
	<td><input class="input_edit" type="text" name="cgate_threads" value="$cgt_threads" />
	    <input type="hidden" name="initial_cgt_threads" value="$cgt_threads" /> </td></tr>
    <tr>
	<td>$text{'communigate_timeout'}</td>
	<td><input class="input_edit" type="text" name="cgate_timeout" value="$cgt_timeout" />
	    <input type="hidden" name="initial_cgt_timeout" value="$cgt_timeout" /> </td></tr>
</table>

</fieldset>
<table>
<table width="90%" style="float:left">
     <tr>
         <td><img src="images/new/s.gif" height="2"/></td>
     </tr>
     <tr>
	 <td>
	    <input class="button" type="submit" name="submit" value="$text{'apply_button'}" />
         </td>
     </tr>
     <tr>
         <td><img src="images/new/s.gif" height="2"/></td>
    </tr>
</table>


</form>
EOF
}

sub draw_protocols_courier
{
my $courier_path = shift;
$browse_courier_path = &bd_file_chooser_button("courier_path", 0, 0);

print <<EOF;
<form action="parse_protocols.cgi?action=courier#courier" method="POST">
<a name=courier></a>
<fieldset class="fieldset_1column">
<legend>$text{'courier'}</legend>
<table>
<tr><td width=120>$text{'courier_path'}</td>
<td><input class="input_edit" type="text" name="courier_path" value="$courier_path" style="width:400px;" />&nbsp;
$browse_courier_path
<input type="hidden" name="initial_courier_path" value="$courier_path" /> </td>
</tr>
</table>

</fieldset>
<table width="90%" style="float:left">
     <tr>
         <td><img src="images/new/s.gif" height="2"/></td>
     </tr>
     <tr>
	 <td>
		<input class="button" type="submit" name="submit" value="$text{'apply_button'}" />
         </td>
     </tr>
     <tr>
         <td><img src="images/new/s.gif" height="2"/></td>
    </tr>
</table>
</form>
EOF
}

sub draw_protocols_milter
{

my $milter_sock_path = shift;
$browse_milter_socket = &bd_file_chooser_button("milter_socket", 1, 0);

print <<EOF;
<form action="parse_protocols.cgi?action=milter#milter" method="POST">
<a name=milter></a>
<fieldset class="fieldset_1column">
<legend>$text{'milter'}</legend>

<table>
<tr><td width=120>$text{'milter_path'}</td>
<td><input class="input_edit" type="text" name="milter_socket" value="$milter_sock_path" style="width:400px;"  /> &nbsp; $browse_milter_socket
<input type="hidden" name="initial_milter_socket" value="$milter_sock_path" /> </td>
</tr></table>
</fieldset>
<table width="90%" style="float:left">
     <tr>
              <td><img src="images/new/s.gif" height="2"/></td>
	           </tr>
		        <tr>
			    <td>
				 <input class="button" type="submit" name="submit" value="$text{'apply_button'}" />
             </td>
     </tr>
     <tr>
         <td><img src="images/new/s.gif" height="2"/></td>
    </tr>
</table>
				 
</form>
EOF
}

sub draw_protocols_qmail
{

my $qmail_path = shift;
$browse_qmail_queue_path = &bd_file_chooser_button("qmail_queue_path", 0, 0);

print <<EOF;
<form action="parse_protocols.cgi?action=qmail#qmail" method="POST">
<a name=qmail></a>
<fieldset class="fieldset_1column">
<legend>$text{'qmail'}</legend>

<table>
<tr><td width=120>$text{'qmail_path'}</td>
<td><input class="input_edit" type="text" size="27" name="qmail_queue_path" value="$qmail_path" style="width:400px;"  /> &nbsp; 
$browse_qmail_queue_path
<input type="hidden" name="initial_qmail_queue_path" value="$qmail_path" /> </td>
</tr>
</table>
</fieldset>
<table width="90%" style="float:left">
     <tr>
	<td><img src="images/new/s.gif" height="2"/></td>
     </tr>
     <tr>
        <td><input class="button" type="submit" name="submit" value="$text{'apply_button'}" /></td>
     </tr>
    <tr>
        <td><img src="images/new/s.gif" height="2"/></td>
    </tr>
</table>
</form>
EOF
}

sub draw_protocols_no_integration
{
print <<EOF;
<fieldset>
<label class=''>$text{'no_mta_integration'}</label><br>
</fieldset>	
EOF
}
sub draw_protocols_samba
{
my ($all_infected_actions, $infected_actions_switch, $all_suspected_actions, $suspected_actions_switch, 
$all_riskware_actions, $riskware_actions_switch, $samba_extensions, $samba_maxfilesize, $samba_sameactions) = @_;

&draw_header("protocols","samba");
&draw_tabs($text{'samba'},"protocols","samba");


my $actions_count = $#{$samba_actions};

print <<EOF;
<fieldset class="fieldset_1column">
    <legend>$text{'samba_actions'}</legend>
    <form action="parse_protocols.cgi?action=samba" method="POST">
	<input class="checkbox" type="checkbox" name="sameactions_enable" id="sameactions_enable" value="Y" $samba_sameactions />
	<label class="checkbox" for="sameactions_enable" >$text{'samba_sameactions'}</label>
	<input type="hidden" name="initial_sameactions_enable" value="$samba_sameactions" />
  
 <table width="70%">
                      <tr>
		      
EOF

my $url="parse_protocols.cgi?";
if ($samba_sameactions eq "checked")
{
	&draw_settings_actions($url, "infected", $all_infected_actions, $infected_actions_switch);
	&draw_settings_actions_disabled("suspected", $all_infected_actions, $infected_actions_switch);
	&draw_settings_actions_disabled("riskware", $all_infected_actions, $infected_actions_switch);
}
else
{
	&draw_settings_actions($url, "infected", $all_infected_actions, $infected_actions_switch);
	&draw_settings_actions($url, "suspected", $all_suspected_actions, $suspected_actions_switch);
	&draw_settings_actions($url, "riskware", $all_riskware_actions, $riskware_actions_switch);

}
print <<EOF;
</tr>
</table>
</fieldset>
<fieldset class="fieldset_1column">
    <legend>$text{'samba_extensions'}</legend>
EOF

my ($all_check, $custom_check, $extensions_check, $initial_extensions) = ( "", "", "", "");
if ( $samba_extensions eq "*" )
{
	$all_check = "checked";
	$samba_extensions = "";
	$initial_extensions = "all";
}
elsif ( $samba_extensions eq $executable_files_extensions )
{
	$executables_check = "checked";
	$samba_extensions = "";	
	$initial_extensions = "executables";
}
else 
{
	$custom_check = "checked";
	$initial_extensions = "custom";
}

print <<EOF;
<input class="radio" type="radio" name="extensions" id="ext_all" value="all" $all_check />
<label class="radio" for="ext_all" >$text{'samba_all'}</label>
<br />
<input class="radio" type="radio" name="extensions" id="ext_custom" value="custom" $custom_check />&nbsp; <label class="radio" for="ext_custom" >$text{'samba_custom'}</label> <input class="input_edit" style="float:none;" type="text" size="40" name="custom_extensions" value="$samba_extensions"  onFocus="selectRadioButton();" />
<input type="hidden" name="initial_custom_extensions" value="$samba_extensions" /><br/>
<input class="radio" type="radio" name="extensions" id="ext_exe" value="executables" $executables_check/>
<label class="radio" for="ext_exe" >$text{'samba_executables'}</label>
<input type="hidden" name="initial_extensions" value="$initial_extensions" />
<br />
EOF


print <<EOF;
</fieldset>
<fieldset class="fieldset_1column">
<legend>$text{'samba_maxsize'}</legend>
<table>
    <tr>
 <td>$text{'samba_maxsize'} (KB)</td>
 <td><input class="input_edit" type="text" size="6" name="maxsize" value="$samba_maxfilesize" />
 <input type="hidden" name="initial_maxsize" value="$samba_maxfilesize" /></td>
</tr></table>

</fieldset>
EOF

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td><input class="button" type="submit" value="$text{'apply_button'}" /></td>
				</form>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF
&draw_footer();
}

sub draw_protocols_smtp
{
my ($smtp_server_addr, $smtp_server_port, $smtpd_port, $smtpd_timeout, $smtpd_threads, $smtpd_mailsize, 
	$smtpd_interfaces, $smtpd_networks, $smtpd_networks_mask, $smtpd_domains) = @_;

print <<EOF;
<form action="parse_protocols.cgi?action=smtpd#smtpd" method="POST">
<a name=smtpd></a>
<fieldset class="fieldset_1column">
<legend>$text{'smtp_proxy'}</legend>

<table>
<tr>
    <td>$text{'smtp_real_server'}</td>
    <td><input class="input_edit" type="text" name="smtp_realserver_addr" value="$smtp_server_addr" />
    <input type="hidden" name="initial_smtp_realserver_addr" value="$smtp_server_addr" /> </td>
    <td rowspan=3>&nbsp;&nbsp;&nbsp;&nbsp;</td>
    <td>$text{'smtp_timeout'}</td>
    <td><input class="input_edit" type="text" name="smtpd_timeout" value="$smtpd_timeout" />
    <input type="hidden" name="initial_smtpd_timeout" value="$smtpd_timeout" /> </td>
</tr>
<tr>
    <td>$text{'smtp_real_port'}</td>
    <td><input class="input_edit" type="text" name="smtp_realserver_port" value="$smtp_server_port" />
    <input type="hidden" name="initial_smtp_realserver_port" value="$smtp_server_port" /> </td>

    <td>$text{'smtp_threads'}</td>
    <td><input class="input_edit" type="text" name="smtpd_threads" value="$smtpd_threads" />
    <input type="hidden" name="initial_smtpd_threads" value="$smtpd_threads" /> </td>
</tr>

<tr>
    <td>$text{'smtp_port'}</td>
    <td><input class="input_edit" type="text" name="smtpd_port" value="$smtpd_port" />
    <input type="hidden" name="initial_smtpd_port" value="$smtpd_port" /> </td>

    <td>$text{'smtp_maxmailsize'}</td>
    <td><input class="input_edit" type="text" name="smtpd_maxmailsize" value="$smtpd_mailsize" />
    <input type="hidden" name="initial_smtpd_maxmailsize" value="$smtpd_mailsize" /> </td>
</tr>
</table>
<hr noshade size=1 color=#CCCCCC>

EOF

print "<b>$text{'smtp_networks'}</b>";
print "<a name=networks></a>";

print <<EOF;
    <table>
	<tr>
	    <td>
		<input class='input_edit' type='text' size='15' name='new_network'></td>
	    <td>
		<input class='input_edit' type='text' size='15' name='new_mask'></td>
	    <td>
		<input class="button" type="submit" name="networks" value="$text{'add_button'}" /></td>
	</tr>

EOF
for $i ( 0 .. $#{$smtpd_networks} ) 
	{
	print "<tr>
		<td><input class='input_edit' type='text' size='15' name='edit_networks' value='${$smtpd_networks}[$i]' />";
	print "<input type='hidden' name='initial_networks' value='${$smtpd_networks}[$i]' /></td>";
	print "<td><input class='input_edit' type='text' size='15' name='edit_networks_mask' value='${$smtpd_networks_mask}[$i]' />\n";
	print "<input type='hidden' name='initial_networks_mask' value='${$smtpd_networks_mask}[$i]' /></td>";
	print "<td><input class='checkbox' type='checkbox' name='check_networks' value='${$smtpd_networks}[$i]' /></td></tr>";
	}

print <<EOF;
</table>
<input class="button" type="submit" name="networks" value="$text{'remove_button'}" />
<hr noshade size=1 color=#CCCCCC>
EOF

print "<a name=domains></a>";
print "<b>$text{'smtp_domains'}</b>";
print <<EOF;
    <table>
	<tr>
	    <td><input class='input_edit' type='text' name='new_domain'></td>
	    <td><input class="button" type="submit" name="domains" value="$text{'add_button'}" /></td>
	<tr>
EOF
for $i ( 0 .. $#{$smtpd_domains} ) 
	{
	print "<tr><td><input class='input_edit' type='text' name='edit_domains' value='${$smtpd_domains}[$i]' /></td>";
	print "<td><input class='checkbox' type='checkbox' name='check_domains' value='${$smtpd_domains}[$i]' />";
	print "<input type='hidden' name='initial_domains' value='${$smtpd_domains}[$i]'></td></tr>";
	}

print <<EOF;
</table>
<input class="button" type="submit" name="domains" value="$text{'remove_button'}" />
<hr noshade size=1 color=#CCCCCC>
EOF

print "<a name=interfaces></a>";
print "<b>$text{'smtp_interfaces'}</b>";
print <<EOF;
    <table>
	<tr>
	    <td><input class='input_edit' type='text' size='15' name='new_interface'></td>
	    <td><input class="button" type="submit" name="interfaces" value="$text{'add_button'}" /></td>
	</tr>
EOF
for $i ( 0 .. $#{$smtpd_interfaces} ) 
	{
	print "<tr><td><input class='input_edit' type='text' size='15' name='edit_interface' value='${$smtpd_interfaces}[$i]' /></td>";
	print "<td><input class='checkbox' type='checkbox' name='check_interfaces' value='${$smtpd_interfaces}[$i]' />\n";
	print "<input type='hidden' name='initial_interface' value='${$smtpd_interfaces}[$i]'></td></tr>";
	}

print <<EOF;
</table>
<input class="button" type="submit" name="interfaces" value="$text{'remove_button'}" />
<hr noshade size=1 color=#CCCCCC>
<input class="button" type="submit" name="submit" value="$text{'apply_button'}" />
</fieldset>
</form>
EOF

}

1;
