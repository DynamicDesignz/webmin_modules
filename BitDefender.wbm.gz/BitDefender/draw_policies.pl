#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

sub draw_group_settings_header
{
my ($group, $type) = @_;
print <<EOF;
<table BORDER=0 cellpadding="0" cellspacing="0" width="100%">
    <tr>
EOF
}

sub draw_ldap_import_group()
{
    my ($selected_group, $count_users, $type, $group_exists) = @_;
    my $group_name = &un_urlize($selected_group);
    
print <<EOF;
    <td>
        <fieldset class="fieldset_1column">
	    <legend>$text{'group_ldap_import_group'}</legend>
		    <table border=0>
			<form action="parse_groups.cgi?action=parse_groups&import_users=true" method="POST">
			<tr>
			    <td width=130><b>$text{'group_ldap_import_group_name'}:</b></td>
			    <td>$group_name <input type="hidden" name="initial_ldap_group_name" value="$group_name"/>
			    <input type="hidden" name="type" value="$type"/></td>
			</tr>
			<tr>
			    <td width=130><b>$text{'group_ldap_import_users'}:</b></td>
			    <td>$count_users</td>
			</tr>
EOF

if ($group_exists eq "true")
{
print <<EOF;
                        <tr>
                            <td><b>$text{'group_ldap_import_new'}:</b></td>
                            <td><input type=edit class=input_edit name=ldap_group_name id=ldap_group_name value="" /></td>
                        </tr>
			<tr>
			    <td></td><td>$text{'group_ldap_import_exists'}</td>
			</tr>
EOF
}
else
{
print <<EOF;
			<tr>
			    <td><b>$text{'group_ldap_import_new'}:</b></td>
			    <td><input type=edit class=input_edit name=ldap_group_name id=ldap_group_name value="$group_name" /></td>
			</tr>
EOF
}
print <<EOF;
		    </table>
	        </fieldset>
	    </td>
	</tr>
	</table>

    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <input class="button" name="import_name_button" type="submit" value="$text{'group_ldap_import'}" />
		</td>
	    </tr>
	    </form>
	</table>
    </td>
</tr>
	    
EOF
	    
	

}

sub draw_ldap_settings
{
my ($ldap_server, $ldap_root_node, $ldap_username, $ldap_use_registry_password, $ldap_error) = @_;

if ($ldap_error eq "true"){
    $ldap_error = $text{'group_ldap_connection_error'};
} else {
    $ldap_error = "";
}

$ldap_checked_password  = "";
$ldap_disabled_password = "";
if ($ldap_use_registry_password eq "y")
    { $ldap_checked_password = "checked"; $ldap_disabled_password = "disabled"; }

print <<EOF;
	    <td>
	        <fieldset class="fieldset_1column">
	        <legend>$text{'group_ldap_configure'}</legend>
		    <table border=0>
			<form action="parse_groups.cgi?action=parse_groups" method="POST">
			<tr>
			    <td colspan=2><div id=ldap_status>$ldap_error</div></td>
			</tr>
			<tr>
			    <td width=130><b>$text{'group_ldap_server_address'}:</b></td>
			    <td><input type=edit class=input_edit name=ldap_server_address id=ldap_server_address style="width:250px;" value="$ldap_server" /></td>
			</tr>
			<tr>
			    <td><b>$text{'group_ldap_username'}:</b></td>
			    <td><input type=edit class=input_edit name=ldap_username id=ldap_username value="$ldap_username" /></td>
			</tr>
			<tr>
			    <td><b>$text{'group_ldap_password'}:</b></td>
			    <td><input type=password class=input_edit name=ldap_password id=ldap_password $ldap_disabled_password /> <input type=checkbox value='y' $ldap_checked_password id=ldap_user_registry_password name=ldap_user_registry_password onClick="disablePassword(this.checked);" /><label for=ldap_user_registry_password>$text{'group_ldap_password_use'}</label></td>
			</tr>
			<tr>
			    <td><b>$text{'group_ldap_root_node'}:</b></td>
			    <td><input type=edit class=input_edit name=ldap_root_node id=ldap_root_node style="width:250px;"  value="$ldap_root_node" /></td>
			</tr>
		    </table>
	        </fieldset>
	    </td>
	</tr>
	</table>

    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <input class="button" name="import_button" type="submit" value="$text{'group_ldap_connect'}" />
		    
		</td>
	    </tr>
	    </form>
	</table>
    </td>
</tr>
	    
EOF


}


sub draw_ldap_groups_list
{
    my ($ldap_groups, $selected_group, $ldap_group_users) = @_;
    my @groups = @$ldap_groups;
    my @users = @$ldap_group_users;
$count = $#groups-3;
print <<EOF;
	<table cellspacing=0 cellpadding=0>
	    <form action=parse_groups.cgi?action=parse_groups method=post onSubmit="return ValidateImportFromLdap($count);">
		<input type=hidden name=group_name value="" id="group_name">
EOF

for $i ( 3 .. $#groups ){
    $group_label = $groups[$i];
    $group_label =~ s/\t//;
    $group_name = &urlize($group_label);
    
    print "<tr>
		<td><a href=#$i></a><input type=radio value=$group_name name=ldap_group id=label_$i onClick=\"document.getElementById('group_name').value='$group_name';\"><a href=parse_groups.cgi?action=parse_groups&import_button=import&group=$group_name><strong>".$group_label."</strong></a></td>
	</tr>";
	
    if ($selected_group eq $group_label) {
	for $j ( 3 .. $#users ){
	    $user_label = $users[$j];
	    $user_label =~ s/\t//;
	    $user_label =~ s/</\&lt;/;
	    $user_label =~ s/>/\&gt;/;
	    print "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$user_label</td></tr>";
	    
	}
    }	
}

print <<EOF;

	</table>

    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <input type=radio id="senders" name="senders" value="y" /> Import to senders &nbsp;
		    <input type=radio id="recipients" name="senders" value="n" /> Import to recipients &nbsp;
		    <input type="submit" name="import" class="button" value="Import" >
		    <input type="button" class="button" value="Settings" onClick="document.location='parse_groups.cgi?action=parse_groups&import_button=import&settings=true';" />
		</td>
	    </tr>
	    </form>
	</table>
    </td>
</tr>

EOF
}


sub draw_group_cf_settings
{
$group = shift;
$rules_count = shift;
$group_url = &urlize($group);
$Rule = shift;
$Enabled = shift;
$Name = shift;
$Type = shift;
$Header_Name = shift;
$Condition = shift;
$Value = shift;
$Action = shift;
$Notify = shift;
$Message = shift;
$Units = shift;

$Message = &un_urlize($Message);

print <<EOF;
<td>
    <script language="Javascript">
    
    
    //Added here because of the translation problem
    function validateContentFilterForm(){
	var fe_name 		= document.getElementById("fe_name").value;
        var fe_type 		= document.getElementById("fe_type").value;
	var fe_header_name 	= document.getElementById("fe_header_name_value").value;
        var fe_condition 	= document.getElementById("fe_condition").value;
        var fe_value 		= document.getElementById("fe_value").value;
	var fe_action		= document.getElementById("fe_action").value;	

        if (!fe_name || fe_name==""){
	    alert("$text{'group_cf_error_name'}");
	    return false;
	}
	if (fe_type=='header' && (!fe_header_name || fe_header_name=="")){
	    alert("$text{'group_cf_error_header_name'}");
	    return false;
	}
    
        if (!fe_condition || fe_condition==""){
	    alert("$text{'group_cf_error_condition'}");
	    return false;
	}

        if (!fe_value || fe_value==""){
	    if (fe_condition!='exists' && fe_condition!='!exists'){
    	        alert("$text{'group_cf_error_value'}");
		return false;
	    }
	} else {
	    if (fe_type=='mailsize' || fe_type=='attachment-size'){
		if (!isFloat(fe_value)){
		    alert("$text{'group_cf_error_value_float'}");
		    return false;
				
		
		}
	    }
	}

        if (!fe_action || fe_action==""){
	    alert("$text{'group_cf_error_action'}");
	    return false;
	}
    
	return true;
    }

    </script>

    <form action="parse_policies.cgi?group=$group_url&action=parse_rule" method="POST" onSubmit="return validateContentFilterForm();">
    <table width="100%" border="0" cellspacing="0" cellpadding="1">
EOF

if ($Rule eq "")
{
    print <<EOF;
	<tr class="container_table_odd_row">
	    <td width="140" valign="top">&nbsp;$text{'group_cf_edit_order'}: </td>
	    <td width="140"><select name="Position" class="input_select" ><option value="last">$text{'group_cf_edit_order_last'}</option><option value="first">$text{'group_cf_edit_order_first'}</option></select></td>
	    <td>&nbsp;&nbsp;&nbsp;&nbsp;<span class="tooltip">($text{'group_cf_edit_filter_order_tooltip'})</span></td>
	</tr>
EOF
} else {
    print <<EOF;

        <tr class="container_table_odd_row">
	    <td valign="top" width="140">&nbsp;$text{'group_cf_edit_order'}: </td>
	    <td>$Rule</td>
	    <td></td>
	</tr>
EOF
}

print <<EOF;
        <tr class="container_table_even_row">
	    <td valign="top" width="140">&nbsp;$text{'group_cf_edit_filter_name'}: </td>
	    <td width="140"><input name="Name" id="fe_name" type="edit" class="input_edit" value="$Name" />
	    <input type="hidden" name="initial_Name" value="$Name" />
	    <input type="hidden" name="rule_number" value="$Rule" /></td>
	    <td>&nbsp;&nbsp;&nbsp;&nbsp;<span class="tooltip">($text{'group_cf_edit_filter_name_tooltip'})</span></td>
	</tr>
        <tr class="container_table_odd_row">
	    <td  valign="top" width="140">&nbsp;$text{'group_cf_edit_type'}: </td>
	    <td nowrap><select name=Type id="fe_type" class="input_select" onChange="updateContentFilterFormFields('');">
EOF

print "<option value=\"header\" ".($Type eq "header"?"selected":"").">header</option>";
print "<option value=\"body\" ".($Type eq "body"?"selected":"").">body</option>";
print "<option value=\"mailsize\" ".($Type eq "mailsize"?"selected":"").">mail size</option>";
print "<option value=\"attachment-name\" ".($Type eq "attachment-name"?"selected":"").">attachment name</option>";
print "<option value=\"attachment-type\" ".($Type  eq "attachment-type"?"selected":"").">attachment type</option>";	
print "<option value=\"attachment-size\" ".($Type  eq "attachment-size"?"selected":"").">attachment size</option>";

#$disabled_header_name = "";
#if ($Type eq "header"){
#    $disabled_header_name = "";
#}
    
print <<EOF;
	    </select><span id="fe_header_name">&nbsp;&nbsp;Header name:<input type="edit" name="Header_Name" id="fe_header_name_value" class="input_edit" value="$Header_Name" style="float:none;" onChange="updateContentFilterFormFields('');" /></span>
	    <input type="hidden" name="initial_Type" value="$Type" />
	    <input type="hidden" name="initial_Header_Name" value="$Header_Name" />
	    
	    </td>
	    <td>&nbsp;&nbsp;&nbsp;&nbsp;<span class="tooltip">($text{'group_cf_edit_filter_type_tooltip'})</span></td>
	</tr>
	<tr class="container_table_even_row">
	    <td width="140" valign="top">&nbsp;Notify: </td>
	    <td width="340"><select name="Notify" class="input_select">
EOF

print 			"<option value=none".($Notify eq "none"?" selected":"").">none</option>";
print 			"<option value=administrator".($Notify eq "administrator"?" selected":"").">administrator</option>";
print 			"<option value=recipients".($Notify eq "recipients"?" selected":"").">recipient(s)</option>";
print 			"<option value=sender".($Notify eq "sender"?" selected":"").">sender</option>";

print <<EOF;
		</select>
		 <input type="hidden" name="initial_Notify" value="$Notify" />
		 
		</td>
	    <td>&nbsp;&nbsp;&nbsp;&nbsp;<span class="tooltip">($text{'group_cf_edit_filter_notify_tooltip'})</span></td>
	</tr>
EOF

if ($Rule eq ""){
    $fe_field_name = "&nbsp;";
} else {
    if ($Type eq "header"){
	$fe_field_name = $Header_Name;
    } else {
	$fe_field_name = $Type;
    }
}

print <<EOF;
	<tr class="container_table_odd_row">
	    <td width="140" valign="top">&nbsp;$text{'group_cf_edit_filter_formula'}:</td>
	    <td colspan="2"><span class="tooltip">$text{'group_cf_edit_filter_formula_tooltip'}:</span></td>
	</tr>
	<tr class="container_table_even_row">
	    <td width="140" valign="top"></td>
	    <td colspan="2" nowrap>
		<input type="hidden" name="initial_Condition" value="$Condition" />
		<input type="hidden" name="initial_Value" value="$Value" />
		<table border=0>
		    <tr>
			<td>
			    <b><font color=#0000CC>$text{'group_cf_edit_formula_if'}</font></b>&nbsp;&nbsp;&nbsp;</td>
			<td>
			    <div id="fe_field_name" style="font-weight:bold;width:120px;">$fe_field_name</div></td>
			<td><select class="input_select" name="Condition" onChange="doCondition(this.value);" id="fe_condition"><option value="">------------</option></select></td>
			<td valign="top"><input type="edit" id="fe_value" style="width:70px;float:none;"  name="Value" class="input_edit" value="$Value" />
			 <input type="hidden" name="initial_Units" value="$Units" />
			</td>
			<td>
			<select name="Units" id="fe_units" class="input_select">
EOF

print "<option value=K ".($Units eq 'K'?"selected":"").">KB</option>";
print "<option value=M ".($Units eq 'M'?"selected":"").">MB</option>";
print "<option value=G ".($Units eq 'G'?"selected":"").">GB</option>";

print <<EOF;
			    </select><script language="Javascript">updateContentFilterFormFields('$Condition');</script>
			</td>
			<td><b><font color=#0000CC>$text{'group_cf_edit_formula_then'}</font> </b></td>
			<td>
			    <input type="hidden" name="initial_Action" value="$Action" />
			    <select class="input_select" name="Action" id="fe_action" onChange="toggleMessageVisibility(this.value);">
				    <option value="">-----------------</option>
EOF

print "				    <option value=\"ignore\" ".($Action eq "ignore"?"selected":"").">Ignore</option>";
print "				    <option value=\"drop\" ".($Action eq "drop"?"selected":"").">Drop</option>";
print "				    <option value=\"reject\" ".($Action eq "reject"?"selected":"").">Reject</option>";
print "				    <option value=\"replace\" ".($Action eq "replace"?"selected":"").">Replace</option>";
print "				    <option value=\"quarantine\" ".(($Action eq "quarantine") || ($Action eq "move-to-quarantine")?"selected":"").">Move to quarantine</option>";
print "				    <option value=\"copy-to-quarantine\" ".($Action eq "copy-to-quarantine"?"selected":"").">Copy to quarantine</option>";
print <<EOF;
			    </select></td>
		    </tr>
		</table>
			    
	    </td>
	</tr>
EOF

print <<EOF;
	<tr>
	    <td width="140" valign="top">
		<div id="mtext_reject" 
EOF
if ($Action ne "reject"){
    print "style=\"display:none;\"";
}

print "$text{'group_cf_edit_message_reject'}</div><div ";
if ($Action ne "replace"){
    print "style=\"display:none;\"";
}
print <<EOF;
 id="mtext_replace">$text{'group_cf_edit_message_replace'}</div></td>
	    <td colspan="2">
		<input type="hidden" name="initial_Message" value="$Message" />
		<div id="mtextarea"><textarea class="input_edit" style="width:500px; height:65px;" name="Message">$Message</textarea></div>
	    </td>
	</tr>
EOF

print <<EOF;
	</table>
	<script language="Javascript">
	    /**
	     * Setting disable condition value if default condition is exists or !exists
	     **/
	    var fe_condition        = document.getElementById("fe_condition").value;
	    if (fe_condition.toLowerCase()=='exists' && fe_condition.toLowerCase()=='!exists'){
	        document.getElementById("fe_value").value = '';
		document.getElementById("fe_value").disabled = true;
	    } else {
		document.getElementById("fe_value").disabled = false;
	    }
		     
	    doCondition("$Condition");     
	
	    toggleMessageVisibility('$Action');
	</script>
</td>
</tr>
EOF

print <<EOF;
	    </table>
    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <input name="rules_count"  type="hidden" value="$rules_count" />
		    <input type="submit" class="button" value="$text{'apply_button'}">&nbsp;
		    <input type="button" value="$text{'back_button'}" class="button" onClick="location='parse_policies.cgi?group=$group_url&action=filters';" />
		</td>
	    </tr>
	</table>
    </td>
</tr>
</form>
EOF

}

sub draw_group_settings_content_filtering
{
$group_url = shift;
$default_state = shift;

print <<EOF;
		</tr>
		<tr>
		    <td colspan=3>
		    	<fieldset class="fieldset_1column">
			<legend>$text{'group_cf'}</legend>
			    <table cellspacing="0" cellpadding="0">
				<input name="initial_group_cf_enabled"  type="hidden" value="$default_state" />
				<tr>
				    <td><label><input name="group_cf_enabled" type="checkbox" value="Y" $default_state/>$text{'group_cf_enabled'}</label></td>
				    <td>&nbsp;<input type="submit" name="edit_cf_filters" value="$text{'group_cf_edit_filters'}" class="button" /></td>
				</tr>
			    </table>
		    	</fieldset>

		    </td>
		</tr>
EOF
}

sub draw_group_content_filtering
{
    $group = shift;
    $group_url = shift;
    $filters_list_tmp = shift;
    my %filters_list = %$filters_list_tmp;	

    
    print <<EOF;
	<table border="0" width="99%" cellspacing="0" cellpadding="3">
	<form action="parse_policies.cgi?group=$group&action=filters" method="post">
        <tr>
		<td class="container_table_header" width="20">&nbsp;</td>
		<td class="container_table_header" width="20"><b>&nbsp;</b></td>
		<td class="container_table_header"><b>$text{'group_cf_filter_name'}</b></td>
		<td class="container_table_header" width="40"><b>$text{'group_cf_status'}</b></td>
		<td class="container_table_header" width="75"><b>$text{'group_cf_applied'}</b></td>
		<td class="container_table_header" width="120"><b>$text{'group_cf_condition'}</b></td>
		<td class="container_table_header" width="40"><b>$text{'group_cf_action'}</b></td>
		<!--td class="container_table_header" width="120"><b>$text{'group_cf_notify'}</b></td-->
		<td class="container_table_header" width="50"><b>$text{'group_cf_order'}</b></td>
	</tr>
EOF

for $i ( 0 .. $#{$filters_list{'Name'}}) {
    if ($i%2 eq "1")  {
	print "<tr class=container_table_even_row>";
    } else {
	print "<tr class=container_table_odd_row>";
    } 

    if ($filters_list{'Header_Name'}[$i] eq 'ATTACHMENT'){
	$file_icon = "attachment.gif";
    } else {
	$file_icon = "email.gif";
    }

    if ($filters_list{'Enabled'}[$i] eq 'Y' || $filters_list{'Enabled'}[$i] eq 'y'){
	$status = "<span class=text_enabled>$text{'group_cf_rule_enabled'}</span>";
    } else {
    	$status = "<span class=text_disabled>$text{'group_cf_rule_disabled'}</span>";
    }

    $Action = $filters_list{'Action'}[$i];
    $Action =~ s/\(.*//;
   
    my $condition = lc($filters_list{'Condition'}[$i]);
    $condition =~ s/-/ /;
    if ($condition =~ /greater/)
    {
	my $value = $filters_list{'Value'}[$i];
	if ( !($value%1024) )
        {
                # we might have KB
                $value = $value/1024;
                $filters_list{'Value'}[$i] = $value."K";
                if ( !($value%1024) )
                        {
                                # we might have MB
                                $value = $value/1024;
				$filters_list{'Value'}[$i] = $value."M";
                                if ( !($value%1024) )
                                        {
                                                        # we might have GB
                                                        $value = $value/1024;
							$filters_list{'Value'}[$i] = $value."G";
                                        }
                        }
        }
    } 
    
    


    $applied_to = "";
    if ($filters_list{'Type'}[$i] eq 'header'){
	$applied_to = "header: ".$filters_list{'Header_Name'}[$i];
    } else {
    	$applied_to = $filters_list{'Type'}[$i];
    }
    
    $filter_name = $filters_list{'Name'}[$i];
    if (length ($filter_name)>25){
	$filter_name = substr($filter_name, 0, 25)."...";
    }

    if ($condition =~ /exist/){
        $filters_list_value = "";
    } else {
	$filters_list_value = "\"$filters_list{'Value'}[$i]\"";
    }
    
    print 	"<td width=\"20\"><input type=checkbox name=\"rules\" value=\"$filters_list{'Rule'}[$i]\" /></td>";
    print 	"<td width=\"20\"><img src=\"images/new/icons/$file_icon\" /></td>";
    print 	"<td><a href=\"parse_policies.cgi?group=$group_url&action=edit_rule&rule_number=$filters_list{'Rule'}[$i]\">$filter_name</a></td>";
    print 	"<td width=\"40\">$status</td>";
    print 	"<td>$applied_to</td>";
    print 	"<td>$condition $filters_list_value</td>";
    print 	"<td width=\"100\" nowrap>$Action</td>";
    print 	"<td width=\"50\" nowrap>
		    <a href=parse_policies.cgi?group=$group&action=filters&first=$filters_list{'Rule'}[$i]>
		    <img src=\"images/new/icons/first.gif\" border=0/></a>
	    	    <a href=parse_policies.cgi?group=$group&action=filters&up=$filters_list{'Rule'}[$i]>
		    <img src=\"images/new/icons/up.gif\" border=0/></a>
		    <a href=parse_policies.cgi?group=$group&action=filters&down=$filters_list{'Rule'}[$i]&count=$#{$filters_list{'Name'}}>
		    <img src=\"images/new/icons/down.gif\" border=0/></a>
		    <a href=parse_policies.cgi?group=$group&action=filters&last=$filters_list{'Rule'}[$i]&count=$#{$filters_list{'Name'}}>
		    <img src=\"images/new/icons/last.gif\" border=0/></a>
		</td>";
    print "</tr>";
}
    
print <<EOF;
	    </table>
    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <input type="button" name="add_button" class="button" value="Add filter" onClick="location='parse_policies.cgi?group=$group&action=add_rule&rules_count=$#{$filters_list{'Name'}}';">&nbsp;
		    <input type="submit" name="remove_button" class="button" value="Remove">&nbsp;
		    <input type="submit" name="enable_button" class="button" value="Enable">&nbsp;
		    <input type="submit" name="disable_button" class="button" value="Disable">&nbsp;
		    
		    <!--input type="submit" class="button" value="Import filters">&nbsp;
		    <input type="submit" class="button"  value="Export filters">&nbsp;-->
		    
		</td>
	    </tr>
	    </form>
	</table>
    </td>
</tr>

EOF

}

sub draw_group_settings_footer
{
print <<EOF;
	    </table>
    	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td><input class="button" type="submit" value="Apply" />&nbsp;</td>
		</form>
	    </tr>
	</table>
    </td>
</tr>

EOF
}

sub draw_group_settings_antivirus
{

my $group_url = shift;
my $actions = shift;
my $actions_switch = shift;
my $av_scanning_enable_check = shift;

my $sameactions_enable_check = shift;

print <<EOF;	
	<td>
	<a name=av></a>
	<table height="220" cellspacing="0" cellpadding="1" width="200" border="0">
	    <tr>
		<td>
	<form action="parse_policies.cgi?group=$group_url&action=settings_apply" method="POST">
	<fieldset class="fieldset_3columns">
	    <legend>$text{'group_antivirus'}</legend>
			<input class="checkbox" type="checkbox" name="scan_enable" id="scan_enable" value="Y" $av_scanning_enable_check /> <label class="checkbox" for="scan_enable" >$text{'group_av_enable'}</label>
	    		<input type="hidden" name="initial_scan_enable" value="$av_scanning_enable_check" /><br />
	    		<input class="checkbox" type="checkbox" name="sameactions_enable" id="sameactions_enable" value="Y" $sameactions_enable_check /> <label class="checkbox" for="sameactions_enable" >$text{'group_av_sameactions'}</label>
			<input type="hidden" name="initial_sameactions_enable" value="$sameactions_enable_check" />
<br/><br/>
<table>
    <tr>
EOF

my $url = "parse_policies.cgi?group=".$group_url."&";
&draw_settings_actions($url, "virus", $actions, $actions_switch);

print <<EOF;	
    </tr>
</table>
	</fieldset>
	
		</td>
	    </tr>
	    <tr>
		<td>&nbsp;&nbsp; <input class="button"  type="button" value="$text{'advanced_button'}" onClick="location='advanced_policies.cgi?group=$group_url&section=antivirus';" /> 
		</td>
	    </tr>
	</table>
	</td>
EOF
}

sub draw_group_settings_antispam
{
my $group_url = shift;
my $checkbox_values = shift;
my ($as_enable_check) = @{$checkbox_values};
my $actions = shift;
my $actions_switch = shift;

my $user_disabled = "disabled";
if ( $group_url eq "Default" )
	{
		$user_disabled = "";
	}

print <<EOF;
<td>
	<a name=as></a>
<table height="220" cellpadding="1" cellspacing="0" width="180" style="float:left" border=0>
<tr>
    <td>
        <fieldset class="fieldset_3columns" style="width:180px;">
                <legend>$text{'group_antispam'}</legend>
                <input class="checkbox" type="checkbox" name="antispam" id="antispam" value="Y" $as_enable_check />
		<label class="checkbox" for="antispam" >$text{'group_as_enable'}</label>
		<input type="hidden" name="initial_antispam" value="$as_enable_check" />
<br/><br/>
<table>
    <tr>
EOF
			my $url = "parse_policies.cgi?group=".$group_url."&";
			&draw_settings_actions($url, "antispam", $actions, $actions_switch);
print <<EOF
    </tr>
</table>
	        </fieldset>
		</td>
	    </tr>
	    <tr>
		<td>
		    &nbsp;&nbsp; <input class="button" type="button" value="$text{'advanced_button'}" onClick="location='advanced_policies.cgi?group=$group_url&section=antispam';" /> 
		</td>
	    </tr>
	</table>
</td>	
EOF
}

sub draw_group_settings_mf
{
my ($group_url, $mf_mail_forward, $mf_ip, $mf_helo, $mf_from, $mf_rcpt, $mf_forwardafter_check, 
    $mf_forwardbefore_check, $mf_forward) = @_;
print <<EOF;
<td>
<a name=mf></a>
<table height="210" cellpadding="1" cellspacing="0" width="240" style="float:left">
<tr>
    <td>
<fieldset class="fieldset_3columns" style="width:240px;">
    <legend>$text{'group_mf'}</legend>
    <input class="checkbox" type="checkbox" name="mail_forward" id="mail_forward" value="Y" $mf_mail_forward />
    <label class="checkbox" for="mail_forward" >$text{'group_mf_enable'}</label>
    <input type="hidden" name="initial_mail_forward" value="$mf_mail_forward" />
    <br />
    <br />
    
    <b>$text{'group_mf_when'}</b>
    <br/>
    <input class="radio" type="radio" name="mf_when" id="mf_after" value="AfterScan" $mf_forwardafter_check /> <label class="radio" for="mf_after" >$text{'group_mf_afterscan'}</label>
    <input type="hidden" name="initial_mf_when" value="$mf_forward" />&nbsp;
    <input class="radio" type="radio" name="mf_when" id="mf_before" value="BeforeScan" $mf_forwardbefore_check /> <label class="radio" for="mf_before" >$text{'group_mf_beforescan'}</label>
    <br />
		
    <br />
    <b>$text{'group_mf_where'}</b>
    <table border="0" cellspacing="1" cellpadding="0" width="100%">
        <tr>
	    <td>$text{'group_mf_ip'}</td>
	    <td><input class="input_edit" type="text" name="mailfw_ip" value="$mf_ip" /> <input type="hidden" name="initial_mailfw_ip" value="$mf_ip" /></td>
	</tr>
        <tr>
	    <td>$text{'group_mf_helo'}</td>
	    <td><input class="input_edit" type="text" name="mailfw_helo" value="$mf_helo" /> <input type="hidden" name="initial_mailfw_helo" value="$mf_helo" /></td>
	</tr>
	<tr>
            <td>$text{'group_mf_from'}</td>
    	    <td><input class="input_edit" type="text" name="mailfw_from" value="$mf_from" /> <input type="hidden" name="initial_mailfw_from" value="$mf_from" /></td>
	</tr>
	<tr>
            <td>$text{'group_mf_dest'}</td>
	    <td valign="top"><input class="input_edit" type="text" name="mailfw_rcpt" value="$mf_rcpt" /> <input type="hidden" name="initial_mailfw_rcpt" value="$mf_rcpt" /></td>
	</tr>
    </table>
</fieldset>
</td>
</tr>
</tr>
</table>
</td>
EOF
}

sub draw_group_settings_users
{
my ( $group_url, $senders, $recipients ) = @_;
$senders = &html_escape($senders);
$recipients = &html_escape($recipients);
print <<EOF;
<td colspan=3>

	        <fieldset class="fieldset_1column">
	        <legend>$text{'group_users'}</legend>
	            <table>
			<form action="parse_policies.cgi?group=$group_url&action=users_apply#users" method="POST">
		            <tr>
    	    			<td><label class="text">$text{'group_senders'}</label></td>
			        <td><label class="text">$text{'group_recipients'}</label></td>
			    </tr>
		            <tr>
				<td><textarea name="senders" cols=20 rows=6>$senders</textarea>
			        <input type="hidden" name="initial_senders" value="$senders" /></td>
    		    	
				<td><textarea name="recipients" cols=20 rows=6 >$recipients</textarea>
				<input type="hidden" name="initial_recipients" value="$recipients" /></td>
		    	    </tr>
			    <tr>
				<td colspan=2><input class="button" type="submit" value="$text{'apply_button'}" /></td>
			    </tr>
			</form>
    		    </table>
		</fieldset>
</td>
</tr>
EOF


}

sub draw_groups
{
my ( $groups, $groups_check ) = @_;
print <<EOF;             
<td></td></tr></table>
    <form action="parse_groups.cgi?action=parse_groups" method="POST">
    <table cellspacing="0" cellpadding="1" width="100%">
	<tr class="container_table_header">
	    <td class="container_table_header" width="20">&nbsp;</td>
    	    <td class="container_table_header"><b>Group name</td>
	    <td class="container_table_header" width="60">&nbsp;</td>
	</tr>
EOF

for $i ( 0 .. $#{$groups} )
	{
	my $groups_url = &urlize(${$groups}[$i][0]);
	print "<tr>";
        print "<td width=\"20\"><input class='checkbox' type='checkbox' name='check_group' value='$groups_url' ${$groups_check}[$i] /></td>";
        print "<td><input class='input_edit' type='text' name='groupname' style='width:300px;' value='${$groups}[$i][0]' /></td>";
	print "<td width=\"60\"><a href=parse_policies.cgi?group=$groups_url>$text{'groups_edit'}</a></td>";
	print "<input type='hidden' name='priority' value='${$groups}[$i][1]'>\n";
        print "<input type='hidden' name='initial_groupname' value='$groups_url'></tr>";

	}
print <<EOF;
    </table>
    </td>
</tr>

	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
		    <table cellspacing="0" cellpadding="0">
			<tr>
		    	    <td>
		    		<input class="small_button" type="submit" name=up_button value="$text{'up_button'}" />
		    		<input class="small_button" type="submit" name=down_button value="$text{'down_button'}" />
			        <input class="small_button" type="submit" name=remove_button value="$text{'remove_button'}" />
			        <input class="small_button" type="submit" name=rename_button value="$text{'rename_button'}" />
			        <input class="button" type="submit" name=import_button value="$text{'import_button'}" />
			    </td>
			</form>
			<form action="parse_groups.cgi?action=add_group" method="POST">
			    <td width="10">&nbsp;</td>
			    <td>
		    		<input class="input_edit" type="text" name=newgroup value="" />&nbsp;
		    		<input class="button" type="submit" value="$text{'add_button'}" />
		    	    </td>
    			</form>
			</tr>
		    </table>

		</td>
	    </tr>
	</table>
    </td>
</tr>


EOF
}
