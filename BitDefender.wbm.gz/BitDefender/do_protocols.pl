#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_protocols.pl';
require
	'./do_common_policies.pl';
	
my @samba_actions_switch = ( "on", "off", "off", "off", "off", "off");
my %samba_actions_priorities = ( none => 	 0,
				 disinfect =>    1,
                		 quarantine =>   2,
                		 delete => 	 3,
                		 deny => 	 4,
                		 ignore => 	 4);

sub do_smtp
{
&draw_smtp_header;
my $no_integration = 1;
#check for Communigate
if ( -x "${bitdefender_dir}/bin/bdcgated" )
{
	if ( &verify_check("/BDUX/Agents/CommuniGate/CommuniGateAgentEnabled") eq "checked" )
	{
	my $cgt_path = &BDReg_GetKeys ("/BDUX/Agents/CommuniGate/BaseDirectory");
	my $cgt_threads = &BDReg_GetKeys ("/BDUX/Agents/CommuniGate/Threads");
	my $cgt_timeout = &BDReg_GetKeys ("/BDUX/Agents/CommuniGate/Timeout");
	$no_integration = 0;
	#we have to validate the keys
	&draw_protocols_communigate($cgt_path, $cgt_threads, $cgt_timeout);
	}
}
	
#check for Courier
if ( -x "${bitdefender_dir}/bin/bdcourier" )
{
	if ( &verify_check("/BDUX/Agents/Courier/CourierAgentEnabled") eq "checked" )
	{
	my $courier_path = &BDReg_GetKeys ("/BDUX/Agents/Courier/SubmitPath");
	$no_integration = 0;
	#we have to validate the key
	&draw_protocols_courier($courier_path);
	}
}

#check for Sendmail Milter
if ( -x "${bitdefender_dir}/bin/bdmilterd" )
{
	if ( &verify_check("/BDUX/Agents/Milter/MilterAgentEnabled") eq "checked" )
	{
	my $milter_sock_path = &BDReg_GetKeys ("/BDUX/Agents/Milter/SockPath");
	$no_integration = 0;
	#we have to validate the key
	&draw_protocols_milter($milter_sock_path);
	}
}

#check for qmail
if ( &verify_check("/BDUX/Agents/Qmail/QmailAgentEnabled") eq "checked" )
{
	#we have to validate the key
	my $qmail_path = &BDReg_GetKeys ("BDUX/Agents/Qmail/QmailQueuePath");
	$no_integration = 0;
	&draw_protocols_qmail($qmail_path);
}

#check for smtp proxy
if ( -x "${bitdefender_dir}/bin/bdsmtpd" )
{
	if ( &verify_check("/BDUX/Agents/SmtpProxy/SMTPAgentEnabled") eq "checked" )
	{
	my @smtpd_networks_mask;
	my $smtp_server_info = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/SMTPServer");
	my ($smtp_server_addr, $smtp_server_port) = split(/:/,$smtp_server_info);
	my $smtpd_port = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/Port");
	my $smtpd_timeout = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/Timeout");
	my $smtpd_threads = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/Threads");
	my $smtpd_mailsize = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/MaxMailSize");

	my $smtpd_tmp_interfaces = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/Interfaces/");
	my @smtpd_interfaces = split(/\n/,$smtpd_tmp_interfaces);

	my $smtpd_tmp_networks = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/TrustedNetworks/");
	my @smtpd_networks = split(/\n/,$smtpd_tmp_networks);
	for $i ( 0 .. $#smtpd_networks )
		{
			$smtpd_networks_mask[$i] = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/TrustedNetworks/$smtpd_networks[$i]");
		}

	my $smtpd_tmp_domains = &BDReg_GetKeys ("/BDUX/Agents/SmtpProxy/RelayDomains/");
	my @smtpd_domains = split(/\n/,$smtpd_tmp_domains);
	$no_integration = 0;
	#we have to validate the keys
	&draw_protocols_smtp($smtp_server_addr, $smtp_server_port, $smtpd_port, $smtpd_timeout, $smtpd_threads,
				$smtpd_mailsize, \@smtpd_interfaces, \@smtpd_networks, \@smtpd_networks_mask, \@smtpd_domains);
	}
}

if ( $no_integration )
{
	# There is no MTA integration yet
	&draw_protocols_no_integration;
}

&draw_smtp_footer;
}

sub do_samba
{
	my $samba_sameactions = &BDReg_GetKeys("BDUX/FileDaemon/Actions/UseInfectedOnAll");
	if ( $samba_sameactions eq "ERR_KEY_DOES_NOT_EXIST" )
	{
	# Check if all actions are the same
	my $infected_actions = &BDReg_GetKeys("BDUX/FileDaemon/Actions/OnInfected");
	my $suspected_actions = &BDReg_GetKeys("BDUX/FileDaemon/Actions/OnSuspected");
	my $riskware_actions = &BDReg_GetKeys("BDUX/FileDaemon/Actions/OnRiskware");
	# If they are the same we use by default infected actions for all
	if ( ($infected_actions eq $suspected_actions ) && ($suspected_actions eq $riskware_actions) )
		{
			&BDReg_SetKey("BDUX/FileDaemon/Actions/UseInfectedOnAll","Y");
			$samba_sameactions = "checked";
		}
	else 
		{
			&BDReg_SetKey("BDUX/FileDaemon/Actions/UseInfectedOnAll","N");
			$samba_sameactions = "";
		}
	}
	elsif( ($samba_sameactions eq "y") || ($samba_sameactions eq "Y") )
	{
		$samba_sameactions = "checked";
	}
	else
	{
		$samba_sameactions = "";
	}
my ($all_infected_actions, $all_suspected_actions, $all_riskware_actions) = ("", "", "");
my ($infected_actions_switch, $suspected_actions_switch, $riskware_actions_switch) = ("", "", "");

	# If we use the same actions for all, we don't get the data
	# for suspected and riskware
	if ($samba_sameactions eq "checked")
	{
	($all_infected_actions, $infected_actions_switch) = 
		&get_actions_data("BDUX/FileDaemon/Actions/OnInfected", "BDUX/FileDaemon/Actions/AllOnInfected", "samba", "");
	($all_suspected_actions, $suspected_actions_switch, $all_riskware_actions, $riskware_actions_switch) = 
		( "", "", "", "");
	}
	else
	{
	# The actions are different for each type
	($all_infected_actions, $infected_actions_switch) = 
	     &get_actions_data("BDUX/FileDaemon/Actions/OnInfected", "BDUX/FileDaemon/Actions/AllOnInfected", "samba", "");
	($all_suspected_actions, $suspected_actions_switch) = 
	     &get_actions_data("BDUX/FileDaemon/Actions/OnSuspected", "BDUX/FileDaemon/Actions/AllOnSuspected", "samba", "");
	($all_riskware_actions, $riskware_actions_switch) = 
	     &get_actions_data("BDUX/FileDaemon/Actions/OnRiskware", "BDUX/FileDaemon/Actions/AllOnRiskware", "samba", "");
	}
	
	my $samba_extensions =  &BDReg_GetKeys ("BDUX/FileDaemon/Targets/Extensions");

	my $samba_maxfilesize = &BDReg_GetKeys ("BDUX/FileDaemon/Targets/MaximumSize");
	$samba_maxfilesize = $samba_maxfilesize / 1024;
	&draw_protocols_samba($all_infected_actions, $infected_actions_switch, 
		$all_suspected_actions, $suspected_actions_switch, 
		$all_riskware_actions, $riskware_actions_switch, 
		$samba_extensions, $samba_maxfilesize, $samba_sameactions)
}

