#!/usr/bin/perl

sub draw_header
{

my $selected_menu = shift;
my $selected_submenu = shift;	

$usragnt = $ENV{'HTTP_USER_AGENT'};

$bd_head = "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />";
$bd_head.= "<link rel='shortcut icon' href='favicon.ico' />";
$bd_head.= "<script type='text/javascript' language='javascript' src='scripts/scripts.js'></script>";


if ($usragnt=~ /Konqueror/){
    $bd_head.= "<link rel='stylesheet' title='Default' type='text/css' href='css/styles_kq.css' />";
}elsif ($usragnt=~ /Gecko/){
    $bd_head.= "<link rel='stylesheet' title='Default' type='text/css' href='css/styles_gk.css' />";
}elsif ($usragnt=~ /Opera/){
    $bd_head.= "<link rel='stylesheet' title='Default' type='text/css' href='css/styles_op.css' />";
}elsif ($usragnt=~ /Safari/){
    $bd_head.= "<link rel='stylesheet' title='Default' type='text/css' href='css/styles_op.css' />";
}elsif ($usragnt=~ /MSIE/){
    $bd_head.= "<link rel='stylesheet' title='Default' type='text/css' href='css/styles_ie.css' />";
}


&header($text{'header_title'},"","","","","","", $bd_head,"","");

print <<EOF;
	<body bgcolor="#787878" onResize="adjustTabs();">
	    <table width="100%" height="100%" border="0">
	    	<tr>
		    <td align="center">
			<table cellspacing="0" cellpadding="0" width="758" height="478">
			    <tr height="4">
				<td colspan="3"></td>					
			    </tr>
			    <tr height="470">
				<td width="1"></td>					
				<td width="750">
				    <table width="750" height="470" cellpadding="0" cellspacing="0" class="table_container" border="0">
					<tr>
					    <td class="header_top"><img src="images/new/s.gif" height="47" width="1" /></td>
					</tr>
					<tr>
					    <td class="header_menu">
						<table width="100%" class="menu_table" cellspacing="0" cellpadding="0" border=0>
						    <tr>
							<td>
EOF
							    &create_menu($selected_menu, $selected_submenu);
print <<EOF;
							</td>
							<td align="right">
EOF
							    &draw_help($selected_menu, $selected_submenu);

print <<EOF;						
							    &nbsp;&nbsp;|&nbsp;<a href="$gconfig{'webprefix'}/session_login.cgi?logout=1">Logout</a>&nbsp;&raquo;
							</td>
						    </tr>
						</table>
					    </td>
					</tr>
					<tr>
					    <td class="content" align="center" valign="top">
					
EOF
}

sub draw_footer
{

print <<EOF;
				    </table>
				</td>					
				<td width="1"></td>				
			    </tr>
			    <tr height="4">
				<td colspan="3"></td>					
			    </tr>
			</table>					
		    </td>
		</tr>
	    </table>
	</body>
EOF

&footer("", $text{'index_return'});
}


sub draw_tabs
{
my $title 	= shift;
my $main_menu 	= shift;
my $active 	= shift;
print <<EOF;
    	<div id="page_header">
    	    <table cellspacing="0" cellpadding="0" width="100%" height="30" class="page_header">
		<tr>
		    <!--[if IE]>
			<style>
			.page_header td {padding-left: 23px;}
			</style>
		    <![endif]-->
		    <td valign="bottom" nowrap>
EOF

&create_menu_tabs($main_menu,$active);

print <<EOF;
		    </td>
		    <td align="right" width="170" nowrap>
			$title
		    </td>
		</tr>
	    </table>
	</div>
	<div id="page_container">									    
	
EOF
}



sub draw_help
{
my ($menu, $submenu) = @_;

$open_address = "lang/help/en/radmin.".$menu.".html#radmin.".$menu.".".$submenu;
# The $open_addres should look like this:
# lang/help/en/radmin.status.html#radmin.status.services

print <<EOF;
<a onclick='window.open("$open_address", "help", "toolbar=no,menubar=no,status=no,scrollbars=yes,width=300,height=500,resizable=yes", "true"); return false' href="$open_address" class="">Help</a> 
EOF

}

sub bd_file_chooser_button
{
local $form = defined($_[2]) ? $_[2] : 0;
local $chroot = defined($_[3]) ? $_[3] : "/";
local $add = int($_[4]);
return "<input class=button type=button onClick='ifield = form.$_[0]; chooser = window.open(\"./bd_chooser.cgi?add=$add&type=$_[1]&chroot=$chroot&file=\"+escape(ifield.value), \"chooser\", \"toolbar=no,menubar=no,scrollbar=no,width=400,height=300\"); chooser.ifield = ifield; window.ifield = ifield' value=\"Browse\">\n";
}


sub draw_settings_actions
{
my $url = shift; 
my $actions_type = shift;
my $actions_ref = shift;
my @actions = @$actions_ref;
my $actions_switch_ref = shift;
my %actions_switch = %$actions_switch_ref;


my $actions_count = $#actions;
if ( $actions_count == 0 )
{
# There is only one action present in the registry
print <<EOF;
<a name=#_actions></a>
<!--fieldset-->
        <h4>$text{$actions_type.'_actions'}</h4>
        <div class="action_stack">
                <img src='images/down_disabled.png' border='0' valign='center'/>
                <img src='images/up_disabled.png' border='0' valign='center'/>
                <span class='action_active'>$text{$actions[0]}</span>
        </div>
<--fieldset-->
EOF
}
else
{
# There are more than one action in the registry
# The first action is always on and has the Up button disabled
print <<EOF;
<a name=#_actions></a>
<!--fieldset-->
	<td>
    	    <span><b>$text{$actions_type.'_actions'}</b></span>
	    <div class="action_stack">
		<a href='${url}action=${actions_type}_actions&down=0&moving=$actions[0]#av'>
		<img src='images/down.png' border='0' valign='center'/></a>
		<img src='images/up_disabled.png' border='0' valign='center'/>
EOF
		if ( $actions_switch{$actions[0]} eq "off" )
			{
			print "<span class='action_inactive'>$text{$actions[0]}</span></div>";
			}
		else
			{
			print "<span class='action_active'>$text{$actions[0]}</span></div>";
			}
# Draw the following actions, without the last one
	for $i ( 1 .. $actions_count-1 )
		{
print <<EOF;
	<div class="action_stack">
		<a href='${url}action=${actions_type}_actions&down=$i&moving=$actions[$i]#av'>
		<img src='images/down.png' border='0' valign='center'/></a>
		<a href='${url}action=${actions_type}_actions&up=$i&moving=$actions[$i]#av'>
		<img src='images/up.png' border='0' valign='center'/></a>
EOF
		if ( $actions_switch{$actions[$i]} eq "off" )
			{
			print "<span class='action_inactive'>$text{$actions[$i]}</span></div>";
			}
		else
			{
                        print "<span class='action_active'>$text{$actions[$i]}</span></div>";
                        }	
		}
# The last action has the Down button disabled
print <<EOF;
	<div class="action_stack">
		<img src='images/down_disabled.png' border='0' valign='center'/>
		<a href='${url}action=${actions_type}_actions&up=$actions_count&moving=$actions[$actions_count]#av'>
		<img src='images/up.png' border='0' valign='center'/></a>
EOF
                if ( $actions_switch{$actions[$actions_count]} eq "off" )
                        {
                        print "<span class='action_inactive'>$text{$actions[$actions_count]}</span></div>";
                        }
                else                                                                                                                                   {
                        print "<span class='action_active'>$text{$actions[$actions_count]}</span></div>";
                        }
print "</td>";
}

}

sub draw_settings_actions_disabled
{
# Does the same thing as the above function but with all 
# the arrows disabled (used when virus actions are used
# for all malware
my $actions_type = shift;

my $actions_ref = shift;
my @actions = @$actions_ref;

my $actions_switch_ref = shift;
my %actions_switch = %$actions_switch_ref;

my $actions_count = $#actions;

print <<EOF;
<a name=#_actions></a>
    <td>              
        <span><b>$text{$actions_type.'_actions'}</b></span>
EOF
for $i ( 0 .. $actions_count )
                {
print <<EOF;
        <div class="action_stack">
                <img src='images/down_disabled.png' border='0' valign='center'/>
                <img src='images/up_disabled.png' border='0' valign='center'/>
EOF
                if ( $actions_switch{$actions[$i]} eq "off" )
                        {
                        print "<span class='action_inactive'>$text{$actions[$i]}</span></div>";
                        }
                else
                        {
                        print "<span class='action_active'>$text{$actions[$i]}</span></div>";
                        }
                }
# The last action has the Down button disabled
print "</td>";
}

1;
