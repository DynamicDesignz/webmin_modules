#!/usr/bin/perl
require 
	'./bitdefender-lib.pl';
require 
	'./draw_policies.pl';
require 
	'./do_common_policies.pl';

sub do_ldap_import_new_name
{
	my ($new_name, $initial_ldap_name, $type) = @_;
	if (&group_existance($new_name))
	{
		&draw_header("policies", "groups");
		&draw_tabs ( $text{"groups"}, "policies", "groups");
		&draw_group_settings_header();

		&draw_ldap_import_group($initial_ldap_name, "10", $type, "true");
		
		&draw_footer();
	}
	else
	{
		my $output = &bdsafe_run_output("ldap group import \"$initial_ldap_name\" \"$type\" \"$new_name\"");
		&do_groups;
	}
}
sub do_ldap_import_group
{
    my ($selected_group, $type) = @_;
    
    
    &draw_header("policies", "groups");
    &draw_tabs ( $text{"groups"}, "policies", "groups");
    &draw_group_settings_header();
    
    
    
    $count_users = 0;
    if ($selected_group ne ""){
	$group_name = &un_urlize($selected_group);
        $output = &bdsafe_run_output("ldap group list \"".$group_name."\"");
	@ldap_group_users = split(/\n/, $output);
	$count_users = $#ldap_group_users-2;
    }
    
    # Should get either the group exists or not
    if (&group_existance($selected_group))
    {
	$group_exists = "true";
    }
    else
    {
    	$group_exists = "false";
    }
    
    
    &draw_ldap_import_group($selected_group, $count_users, $type, $group_exists);
    
    &draw_footer();
}

sub do_ldap_groups_list
{
    &draw_header("policies", "groups");
    &draw_tabs ( $text{"groups"}, "policies", "groups");
    &draw_group_settings_header();
    
    my $selected_ldap_group = shift;
    #getting LDAP tree
    my $command = "ldap group list";
    $output = &bdsafe_run_output($command);
    
    my @ldap_tree = split(/\n/, $output );
    my @ldap_group_users;
    $selected_ldap_group = &un_urlize($selected_ldap_group);
    if ($selected_ldap_group ne ""){
	$output = &bdsafe_run_output("ldap group list \"".$selected_ldap_group."\"");
	@ldap_group_users = split(/\n/, $output);
    }
    
    &draw_ldap_groups_list(\@ldap_tree, $selected_ldap_group,\@ldap_group_users);
    
    
    &draw_footer();
    
    
}

sub do_ldap_settings
{
    &draw_header("policies", "groups");
    &draw_tabs ( $text{"groups"}, "policies", "groups");
    &draw_group_settings_header();
    
    my ($ldap_server_address, $ldap_root_node, $ldap_username, $ldap_use_registry_password, $ldap_error) = @_;
    
    &draw_ldap_settings($ldap_server_address, $ldap_root_node, $ldap_username, $ldap_use_registry_password, $ldap_error);
    
    &draw_footer();
}

sub do_groupsettings
{
# Get and draw the default settings for a given group
my $group = shift;
my $group_url = &urlize($group);
my $group_exists = "no";
my $test_actions = "";
my ($all_virus_actions, $virus_actions_switch) = ("", "");
my ($all_as_actions, $as_actions_switch) = ("", "");

my $groups_entries = &BDReg_GetKeys ( "BDUX/GroupManagement/Groups/");
my @registered_groups =  split(/\n/, $groups_entries );
# Check if the group exists
foreach $registered_group ( @registered_groups )
	{
		if ( $group eq $registered_group ) 
		{
			$group_exists = "yes";
			last;
		}
	}

if ( $group_exists eq "no" )
{
	&do_groups();
	return 0;
}





if ( $group eq "Default" )
	{ 
		&draw_header("policies", "defsett");
		&draw_tabs ( $text{"defsett"}, "policies", "defsett"); 
	}
else
	{ 
		&draw_header("policies", "groups");
		&draw_tabs ( $group." ".$text{"group_settings"}, "policies", "groups"); 
	}

&draw_group_settings_header($group);

# Get group antivirus and footer settings from registry
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# Get actions settings and determine which action is active and which not
$test_actions = &BDReg_GetKeys ($groups_root.$group."/Settings/Antivirus/ActionsOnVirus");
($all_virus_actions, $virus_actions_switch) = &get_actions_data("/Settings/Antivirus/ActionsOnVirus", 
				"/Settings/Antivirus/AllActionsOnVirus", "antivirus", $group);	

# Get the other antivirus settings (checkboxes)
my $av_scanning_enable_check = 	&verify_group_check( $group, "/Settings/Antivirus/Enable"); 
my $sameactions_enable_check = &group_getkey( $group, "/Settings/Antivirus/UseVirusActionsOnAll");
if ( $sameactions_enable_check eq "ERR_KEY_DOES_NOT_EXIST" )
	{
		# We check if all the malware actions are the same
		my $virus_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnVirus" );
		my $riskware_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnRiskware" );
		my $suspected_actions = &group_getkey( $group, "/Settings/Antivirus/ActionsOnSuspected" );
		# If they are the same then we use by default all virus actions for all malware
		if ( ( $virus_actions eq $riskware_actions ) && ( $riskware_actions eq $suspected_actions ) )
			{
			&BDReg_SetKey($groups_root.$group."/Settings/Antivirus/UseVirusActionsOnAll", "Y");
			$sameactions_enable_check = "checked";
			}
		else
			{
			&BDReg_SetKey($groups_root.$group."/Settings/Antivirus/UseVirusActionsOnAll", "N");
			$sameactions_enable_check = "";
			}
	}
elsif ( ( $sameactions_enable_check eq "y" ) || ( $sameactions_enable_check eq "Y" ) )
	{
		$sameactions_enable_check = "checked";
	}
else 
	{
		 $sameactions_enable_check = "";
	}

# Get group antispam settings from registry
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
my @checkbox_values;
my @checkbox_keys = ( "/Settings/Antispam/Enable");
# The checkbox keys are read in checkbox_values in the following order:
# $as_enable_check, $blacklist_enable_check, $urlfilter_enable_check, $imagefilter_enable_check
# $bayesfilter_enable_check, $heurfilter_enable_check, $multifilter_enable_check, $rblfilter_enable_check,
# $modifysubject_enable_check, $mailheader_enable_check 
$checkbox_values[0] = &verify_group_check($group, $checkbox_keys[0]);

($all_as_actions, $as_actions_switch) = &get_actions_data("/Settings/Antispam/Actions", 
				"/Settings/Antispam/AllActions", "antispam", $group);

# Get group mail forward settings from registry
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

my $mf_ip	= &group_getkey( $group, "/Settings/SmtpForward/SMTP_IP" );
my $mf_helo	= &group_getkey( $group, "/Settings/SmtpForward/SMTP_HELO" );
my $mf_from	= &group_getkey( $group, "/Settings/SmtpForward/SMTP_FROM" );
my $mf_rcpt	= &group_getkey( $group, "/Settings/SmtpForward/SMTP_RCPT_TO" );
my $mf_forward  = &group_getkey( $group, "/Settings/SmtpForward/When" );
my $mf_mail_forward = &verify_group_check( $group, "/Settings/SmtpForward/Enable" );

# Check the correspondig When radio buttons
if ( $mf_forward eq "BeforeScan" )
	{ 
	$mf_forwardbefore_check = "checked";
	$mf_forwardafter_check = "";
	}
elsif ( $mf_forward eq "AfterScan" )
	{
	$mf_forwardbefore_check = "";
	$mf_forwardafter_check = "checked";
	}

if ( $group ne "Default" )
	{
		
		my $senders = &BDReg_GetKeys( "BDUX/GroupManagement/Groups/$group/Sender");
		my $recipients = &BDReg_GetKeys( "BDUX/GroupManagement/Groups/$group/Recipients");
		$senders =~ s/ERR_KEY_DOES_NOT_EXIST//;
		if ($senders ne "")
			{
			$senders =~ s/,/\n/g;
			$senders = $senders."\n";
			}
		$recipients =~ s/ERR_KEY_DOES_NOT_EXIST//;
		if ($recipients ne "")
			{
			$recipients =~ s/,/\n/g;
			$recipients = $recipients."\n";
			}
		&draw_group_settings_users($group_url, $senders, $recipients);
		
		
		
	}

my $cf_enable_check = &verify_group_check($group, "/Settings/ContentFilter/Enable");

&draw_group_settings_antivirus($group_url, $all_virus_actions, $virus_actions_switch, 
			      $av_scanning_enable_check, $sameactions_enable_check);
&draw_group_settings_antispam($group_url, \@checkbox_values,  $all_as_actions, $as_actions_switch);
&draw_group_settings_mf($group_url, $mf_mail_forward, $mf_ip, $mf_helo, $mf_from, $mf_rcpt, 
			$mf_forwardafter_check, $mf_forwardbefore_check,$mf_forward);
&draw_group_settings_content_filtering($group_url, $cf_enable_check);
&draw_group_settings_footer();
&draw_footer();
}

sub do_groups
{

&draw_header("policies", "groups");
&draw_tabs ( $text{"groups"}, "policies", "groups");
&draw_group_settings_header();

$groups_check_array = shift;

my $groups_entries = &BDReg_GetKeys ( "BDUX/GroupManagement/Groups/");
my @groups =  split(/\n/, $groups_entries );
# Take out the default group
for $i (0 .. $#groups)
{
	if ($groups[$i] eq "Default")
		{
			splice (@groups, $i, 1);
			last;
		}
}	
# Build an array which contains group name and its priority on every line
# The array should not contain the Default group
for $i ( 0 .. $#groups )
	{
		my $tmp = &BDReg_GetKeys ( "BDUX/GroupManagement/Groups/$groups[$i]/Priority" );
		push @groups_array, [$groups[$i], $tmp];
	}
# We sort groups array in priority order
@groups_array = sort { $a->[1] <=> $b->[1] } @groups_array;
&draw_groups (\@groups_array, $groups_check_array);
&draw_footer();
}

sub do_group_content_filtering
{
my $group = shift;
my $group_url = &urlize($group);
my %filters_info;

if ( $group eq "Default" )
	{ 
		&draw_header("policies", "defsett");
		&draw_tabs ( $text{"defsett"}, "policies", "defsett"); 
	}
else
	{ 
		&draw_header("policies", "groups");
		&draw_tabs ( $group." ".$text{"group_settings"}, "policies", "groups"); 
	}

&draw_group_settings_header($group);

for ( `$bitdefender_dir/bin/bdsafe group configure \"$group\" contentfilter dump` )
{

	 
	 $_ =~ s/\"/%22/g;
	 $_ =~ s/\'/%27/g;
	 
         $_ =~ s|^(.*): ?(.*)$|\$filters_info{\'$1\'}\[\$idx_$1++\] = \'$2\';|mg; #'
         no strict "vars";
         #print "$_"."<br>";
         eval "$_; return(1);";
}

&draw_group_content_filtering($group, $group_url, \%filters_info);
#&draw_group_settings_footer();
&draw_footer();
}

sub do_rule_add_group
{
my $group = shift;
my $rules_count = shift;
if ( $group eq "Default" )
        {
                &draw_header("policies", "defsett");
                &draw_tabs ( $text{"defsett"}, "policies", "defsett");
        }
else
        {
                &draw_header("policies", "groups");
                &draw_tabs ( $group." ".$text{"group_settings"}, "policies", "groups");
        }
&draw_group_settings_header($group);
&draw_group_cf_settings($group, $rules_count);
&draw_footer();
}

sub do_rule_edit_group
{
my $group = shift;
my $rule_number = shift;

if ( $group eq "Default" )
	{ 
		&draw_header("policies", "defsett");
		&draw_tabs ( $text{"defsett"}, "policies", "defsett"); 
	}
else
	{ 
		&draw_header("policies", "groups");
		&draw_tabs ( $group." ".$text{"group_settings"}, "policies", "groups"); 
	}

&draw_group_settings_header($group);

my ($Rule, $Enabled, $Name, $Type, $Header_Name, $Condition, $Value, $Action, $Notify, $Message, $Units) = ("", "", "", "", "", "", "", "", "", "");
for ( `$bitdefender_dir/bin/bdsafe group configure $group contentfilter dump $rule_number` )
	 {
	 
	 $_ =~ s/\"/%22/g;
	 $_ =~ s/\'/%27/g;
         $_ =~ s|^(.*): ?(.*)$|\$$1 = \'$2\';|mg; #'
         no strict "vars";
         eval "$_; return(1);";
	 }

$Action =~ s/^([\w-]*)(\(.*\))?$/\$Action_=\'$1\';\$Message=\'$2\';/m; #'
no strict "vars";
eval "$Action; return(1);";
$Action = $Action_;
$Message =~ s/\(//;
$Message =~ s/\)//;

if ( $Condition =~ /GREATER/ )
{
if ( !($Value%1024) )
	{
		# we might have KB
		$Value = $Value/1024;
		$Units = "K";
		if ( !($Value%1024) )
			{
				# we might have MB
				$Value = $Value/1024;
				$Units = "M";
				if ( !($Value%1024) )
					{
							# we might have GB
							$Value = $Value/1024;
							$Units = "G";
					}
			}
	}
}

&draw_group_cf_settings($group, "", $Rule, $Enabled, $Name, $Type, $Header_Name, $Condition, $Value, $Action, $Notify, $Message, $Units);
&draw_footer();
}
