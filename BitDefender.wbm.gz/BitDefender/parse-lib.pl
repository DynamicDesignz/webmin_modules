#!/usr/bin/perl

sub check_and_configure
{
# This function checks if the new configuration is empty
# if it was changed (edited), it validates it
# and then configures accordingly through bdsafe
my ( $arguments, $value, $initial_value, $validate_function ) = @_;
if ( ($value ne "") && ($value ne $initial_value) )
	{
		if (!defined($validate_function) || &$validate_function($value))
			{
				&bdsafe_run($arguments);
			}
	}
}

sub check_and_configure_box
{
# This function checks if a checkbox has changed
# its state, and sets config accordingly through bdsafe
my ( $arguments, $value, $initial_value, $enable, $disable ) = @_;
if ( ($value eq "Y") && ($initial_value eq "") )
	{
	&bdsafe_run($arguments." ".$enable);
	}
elsif ( ($value eq "") && ($initial_value eq "checked") )
	{
	&bdsafe_run($arguments." ".$disable);
	}
}

sub check_and_write_key
{
# This functions checks if the key is empty,
# if it was changed (edited), it validates the key
# and then it writes it into the registry
my ( $key, $value, $initial_value, $validate_function ) = @_;
if ( ($value ne "") && ($value ne $initial_value) ) 
        {
	if (!defined($validate_function) || &$validate_function($value))
		{
        	&BDReg_SetKey($key,$value);
		}
        }
}

sub check_and_write_key_v2
{
# This functions checks if the key was changed,
# (it doesn't care if it's empty), it validates the key
# and then it writes it into the registry
my ( $key, $value, $initial_value, $validate_function ) = @_;
if ( $value ne $initial_value ) 
        {
	if (!defined($validate_function) || &$validate_function($value) || $value eq "")
		{
        	&BDReg_SetKey($key,$value);
		}
        }
}

sub check_and_write_box
{
# This function checks if a checkbox has changed
# its state, and sets the key accordingly
my ( $key, $value, $initial_value ) = @_;
if ( ($value eq "Y") && ($initial_value eq "") )
	{
	&BDReg_SetKey($key, "Y");
	}
elsif ( ($value eq "") && ($initial_value eq "checked") )
	{
	&BDReg_SetKey($key, "N");
	}
}

sub check_and_write_box_with_value
{
# This function checks if a checkbox has changed
# its state, and sets the key accordingly to $checkedvalue
my ( $key, $value, $initial_value, $checkedvalue, $unchecked_value ) = @_;
if ( ($value eq $checkedvalue) && ($initial_value eq "") )
	{
	&BDReg_SetKey($key, $checkedvalue);
	}
elsif ( ($value eq "") && ($initial_value eq "checked") )
	{
	&BDReg_SetKey($key, $unchecked_value);
	}
}
1;
