#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

sub draw_statistics
{
my ( $maildaemon_enabled, $filedaemon_enabled, $Mails_Scanned, $Mails_Infected, $Mails_Disinfected,
        $Mails_Quarantined, $Mails_Rejected, $Mails_Spam, $Mails_Ignored, $Mails_Dropped, 
	$Files_Scanned, $Files_Infected, $Files_Disinfected, $Files_Quarantined, $Files_Ignored,                               	       $Files_Deleted, $Files_Denied, $Files_CacheHits, $Files_CacheSize) = @_;
	
&draw_header('reports',"statistics");
&draw_tabs($text{'statistics'},'reports',"statistics");
if ($maildaemon_enabled eq "1") {
print <<EOF;
<fieldset class=fieldset_1column>
    <legend>$text{'stats_mails'}</legend>
                                            <table cellspacing="0" cellpadding="3" width="100%">
                                            <tr class="container_table_odd_row"><td width="120"><b>$text{'stats_scanned'}</b></td> <td>$Mails_Scanned</td></tr> 
                                            <tr class="container_table_even_row"><td><b>$text{'stats_infected'}</b></td><td>$Mails_Infected</td></tr>
                                            <tr class="container_table_odd_row"><td><b><b>$text{'stats_disinfected'}</b></td><td>$Mails_Disinfected</td></tr>
                                            <tr class="container_table_even_row"><td><b>$text{'stats_quarantined'}</b></td><td>$Mails_Quarantined</td></tr>
                                            <tr class="container_table_odd_row"><td><b>$text{'stats_rejected'}</b></td><td>$Mails_Rejected</td></tr>
                                            <tr class="container_table_even_row"><td><b>$text{'stats_spam'}</b></td><td>$Mails_Spam</td></tr>
                                            <tr class="container_table_odd_row"><td><b>$text{'stats_ignored'}</b></td><td>$Mails_Ignored</td></tr>
                                            <tr class="container_table_even_row" class="container_table_odd_row"><td><b>$text{'stats_dropped'}</b></td><td>$Mails_Dropped</td></tr>
                                        </table>
					</fieldset>

EOF
}

if ($filedaemon_enabled eq "1"){
print <<EOF;
				<br/>
<fieldset class=fieldset_1column>
    <legend>$text{'stats_files'}</legend>
                                        <table cellspacing="0" cellpadding="3" width="100%">
                                            <tr class="container_table_odd_row"><td width="120"><b>$text{'stats_scanned'}</b></td> <td>$Files_Scanned</td></tr> 
                                            <tr class="container_table_even_row"><td><b>$text{'stats_infected'}</b></td><td>$Files_Infected</td></tr>
                                            <tr class="container_table_odd_row"><td><b><b>$text{'stats_disinfected'}</b></td><td>$Files_Disinfected</td></tr>
                                            <tr class="container_table_even_row"><td><b>$text{'stats_quarantined'}</b></td><td>$Files_Quarantined</td></tr>
                                            <tr class="container_table_odd_row"><td><b>$text{'stats_deleted'}</b></td><td>$Files_Deleted</td></tr>
                                            <tr class="container_table_even_row"><td><b>$text{'stats_denied'}</b></td><td>$Files_Denied</td></tr>
                                            <tr class="container_table_odd_row"><td><b>$text{'stats_ignored'}</b></td><td>$Files_Ignored</td></tr>
                                            <tr class="container_table_even_row" class="container_table_odd_row"><td><b>$text{'stats_cachehits'}</b></td><td>$Files_CacheHits</td></tr>
					    <tr class="container_table_odd_row"><td><b>$text{'stats_cachesize'}</b></td><td>$Files_CacheSize</td></tr>	
                                        </table>
                                    </fieldset>
				    </form>				    

EOF
}
print <<EOF;
					</div>
				    </td>
				</tr>
				<tr>
				    <td class="footer">
					<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
					    <form action="reports.cgi?subcat=statistics" method="POST">
					    <tr>
				    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
						<td><input class="button" type="submit" value="$text{'refresh_button'}" /></td>
					    </tr>
					    </form>
					</table>
				    </td>
				</tr>

EOF
&draw_footer();
}

sub draw_charts
{
my ($Mail_Daemon, $File_Daemon, $bdmaild_graph_file,$bdmaild_graph_all_fields, $bdmaild_graph_checked_fields, 
     $bdmaild_graph_interval, $filed_graph_file, $filed_graph_all_fields, $filed_graph_checked_fields, 
     $filed_graph_interval, $mond_graph_file, $mond_graph_all_fields, $mond_graph_checked_fields, $mond_graph_interval) = @_;

my @bdmond_graph_all_fields_new = @$mond_graph_all_fields;
my %bdmond_graph_checked_fields_new = %$mond_graph_checked_fields;
my $bdmond_interval_new = $mond_graph_interval;

my @bdmaild_graph_all_fields_new = @$bdmaild_graph_all_fields;
my %bdmaild_graph_checked_fields_new = %$bdmaild_graph_checked_fields;
my $bdmaild_interval_new = $bdmaild_graph_interval;

my @bdfiled_graph_all_fields_new = @$filed_graph_all_fields;
my %bdfiled_graph_checked_fields_new = %$filed_graph_checked_fields;
my $bdfiled_interval_new = $filed_graph_interval;

&draw_header('reports',"charts");
&draw_tabs($text{'charts'},'reports',"charts");

print <<EOF;

                                <form action="parse_reports.cgi?action=graph" method="POST">
	    			<fieldset class="fieldset_1column">
	    				<legend>$text{'stats_resources'}</legend>
					
				    <table border=0>
					<tr>
					    <td valign="top">
						<img src="images/$mond_graph_file">
					    </td>
					    <td valign=top>
						<br/><br/>
						<table cellpadding="1" width="100%">
EOF
print "<tr><td>";
print "<select class=input_select name=bdmond_graph_interval>";
print "<option value=1_hour ".($bdmond_interval_new eq "1_hour"?"selected":"").">1 hour</option>";
print "<option value=6_hours ".($bdmond_interval_new eq "6_hours"?"selected":"").">6 hours</option>";
print "<option value=24_hours ".($bdmond_interval_new eq "24_hours"?"selected":"").">24 hours</option>";
print "<option value=1_week ".($bdmond_interval_new eq "1_week"?"selected":"").">1 week</option>";
print "<option value=1_month ".($bdmond_interval_new eq "1_month"?"selected":"").">1 month</option>";
print "<option value=3_months ".($bdmond_interval_new_new eq "3_months"?"selected":"").">3 months</option>";
print "<option value=6_months ".($bdmond_interval_new eq "6_months"?"selected":"").">6 months</option>";
print "<option value=1_year ".($bdmond_interval_new eq "1_year"?"selected":"").">1 year</option>";
print "<option value=3_years ".($bdmond_interval_new eq "3_years"?"selected":"").">3 years</option>";
print "</select>";
print "</td></tr>";

for $i ( 0 .. $#bdmond_graph_all_fields_new )
{

 
print '<tr><td width="100">
		<input class="checkbox" type="checkbox" name="bdmond_graph" value="'.$bdmond_graph_all_fields_new[$i].'" id="bdmond_graph_'.$bdmond_graph_all_fields_new[$i].'" '.$bdmond_graph_checked_fields_new{$bdmond_graph_all_fields_new[$i]}.'  >
		<label class="checkbox" for="bdmond_graph_'.$bdmond_graph_all_fields_new[$i].'" >'.$bdmond_graph_all_fields_new[$i].'</label>
                <input type="hidden" name="initial_bdmond_graph" value="'.$bdmond_graph_checked_fields_new{$bdmond_graph_all_fields_new[$i]}.'" >
<td></tr>';
    
}

print <<EOF;						    
						</table>
					    </td>
					</tr>
                                    </table>    
				</fieldset>
				



EOF
if ( $Mail_Daemon eq "yes" )
{
print <<EOF;
				<fieldset class="fieldset_1column">
					<legend>$text{'stats_mails'}</legend>
					<table>
					    <tr>
						<td valign="top">
						    <img src="images/$bdmaild_graph_file">
						</td>
						<td valign="top">
		
					<table cellpadding="1" width="100%">
EOF

print "<tr><td>";
print "<select class=input_select name=bdmaild_graph_interval>";
print "<option value=1_hour ".($bdmaild_interval_new eq "1_hour"?"selected":"").">1 hour</option>";
print "<option value=6_hours ".($bdmaild_interval_new eq "6_hours"?"selected":"").">6 hours</option>";
print "<option value=24_hours ".($bdmaild_interval_new eq "24_hours"?"selected":"").">24 hours</option>";
print "<option value=1_week ".($bdmaild_interval_new eq "1_week"?"selected":"").">1 week</option>";
print "<option value=1_month ".($bdmaild_interval_new eq "1_month"?"selected":"").">1 month</option>";
print "<option value=3_months ".($bdmaild_interval_new eq "3_months"?"selected":"").">3 months</option>";
print "<option value=6_months ".($bdmaild_interval_new eq "6_months"?"selected":"").">6 months</option>";
print "<option value=1_year ".($bdmaild_interval_new eq "1_year"?"selected":"").">1 year</option>";
print "<option value=3_years ".($bdmaild_interval_new eq "3_years"?"selected":"").">3 years</option>";
print "</select>";
print "</td></tr>";


for $i ( 0 .. $#bdmaild_graph_all_fields_new )
{
 
$tmp = lc($bdmaild_graph_all_fields_new[$i]);
print '<tr><td width="100">
		<input class="checkbox" type="checkbox" name="bdmaild_graph" value="'.$bdmaild_graph_all_fields_new[$i].'" id="bdmaild_graph_'.$bdmaild_graph_all_fields_new[$i].'" '.$bdmaild_graph_checked_fields_new{$bdmaild_graph_all_fields_new[$i]}.'  >
		<label class="checkbox" for="bdmaild_graph_'.$bdmaild_graph_all_fields_new[$i].'" >'.$text{'stats_'.$tmp}.'</label>
                <input type="hidden" name="initial_bdmaild_graph" value="'.$bdmaild_graph_checked_fields_new{$bdmaild_graph_all_fields_new[$i]}.'" >
</td></tr>';
    
}

print <<EOF;
                                        </table>    
					    </td>
					</tr>
				</table>
				</fieldset>
EOF
}
if ( $File_Daemon eq "yes" )
{
print <<EOF;
                                <fieldset class="fieldset_1column">
                                    <legend>$text{'stats_files'}</legend>
					<table border=0>
					    <tr>
						<td valign=top><img src="images/$filed_graph_file"></td>
						<td valign=top>
							<table cellpadding="1" width="100%">
							
EOF

print "<tr><td>";
print "<select class=input_select name=bdfiled_graph_interval>";
print "<option value=1_hour ".($bdfiled_interval_new eq "1_hour"?"selected":"").">1 hour</option>";
print "<option value=6_hours ".($bdfiled_interval_new eq "6_hours"?"selected":"").">6 hours</option>";
print "<option value=24_hours ".($bdfiled_interval_new eq "24_hours"?"selected":"").">24 hours</option>";
print "<option value=1_week ".($bdfiled_interval_new eq "1_week"?"selected":"").">1 week</option>";
print "<option value=1_month ".($bdfiled_interval_new eq "1_month"?"selected":"").">1 month</option>";
print "<option value=3_months ".($bdfiled_interval_new eq "3_months"?"selected":"").">3 months</option>";
print "<option value=6_months ".($bdfiled_interval_new eq "6_months"?"selected":"").">6 months</option>";
print "<option value=1_year ".($bdfiled_interval_new eq "1_year"?"selected":"").">1 year</option>";
print "<option value=3_years ".($bdfiled_interval_new eq "3_years"?"selected":"").">3 years</option>";
print "</select>";
print "</td></tr>";


for $i ( 0 .. $#bdfiled_graph_all_fields_new )
{
$tmp = lc($bdfiled_graph_all_fields_new[$i]);

print '<tr><td width="100">
		<input class="checkbox" type="checkbox" name="bdfiled_graph" value="'.$bdfiled_graph_all_fields_new[$i].'" id="bdfiled_graph_'.$bdfiled_graph_all_fields_new[$i].'" '.$bdfiled_graph_checked_fields_new{$bdfiled_graph_all_fields_new[$i]}.'  >
		<label class="checkbox" for="bdfiled_graph_'.$bdfiled_graph_all_fields_new[$i].'" >'.$text{'stats_'.$tmp}.'</label>
                <input type="hidden" name="initial_bdfiled_graph" value="'.$bdfiled_graph_checked_fields_new{$bdfiled_graph_all_fields_new[$i]}.'" >
<td></tr>';
    
}


print <<EOF;
                                        </table>   
				    </td>
				</tr>
			    </table> 
EOF
}
print <<EOF;
					</div>
				    </td>
				</tr>
				<tr>
				    <td class="footer">
					<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
					    <tr>
				    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
						<td><input class="button" type="submit" value="Apply" />&nbsp;</td>
						</form>
					    </tr>
					</table>
				    </td>
				</tr>


EOF
&draw_footer();
}

sub draw_advanced_file_logging
{
my $file_logs_ref = shift;
my @file_logs = @$file_logs_ref;
my $browse_logging_file = "";

my %interval_type = ( h  => "",
		      d => "",
		      w => "",
		      m => "");

my %size_type = ( K => "",
		  M => "");


&draw_header('reports',"logging");
&draw_tabs($text{'logging_rotate_options'},'reports',"logging");

my $user_disabled = "";
#if ( ($remote_user eq "admin") || ($remote_user eq "bitdefender") || ($remote_user eq "root") )
#	{
#		$user_disabled="";
#		$browse_logging_file = &bd_file_chooser_button("logging_filepath", 0, 0);
#	}
#
print <<EOF;

	<form action="parse_reports.cgi?action=advanced_logging" method="POST">
EOF
# File logs array contains the following:
# 0 - the rule name, 1 - the log path, 2 - log rotate status (enabled/disabled)
# 3 - rotate interval, 4 - rotate interval type (h,d,w,m)
# 5 - log size, 6 - log size type (K, M), 7 - entries, 8 - count
for $i ( 0 .. $#file_logs )
{
$rule_name = $file_logs[$i][0];
my $browse_logging_file = &bd_file_chooser_button("${rule_name}_filepath", 0, 0);
$interval_type{$file_logs[$i][4]} = "selected=\"selected\"";
$size_type{$file_logs[$i][6]} = "selected=\"selected\"";

print <<EOF;
  	        <fieldset class="fieldset_1column">
		<legend>$rule_name</legend>	
		<input type="hidden" name="rule_name" value="$rule_name" />


		<table>
		    <tr>
			<td></td>
			<td><label class="">$text{'logging_filepath'}</label></td>
			<td>$text{'logging_rotateinterval'}</td>
			<td>$text{'logging_rotatesize'}</td>
			<td>$text{'logging_rotateentries'}</td>
			<td>$text{'logging_rotatecount'}</td>
		    </tr>
		    <tr>
			<td>
			    <input class="checkbox" type="checkbox" name="enable_logrotate_$i" id="enable_logrotate_$i" value="Y" $file_logs[$i][2]/>
			    <!--label class="checkbox" for="enable_logrotate_$i" >$text{'logging_filelogrotate'}</label-->
			    <input type="hidden" name="initial_enable_logrotate_$i" value="$file_logs[$i][2]" />

			</td>
			<td><div style="width:170px;overflow:hidden;"><a href=# title="$file_logs[$i][1]" alt="$file_logs[$i][1]" style="text-decoration:none;"><b>$file_logs[$i][1]</b></a></div></td>
			<td><input class="input_edit" type="text" name="rotateinterval_$i" size="2" value="$file_logs[$i][3]" />&nbsp;
		            <select name=interval_type_$i class="input_select">
	        		<option value="h" $interval_type{'h'} >$text{'logging_hours'}</option>
    	            		<option value="d" $interval_type{'d'} >$text{'logging_days'}</option>
				<option value="w" $interval_type{'w'} >$text{'logging_weeks'}</option>
				<option value="m" $interval_type{'m'} >$text{'logging_months'}</option>
		            </select>
			    <input type="hidden" name="initial_rotateinterval_$i" value="$file_logs[$i][3]" /> 
			    <input type="hidden" name="initial_interval_type_$i" value="$file_logs[$i][4]" /> </td>
		
		    <td><input class="input_edit" type="text" name="rotatesize_$i" size="2" value="$file_logs[$i][5]" />&nbsp;
	    		<select name=size_type_$i  class="input_select">
	            	    <option value="K" $size_type{'K'} >KB</option>
	            	    <option value="M" $size_type{'M'} >MB</option>
	    		</select>
	    		<input type="hidden" name="initial_rotatesize_$i" value="$file_logs[$i][5]" />
		    	<input type="hidden" name="initial_size_type_$i" value="$file_logs[$i][6]" />
		    </td>
		    <td><input class="input_edit" type="text" name="rotateentries_$i" size="2" value="$file_logs[$i][7]" style="width:70px;"/>
			<input type="hidden" name="initial_rotateentries_$i" value="$file_logs[$i][7]" /></td>
		
		    <td><input class="input_edit" type="text" name="rotatecount_$i" size="3" value="$file_logs[$i][8]" style="width:65px;" />
	    		<input type="hidden" name="initial_rotatecount_$i" value="$file_logs[$i][8]" /> </td>
			
		    <td><input class="button" type="submit" name="apply_$i" value="$text{'apply_button'}" $user_disabled /></td>
		</tr>

		</table>

		</fieldset>
EOF
$interval_type{$file_logs[$i][4]} = "";
$size_type{$file_logs[$i][6]} = "";
}
print <<EOF;
						</div>
					    </td>
				</tr>
				<tr>
				    <td class="footer">
					<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
					    <tr>
				    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
						<td>
						    <input class="button" type="submit" name=applyall value="$text{'applyall_button'}" /> 
						</td>
						</form>					
						<form action="parse_reports.cgi?action=logging" method="POST">
						<td>&nbsp;<input class="button" type="submit" name="back" value="$text{'back_button'}" /> </td>
					        </form>
					    </tr>
					</table>
				    </td>
				</tr>

EOF

&draw_footer();
}

sub insert_logger_script
{
my ($bdfiled_for_script, $bdmaild_for_script, $bdsmtpd_for_script, $spam_for_script, $defined_data_for_script) = @_;
print <<EOF;
<script language="JavaScript">
function fill_form(selected_box, selected_daemon, selected_event)
{
	var filling = new Array();
	var box_to_fill = document.logger_form.event;
	var other_box_select = selected_event;
	var i;
	if ( selected_box == "daemon" )
	{
		
		if ( selected_daemon == "bdmaild" ||  selected_daemon == "*" )
		{ filling = Array("*", "error", "debug", "info", "virus", "scanning", "license", "spam", "cf"); }
		else if ( selected_daemon == "bdfiled" )
		{ filling = Array("*", "error", "debug", "info", "virus", "scanning", "license"); }
		else
		{ filling = Array("*", "error", "debug", "info"); }
	}
	else
	{
		box_to_fill = document.logger_form.daemon;
		other_box_select = selected_daemon;
		if ( selected_event == "spam" || selected_event == "cf" )
		{ filling = Array("*", "bdmaild"); }
		else if ( selected_event == "virus" || selected_event == "scanning" || selected_event == "license" ) 
		{ filling = Array("*" $bdmaild_for_script $bdfiled_for_script); }
		else
		{ filling = Array("*" $bdmaild_for_script $bdfiled_for_script $bdsmtpd_for_script, "bdscand", "bdlogd", "bdmond", "bdlived", "bdemagentd", "bdemclientd" ); }
	}
	for ( i=box_to_fill.length; i>=0; i-- ){
	    box_to_fill[i] = null;
	}
	for ( i=0; i<filling.length; i++ ){
	    box_to_fill[i] = new Option(filling[i], filling[i]);
	    if (filling[i] == other_box_select ) {
		 box_to_fill[i].selected = true;
	    }

	}
}
function button_text_change()
{
	var add = "$text{'add_button'}";
	var replace = "$text{'replace_button'}";
	var defined_data = new Array($defined_data_for_script);
	var daemon = document.logger_form.daemon.value;
	var event = document.logger_form.event.value;
	var no_replace = true;
	var i;
	for ( i=0; i<defined_data.length; i++)
		{
		if (daemon+"."+event == defined_data[i])
			{
			document.logger_form.apply.value = replace;
			no_replace = false;
			break;
			}
		}
	if (no_replace)
	{
		document.logger_form.apply.value = add;
	}

}
function go(select_box, type)
{
	if (type == "file")
	{button_text_change();}
	fill_form(select_box.name, document.logger_form.daemon.value, document.logger_form.event.value);
}
</script>
EOF
}

sub draw_file_logging
{
my ( $file_logs_enabled_ref, $file_logs_disabled_ref ) = @_;
my @file_logs_enabled = @$file_logs_enabled_ref;
my @file_logs_disabled = @$file_logs_disabled_ref;
my $defined_data_for_script = "";
my %daemons = ( *  => "",
		bdmaild 	=> "",
		bdfiled 	=> "",
		bdsmtpd 	=> "", 
		bdscand 	=> "", 
		bdlogd  	=> "", 
		bdmond  	=> "", 
		bdlived 	=> "", 
		bdemagentd	=> "",
		bdemclientd	=> "" );
my %events = ( * => "",
	       error => "",
       	       info =>"",
	       debug => "",
	       virus =>"",
	       scanning =>"",
	       license =>"",
	       spam => "",
	       cf =>"");
&draw_header('reports',"logging");
&draw_tabs($text{'logging'},'reports',"logging");

my $os = $^O;
my $bdemagentd_option = "<option value=\"bdemagentd\" $daemons{'bdemagentd'} >bdemagentd</option>";
my $bdemclientd_option = "<option value=\"bdemclientd\" $daemons{'bdemclientd'} >bdemclientd</option>";
if ( $os ne "linux" )
	{
		$bdemagentd_option = "";
		$bdemclientd_option = "";
	}

my $bdfiled_option = "<option value=\"bdfiled\" $daemons{'bdfiled'}>bdfiled</option>";
my $bdmaild_option = "<option value=\"bdmaild\" $daemons{'bdmaild'}>bdmaild</option>";
my $bdsmtpd_option = "<option value=\"bdscand\" $daemons{'bdsmtpd'}>bsmtpd</option>";
my $bdfiled_for_script = ", \"bdfiled\"";
my ($bdmaild_for_script, $spam_for_script, $bdsmtpd_for_script) = (", \"bdmaild\"", ", \"spam\"", ", \"bdsmtpd\"");
# Check if bdfiled is installed to disable it from the rules adding
if ( (not -e "$bitdefender_dir/var/samba.inf") || (&BDReg_GetKeys("/BDUX/FileDaemon") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
		$bdfiled_option = "";
		$bdfiled_for_script = "";
	}
# Check if bdmaild is installed to disable it from the rules adding
if ( (not -e "$bitdefender_dir/var/mail.inf") || (&BDReg_GetKeys("/BDUX/MailDaemon") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
		$bdmaild_option = "";
		$bdmaild_for_script = "";
		$spam_for_script = "";

		$bdsmtpd_option = "";
		$bdsmtpd_for_script = "";
	}
for $i ( 0 .. $#file_logs_enabled )
	{ $defined_data_for_script = $defined_data_for_script." \"$file_logs_enabled[$i][0]\","; }
chop($defined_data_for_script);
&insert_logger_script($bdfiled_for_script, $bdmaild_for_script, $bdsmtpd_for_script, $spam_for_script, $defined_data_for_script);
$browse_logging_file = &bd_file_chooser_button("filepath", 0, 0);
print <<EOF;
	<form action="parse_reports.cgi?action=add_file_event" name="logger_form" method="POST">
	<fieldset class="fieldset_1column">
	<legend>$text{'logging_add_rule'}</legend>
	<table>
	    <tr>
		<td>
		    <label class="" >$text{'logging_select'}</label><br>
		</td>

		<td>
		    <select class="input_select"  name=daemon onChange="go(this,'file');">
			<option value="*" 	$daemons{'*'}	   >*</option>
			$bdmaild_option
			$bdfiled_option
			$bdsmtpd_option
			<option value="bdscand" $daemons{'bdscand'} >bdscand</option>
 			<option value="bdlogd"	$daemons{'bdlogd'} >bdlogd</option>
			<option value="bdmond" $daemons{'bdmond'} >bdmond</option>
			<option value="bdlived" $daemons{'bdlived'} >bdlived</option>
			$bdemagentd_option
			$bdemclientd_option
    		    </select>
		</td>
		<td>
		

		    <select class="input_select" name=event onChange="go(this,'file');">
			<option value="*"	$events{'*'}	>*</option>
			<option value="error"	$events{'error'}>error</option>
			<option value="info"	$events{'info'}>info</option>
			<option value="debug"	$events{'debug'}>debug</option>
 			<option value="virus"	$events{'virus'}>virus</option>
			<option value="scanning"   $events{'scanning'}>scanning</option>
			<option value="license"   $events{'license'}>license</option>
			<option value="spam"	$events{'spam'} >spam</option>
			<option value="cf"    $events{'cf'} >cf</option>
	            </select>
		</td>
		<td>
	    	    <label class="" >$text{'logging_filepath'}</label>
		</td>
		<td>
		    <input class="input_edit" type="text" name="filepath" size="30" value="" />&nbsp; $browse_logging_file
		</td>
		<td>
			<input class="button" type="submit" name="apply" value="$text{'add_button'}" $user_disabled />
		</td>
	</tr>
	</table>
	</fieldset>
	</form>
	
EOF



print <<EOF;
EOF

# Display enabled file logging rules
# if they are more than one
if ( $#file_logs_enabled >= 0 )
{
print <<EOF;
        <form action="parse_reports.cgi" method="GET" id="form1">
		<input type=hidden name=action value=logging>
		<input type=hidden name=type value=enabled>
                <fieldset class="fieldset_1column">
		<legend>$text{'logging_enabled_rules'}</legend>	
		<table cellspacing="0" cellpadding="3" width="100%">
		 
		<tr>
		    <td width=120><b>$text{'logging_ruletype'}</b></td>
            	    <td><b>$text{'logging_filepath'}</b></td></tr>
EOF

for $i ( 0 .. $#file_logs_enabled )
	{
	$rule_name = $file_logs_enabled[$i][0];
	$browse_logging_file = &bd_file_chooser_button("rule_filepath_$i", 0, 0);
print <<EOF;
		<tr>
		    <td>
			<b><input class="checkbox" type="checkbox" name="selected_rules" id="${rule_name}" value="${rule_name}">
			<label class="" for="${rule_name}" >$rule_name</label></b>
		    </td>
		    <td>
			<input class="input_edit" type="text" name="rule_filepath_$i" size="30" value="$file_logs_enabled[$i][1]" /> 
			<input type="hidden" name="initial_rule_filepath_$i" value="$file_logs_enabled[$i][1]" /> 
			<input type="hidden" name="rules" value="${rule_name}" />&nbsp;$browse_logging_file
		    </td>
		</tr>
EOF
	}

print <<EOF;
		</table>
		</fieldset>
		<table width="90%" style="float:left">
		    <tr>
			<td><img src="images/new/s.gif" height="2"/></td>
		    </tr>
		    <tr>
			<td>
	    		    <input class="button" type="submit" name="apply" value="$text{'apply_button'}" $user_disabled />
		            <input class="button" type="submit" name="rotate_options" value="$text{'rotate_button'}" $user_disabled />
		            <input class="button" type="submit" name="disable" value="$text{'disable_button'}" $user_disabled />
			</td>
		    </tr>
		    <tr>
			<td><img src="images/new/s.gif" height="2"/></td>
		    </tr>
		</table>

	</form>
EOF
}

# Display disabled file logging rules
# if they are more than one
if ( $#file_logs_disabled >= 0 )
{
print <<EOF;
	    <form action="parse_reports.cgi?action=logging&type=disabled" method="POST">
                <fieldset class="fieldset_1column">
		<legend>$text{'logging_disabled_rules'}</legend>	
		<table>
		<tr>
		    <td width=120><b>$text{'logging_ruletype'}<b/></td>
            	    <td><b>$text{'logging_filepath'}<b/></td>
		</tr>
EOF
	for $i ( 0 .. $#file_logs_disabled )
	{
	$rule_name = $file_logs_disabled[$i][0];
	$defined_data_for_script = $defined_data_for_script." \"$rule_name\",";
print <<EOF;
		<tr>
		    <td><input class="checkbox" type="checkbox" name="selected_rules" id="${rule_name}" value="${rule_name}" ><label class="" for="${rule_name}" >$rule_name</label></td>
		    <td><input class="input_edit" type="text" name="rule_filepath" size="30" value="$file_logs_disabled[$i][1]" /> <input type="hidden" name="initial_${rule_name}_filepath" value="$file_logs_disabled[$i][1]" /></td></tr>
EOF
	}
print <<EOF;
		</table>
		
		</fieldset>
		
		<table width="90%" style="float:left">
		    <tr>
			<td><img src="images/new/s.gif" height="2"/></td>
		    </td>
		    <tr>
			<td>
			    <input class="button" type="submit" name="enable" value="$text{'enable_button'}" $user_disabled /></td>
			</td>
		    </tr>
		</table>
    	</form>

		
EOF
}
print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

&draw_footer();
}

sub draw_mail_logging
{
my ( $mail_logs_enabled_ref, $mail_logs_disabled_ref ) = @_;
my @mail_logs_enabled = @$mail_logs_enabled_ref;
my @mail_logs_disabled = @$mail_logs_disabled_ref;

my %daemons = ( *  => "",
                bdmaild         => "",
                bdfiled         => "",
                bdsmtpd         => "",
                bdscand         => "",
                bdlogd          => "",
                bdmond          => "",
                bdlived         => "",
                bdemagentd       => "",
                bdemclientd      => "" );

my %events = ( * => "",
               error => "",
               info =>"",
               debug => "",
               virus =>"",
               scanning =>"",
               license =>"",
               spam => "",
               cf =>"");

&draw_header('reports',"notifications");
&draw_tabs($text{'notifications'},'reports',"notifications");

my $os = $^O;
my $bdemagentd_option = "<option value=\"bdemagentd\" $daemons{'bdemagentd'} >bdemagentd</option>";
my $bdemclientd_option = "<option value=\"bdemclientd\" $daemons{'bdemclientd'} >bdemclientd</option>";
if ( $os ne "linux" )
        {
                $bdemagentd_option = "";
                $bdemclientd_option = "";
        }
my $bdfiled_option = "<option value=\"bdfiled\" $daemons{'bdfiled'}>bdfiled</option>";
my $bdmaild_option = "<option value=\"bdmaild\" $daemons{'bdmaild'}>bdmaild</option>";
my $bdsmtpd_option = "<option value=\"bdscand\" $daemons{'bdsmtpd'}>bsmtpd</option>";
my $bdfiled_for_script = ", \"bdfiled\"";
my ($bdmaild_for_script, $spam_for_script, $bdsmtpd_for_script) = (", \"bdmaild\"", ", \"spam\"", ", \"bdsmtpd\"");
# Check if bdfiled is installed to disable it from the rules adding
if ( (not -e "$bitdefender_dir/var/samba.inf") || (&BDReg_GetKeys("/BDUX/FileDaemon") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
		$bdfiled_option = "";
		$bdfiled_for_script = "";
	}
# Check if bdmaild is installed to disable it from the rules adding
if ( (not -e "$bitdefender_dir/var/mail.inf") || (&BDReg_GetKeys("/BDUX/MailDaemon") eq "ERR_KEY_DOES_NOT_EXIST") )
	{
		$bdmaild_option = "";
		$bdmaild_for_script = "";
		$spam_for_script = "";

                $bdsmtpd_option = "";
                $bdsmtpd_for_script = "";

	}

&insert_logger_script($bdfiled_for_script, $bdmaild_for_script, $bdsmtpd_for_script, $spam_for_script, "");
print <<EOF;
	<form action="parse_reports.cgi?action=add_mail_event" name="logger_form" method="POST">
	<fieldset class="fieldset_1column">
	<legend>$text{'logging_add_rule'}</legend>
	<table>
	    <tr>
		<td>
		    	<label class="" >$text{'logging_select'}</label><br>
		</td>
		<td>
			<select name=daemon class="input_select" onChange="go(this,'mail');">
	    		    <option value="*" $daemons{'*'} >*</option>
	    		    $bdmaild_option
		    	    $bdfiled_option
			    $bdsmtpd_option
			    <option value="bdscand" $daemons{'bdscand'} >bdscand</option>
			    <option value="bdlogd"  $daemons{'bdlogd'} >bdlogd</option>
			    <option value="bdmond" $daemons{'bdmond'} >bdmond</option>
			    <option value="bdlived" $daemons{'bdlived'} >bdlived</option>
			    $bdemagentd_option
			    $bdemclientd_option	
		        </select>	
		        <select name=event class="input_select" onChange="go(this,'mail');">
		    	    <option value="*"	$events{'*'}	>*</option>
			    <option value="error"   $events{'error'}>error</option>
			    <option value="info"    $events{'info'}>info</option>
			    <option value="debug"   $events{'debug'}>debug</option>
			    <option value="virus"   $events{'virus'}>virus</option>
			    <option value="scanning"   $events{'scanning'}>scanning</option>
			    <option value="license"   $events{'license'}>license</option>
			    <option value="spam"    $events{'spam'} >spam</option>
			    <option value="cf"    $events{'cf'} >cf</option>
		        </select>
		</td>
		<td>
		    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</td>
		<td>
			<label class="" >$text{'logging_emailaddress'}</label>
		</td>
		<td>
		
		    	<input class="input_edit" type="text" name="new_rule_email" size="30" value="" />
		</td>
		<td>
			<input class="button" type="submit" name="add" value="$text{'add_button'}" $user_disabled />
		</td>
	    </tr>
	</table>
	</form>
	</fieldset>

EOF





print <<EOF;
EOF

# Display enabled mail logging rules
# if they are more than one
if ( $#mail_logs_enabled >= 0 )
{
print <<EOF;
        <form action="parse_reports.cgi?action=notifications&type=enabled" method="POST">
                <fieldset class="fieldset_1column">
		<legend>$text{'logging_enabled_rules'}</legend>	
		<table>
		<tr><td><b>$text{'logging_ruletype'}</b></td>
                <td><b>$text{'logging_emailaddress'}</b></td></tr>
EOF
for $i ( 0 .. $#mail_logs_enabled )
{
$rule_name = $mail_logs_enabled[$i][0];
print <<EOF;

		<tr>
		    <td>
			<input class="checkbox" type="checkbox" name="selected_rules" id="${rule_name}" value="${rule_name}"><label class="" for="${rule_name}" >$rule_name</label></td>
    		    <td><input class="input_edit" type="text" name="rule_emails_$i" size="30" value="$mail_logs_enabled[$i][1]" />
			<input type="hidden" name="initial_rule_emails_$i" value="$mail_logs_enabled[$i][1]" />
			<input type="hidden" name="rules" value="${rule_name}" /> </td></tr>
EOF
}
print <<EOF;
		</table>
		</fieldset>
		<table width="90%" style="float:left">
		     <tr>
		         <td><img src="images/new/s.gif" height="2"/></td>
		     </tr>
		     <tr>
			 <td>
				<input class="button" type="submit" name="apply" value="$text{'apply_button'}" $user_disabled />
		    		<input class="button" type="submit" name="disable" value="$text{'disable_button'}" $user_disabled />
                         </td>
		    </tr>
		    <tr>
			     <td><img src="images/new/s.gif" height="2"/></td>
		    </tr>
		</table>
																																										 
		</form>
EOF
}

# Display disabled mail logging rules
# if they are more than one
if ( $#mail_logs_disabled >= 0 )
{
print <<EOF;
	        <form action="parse_reports.cgi?action=notifications&type=disabled" method="POST">
                <fieldset class="fieldset_1column">
		<legend>$text{'logging_disabled_rules'}</legend>	
		<table>
		<tr><td><b>$text{'logging_ruletype'}</b></td>
                <td><b>$text{'logging_emailaddress'}</b></td></tr>
EOF
	for $i ( 0 .. $#mail_logs_disabled )
	{
	$rule_name = $mail_logs_disabled[$i][0];
print <<EOF;

		<tr><td><input class="checkbox" type="checkbox" name="selected_rules" id="${rule_name}" value="${rule_name}"><label class="" for="${rule_name}" >$rule_name</label></td>
		<td><input class="input_edit" type="text" name="rule_emails" size="30" value="$mail_logs_disabled[$i][1]" />		
		<input type="hidden" name="initial_rule_emails" value="$mail_logs_disabled[$i][1]" /></td></tr>
EOF
	}
print <<EOF;
		</table>
		</fieldset>
		<table width="90%" style="float:left">
		     <tr>
		         <td><img src="images/new/s.gif" height="2"/></td>
		     </tr>
		     <tr>
			 <td>
			    <input class="button" type="submit" name="enable" value="$text{'enable_button'}" $user_disabled />
                         </td>
		    </tr>
		    <tr>
			     <td><img src="images/new/s.gif" height="2"/></td>
		    </tr>
		</table>
		</form>
EOF
}

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF


&draw_footer();
}

1;
