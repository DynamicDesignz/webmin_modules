#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

sub draw_maintenance_live
{
my ($main_location, $interval_h, $proxyon, $proxy_user, $proxy_domain, $proxy_pass,
   $proxy_addr, $proxy_port, $push_update, $update_locations_array, $insecure_update_checks_array, $live_updating) = @_;

@update_locations = @$update_locations_array;
@insecure_update_checks = @$insecure_update_checks_array;
&draw_header("maintenance","live");
&draw_tabs($text{"live"},"maintenance","live");

print <<EOF;
<fieldset class="fieldset_1column">
<!-- <legend>$text{'live_general'}</legend> -->
<form action="parse_maintenance.cgi?action=live" method="POST">
EOF

if ( $live_updating eq "updating" )
        {
                print "<label class=\"\">$text{'live_updating'}</label><br>\n";
        }
print <<EOF;

<table border=0>
<tr><td width="120"><b>$text{'live_update_server'}</b></td>
<td><input class="input_edit" type="text" name="main_location" size="30" value="$main_location" />
<input type="hidden" name="initial_main_location" value="$main_location" /> </td></tr>

<tr><td><b>$text{'live_interval'}</b></td>
<td><input class="input_edit" type="text" name="interval" size="3" value="$interval_h" />
<input type="hidden" name="initial_interval" value="$interval_h" /> </td></tr>
</table>
EOF

# If there is a MailDaemon installed we show the Push Update option
if ( &BDReg_GetKeys("/BDUX/MailDaemon") ne "ERR_KEY_DOES_NOT_EXIST" )
{
print <<EOF;
<input class="checkbox" type="checkbox" name="push_update" id="push_update" value="Y" $push_update />
<label class="checkbox" for="push_update" >$text{'live_push_update'}</label>
<input type="hidden" name="initial_push_update" value="$push_update" />
EOF
}

# If there is a password put 6 stars, else the field is empty
my $proxy_pass_stars = "";
if ( $proxy_pass ne "" )
	{ $proxy_pass_stars = "\x06\x06\x06\x06\x06\x06"; }

print <<EOF;
<input class="checkbox" type="checkbox" name="proxyon" id="proxyon" value="Y" $proxyon />
<label class="checkbox" for="proxyon" >$text{'live_use_proxy'}</label>
<input type="hidden" name="initial_proxyon" value="$proxyon" /><br>
</fieldset>

<fieldset class="fieldset_2columns" style="height:150px;">
<legend>$text{live_insecure_update}</legend>
<label class="">$text{'live_insecure_update_body'}</label><br>
EOF

# Show insecure update settings for every location
for $i ( 0 .. $#update_locations )
{
print <<EOF;
<input class="checkbox" id="chk_insecure_$i" type="checkbox" name="sent_$update_locations[$i]" value="Y" $insecure_update_checks[$i] />
<label for=chk_insecure_$i>$update_locations[$i]</label>
<input type="hidden" name="initial_$update_locations[$i]" value="$insecure_update_checks[$i]" /><br>
EOF
}

print <<EOF;
</fieldset>
<fieldset class="fieldset_2columns" style="height:150px;">
<legend>$text{'live_proxy_settings'}</legend>
<table border=0>
<tr><td width="120"><b>$text{'live_proxy'}</b></td>
<td><input class="input_edit" type="text" name="proxy_addr" size="26" value="$proxy_addr" />
<input type="hidden" name="initial_proxy_addr" value="$proxy_addr" /></td> </tr>

<tr><td><b>$text{'live_port'}</b></td>
<td><input class="input_edit" type="text" name="proxy_port" size="4" value="$proxy_port" />
<input type="hidden" name="initial_proxy_port" value="$proxy_port" /></td> </tr>


<tr><td><b>$text{'live_user'}</b></td>
<td><input class="input_edit" type="text" name="proxy_user" size="12" value="$proxy_user" />
<input type="hidden" name="initial_proxy_user" value="$proxy_user" /></td></tr>

<tr><td><b>$text{'live_domain'}</b></td>
<td><input class="input_edit" type="text" name="proxy_domain" size="12" value="$proxy_domain" />
<input type="hidden" name="initial_proxy_domain" value="$proxy_domain" /></td></tr>

<tr><td><b>$text{'live_password'}</b></td>
<td><input class="input_edit" type="password" name="proxy_pass" size="6" value="$proxy_pass_stars" /></td></tr>
</table>

</fieldset>

EOF

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td><input class="button" type="submit" value="$text{'apply_button'}" />&nbsp;</td>
				</form>
				</td>
				<form action="parse_maintenance.cgi?action=update" method="POST">
				<td><input class="button" type="submit" value="$text{'live_update_button'}" /></td>
				</form>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF


&draw_footer();
}

sub draw_maintenance_signatures
{
my ($last_check, $last_update, $signatures_no) = @_;
my $last_check_string = $text{'signatures_unknown'};
my $last_update_string = $text{'signatures_unknown'};

if ( $last_check ne "ERR_KEY_DOES_NOT_EXIST" )
	{ $last_check_string = localtime($last_check); }
if ( $last_update ne "ERR_KEY_DOES_NOT_EXIST" )
	{ $last_update_string = localtime($last_update); }

&draw_header("maintenance","signatures");
&draw_tabs($text{'signatures'},"maintenance","signatures");

print <<EOF;
			    <fieldset class="fieldset_1column">
			    <form action="maintenance.cgi?subcat=signatures" method="POST">
			    	<table>
				    <tr><td width="120"><b>$text{'signatures_last_check'}</b></td> <td>$last_check_string</td></tr>
				    <tr><td><b>$text{'signatures_last_update'}</b></td> <td>$last_update_string</td></tr>
				    <tr><td><b>$text{'signatures_no'}</b></td> <td>$signatures_no</td></tr>
				</table>	
			    </fieldset>
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td><input class="button" type="submit" value="$text{'refresh_button'}" /></td>
			    </tr>
			    </form>
	    		</table>
		    </td>		
		</tr>

EOF


&draw_footer();
}

sub draw_maintenance_updates
{
my ( $pa_rf, $pi_rf ) = &Get_Sorted_Patches();

my @pa = @$pa_rf;
my @pi = @$pi_rf;

&draw_header("maintenance","updates");
&draw_tabs($text{'updates'},"maintenance","updates");

print <<EOF;
EOF


if ( defined @pa )
{
print <<EOF;
<fieldset class=fieldset_1column><legend>$text{'updates_available'}</legend>
<form action="parse_maintenance.cgi?action=install_updates" method="POST">
EOF
foreach my $patch ( @pa ) 
	{
	print "<fieldset class=fieldset_1column><legend>$text{'updates_number'} $patch->{number}</legend>";
	print "<label class=''><b>$patch->{summary}</b></label><br>";
	print "<dl>";
	print "<dt>$text{'updates_released'}</dt><dd>$patch->{release}</dd>";
	print "<dt>$text{'updates_description'}</dt><dd>$patch->{description}</dd>";
	print "</dl>";
	print "<label class=''>$text{'updates_instructions'}<br><b>$bitdefender_dir/bin/bdsafe patch install $patch->{number}</b></label></fieldset>"
	}
print "</form></fieldset>";
}
else
{
print <<EOF;
<fieldset class=fieldset_1column><legend>$text{'updates_available'}</legend>
    <label class=''>$text{'updates_are_not_available'}</label><br>
</fieldset>
EOF
}


if ( defined @pi )
{
print <<EOF;
<fieldset class=fieldset_1column><legend>$text{'updates_installed'}</legend>
<form action='parse_maintenance.cgi?action=uninstall_updates' method='POST'>
EOF
foreach my $patch ( @pi ) 
	{
	print "<fieldset class=fieldset_1column><legend>$text{'updates_number'} $patch->{number}</legend>";
	print "<label class=''><b>$patch->{summary}</b></label><br>";
	print "<dl>";
	print "<dt>$text{'updates_summary'}</dt><dd>$patch->{summary}</label></dd>";
	print "<dt>$text{'updates_released'}</dt><dd>$patch->{release}</label></dd>";
	print "<dt>$text{'updates_description'}</dt><dd>$patch->{description}</dd>";
	print "</dl></fieldset>";

	}
print "</form></fieldset>";
}

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

&draw_footer();
}
