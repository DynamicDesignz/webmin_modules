#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';


sub draw_services
{

&draw_header('status','services');
my $running_array = shift;
my $notrunning_array = shift;

&draw_tabs($text{'services'},'status','services');
# Draw the running processes with the correspondig form



if ( $#{$running_array} >= 0){
print <<EOF;		
        <fieldset class="fieldset_2columns" style="height:275px;">
		<legend>$text{'services_running'}</legend>
    		<table cellspacing="0" cellpadding="3" width="100%" border=0>
		    <tr>
			<td width="100" class="container_table_header"><b>$text{'services_service_name'}</b></td>
	    		<td class="container_table_header"><b>$text{'services_uptime'}</b></td>
		    </tr>
EOF

for $i ( 0 .. $#{$running_array} ) 
{
     # Check if we have the uptime
     if ( $#{${$running_array}[$i]} eq 4 )
        {
	 # We do have the uptime so we parse and print the array
	 #for $j ( 0 .. $#{${$running_array}[$i]} ) {
	 #print"<td> ${$running_array}[$i][$j] </td>\n";
	 #}
	 print "<tr><td>${$running_array}[$i][0]</td>
	 <td>${$running_array}[$i][1]d ${$running_array}[$i][2]h ${$running_array}[$i][3]m ${$running_array}[$i][4]s </td>";
    }
     else
    {
    	 # We don't have the uptime
	 print"<tr><td> ${$running_array}[$i][0] </td><td>&nbsp;</td></tr>\n";
    }
}
print "</table><br/></fieldset>";
}  

# Draw the stopped processes with the corresponding form
if ( $#{$notrunning_array} >= 0)
{
print <<EOF;
    <fieldset class="fieldset_2columns" style="height:275px;">
	    <legend>$text{'services_notrunning'}</legend>
	        <table cellspacing="0" cellpadding="3" width="100%" border="0">
	    	    <tr>
			<td width="100" class="container_table_header"><b>$text{'services_service_name'}</b></td>
		        <td class="container_table_header">&nbsp;</td>
		    </tr>
EOF

for $j ( 0 .. $#{$notrunning_array} )
	{
		print "<tr><td> ${$notrunning_array}[$j] </td><td>&nbsp;</td></tr>\n";
	}
	
	print "</table></fieldset>";
}


        






print  <<EOF;





	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
        <form action="parse_status.cgi?action=services" method="POST">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>
EOF

# Close stopped processes form

# If we have running processes we show the Stop and Restart buttons
if ( $#{$running_array} >= 0 )
{
	print "<input  class=\"button\"  type=\"submit\" name=stop  value=\"$text{'stop_button'}\" />\n";
	print "<input  class=\"button\"  type=\"submit\" name=restart value=\"$text{'restart_button'}\" />\n";
}

# If we have stopped processes we show the Start button
if ( $#{$notrunning_array} >= 0 )
{
	print "<input class=\"button\" type=\"submit\" name=start value=\"$text{'start_button'}\" />\n";
}

print <<EOF;
		</td>
	    </tr>
	</form>	
	</table>
    </td>
</tr>		
																																																		
EOF
&draw_footer;
}

sub draw_myaccount_content
{

my ($myaccount_registered, $myaccount_email, $myaccount_error) = @_;

print <<EOF;
    <fieldset class="fieldset_1column">
	<legend>$text{'myaccount'}</legend>
EOF

if ($myaccount_error ne ""){
print <<EOF;
    <div style="font-weight:bold; color: #EE0000;font-size:11px;">$myaccount_error</div>
EOF
}

if ($myaccount_registered eq 'y'){
print <<EOF;
	<table>
	    <tr>
		<td width=120>
		    <b>$text{'myaccount_status'}:</b></td>
		<td>
		    <span style="color:#007700;font-weight:bold;">$text{'myaccount_active'}</span></td></tr>
	    <tr>
		<td><b>$text{'myaccount_email'}:</b></td>
		<td>$myaccount_email</td>
	    </tr>
	</table>
EOF
} else {
    my $account_action = $in{'account_action'};
    my $account_login_email = $in{'account_login_email'};
    my $account_register_email = $in{'account_register_email'};
    my $account_register_fname = $in{'account_register_fname'};
    my $account_register_lname = $in{'account_register_lname'};
    
    my $action1_checked = "checked";
    my $action2_checked = "checked";
    
    if ($account_action eq "register"){
	$action1_checked = "";
    } else {
    	$action2_checked = "";
    }
    
print <<EOF;
    $text{'myaccount_text'}<br/><br/>
    <form action="parse_status.cgi?action=myaccount" method="POST" onSubmit="return ValidateMyAccountForm();">
    <table width="100%" cellpadding="1" cellspacing="1" border="0">
	<tr>
	    <td width="15"><input type=radio name=account_action id=radio1 value=login $action1_checked onClick="switchFormFields(false);"></td>
	    <td colspan=4><label for=radio1><b>&nbsp;$text{'myaccount_existing_account'}</b></label></td>
	</tr>
	<tr>
	    <td>&nbsp;</td>
	    <td width=110>$text{'myaccount_email'}:</td>
	    <td width=170><input type=edit class=input_edit name=account_login_email id=account_login_email value="$account_login_email"></td>
	    <td colspan=2>&nbsp;</td>
	</tr>
	<tr>
	    <td>&nbsp;</td>
	    <td>$text{'myaccount_password'}:</td>
	    <td colspan=3><input type=password class=input_edit name=account_login_password id=account_login_password> &nbsp; &nbsp;<a href="https://myaccount.bitdefender.com/site/MyAccount/forgotPassword/Forgot_your_password.html" target="_blank">Forgot password?</a></td>
	</tr>
	<tr>
	    <td><input type=radio name=account_action id=radio2 value=register $action2_checked onClick="switchFormFields(true);"></td>
	    <td colspan=4><label for=radio2><b>&nbsp;$text{'myaccount_new_account'}</b></label></td>
	</tr>
	<tr>
	    <td>&nbsp;</td>
	    <td>$text{'myaccount_email'}:</td>
	    <td><input type=edit class=input_edit name=account_register_email id=account_register_email disabled value="$account_register_email"></td>
	    <td width=110>$text{'myaccount_firstname'}:</td>
	    <td><input type=edit class=input_edit name=account_register_fname id=account_register_fname disabled value="$account_register_fname"></td>
	</tr>
	<tr>
	    <td>&nbsp;</td>
	    <td>$text{'myaccount_password'}:</td>
	    <td><input type=password class=input_edit name=account_register_password id=account_register_password disabled></td>
	    <td>$text{'myaccount_lastname'}:</td>
	    <td><input type=edit class=input_edit name=account_register_lname id=account_register_lname disabled value="$account_register_lname"></td>
	</tr>
	<tr>
	    <td>&nbsp;</td>
	    <td>$text{'myaccount_confirm_password'}:</td>
	    <td><input type=password class=input_edit name=account_register_password2 id=account_register_password2 disabled></td>
	    <td>$text{'myaccount_country'}:</td>
	    <td><select class=input_edit style="width:129px;" name=account_register_country id=account_register_country disabled>
		    <option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American">American Samoa</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antarctica">Antarctica</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Ascension Island">Ascension Island</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option><option value="Botswana">Botswana</option><option value="Bouvet">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="Brunei">Brunei</option><option value="Bulgaria">Bulgaria</option><option value="Burkina">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Channel Islands, Guernsey">Channel Islands, Guernsey</option><option value="Channel Islands, Jersey">Channel Islands, Jersey</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Congo, Democratic Republic of">Congo, Democratic Republic of</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Cote d Ivoire">Cote d Ivoire</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="East Timor">East Timor</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands">Falkland Islands</option><option value="Faroe Islands">Faroe Islands</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guiana">French Guiana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="French, Metropolitan">French, Metropolitan</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard and McDonald Islands">Heard and McDonald Islands</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Ireland">Ireland</option><option value="Isle of Man">Isle of Man</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Kosovo">Kosovo</option><option value="Korea, Democratic People">Korea, Democratic People's Republic of</option><option value="Korea, Republic of">Korea, Republic of</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macao">Macao</option><option value="Macedonia">Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Micronesia">Micronesia</option><option value="Moldova">Moldova</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn">Pitcairn</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russia">Russia</option><option value="Rwanda">Rwanda</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="St">St. Helena</option><option value="St">St. Pierre and Miquelon</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Taiwan">Taiwan</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="The Bahamas">The Bahamas</option><option value="The Cayman Islands">The Cayman Islands</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks and Caicos Islands">Turks and Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Vatican City State">Vatican City State</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Virgin Islands (British)">Virgin Islands (British)</option><option value="Virgin Islands (US)">Virgin Islands (US)</option><option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option>
		</select></td>
	</tr>
	<tr>
	    <td></td>
	    <td colspan=4>(All fields are mandatory)</td>
	</tr>
	<tr>
	    <td></td>
	    <td colspan=4><input type=submit class=button value="$text{'apply_button'}" /></td>
	</tr>
    </table>	    
    </form>
EOF

    #print "<script language=Javascript>selectOption('account_register_country','$account_register_country');</script>";
    
    if ($account_action eq "register"){
	print "<script language=Javascript>switchFormFields(true);</script>";
    }
}
		
print <<EOF;		
    </fieldset><table width=600 cellspacing=0 cellpadding=0 style="float:left;"><tr><td style="font-size:7px;">&nbsp;</td></tr></table>
EOF

}

sub draw_license_content
{
my ($type, $license_status_string, $remaining_days, $expiration_date,
    $licensed_domains, $licensed_users, $license_key, $license_key_button) = @_;


if ( $license_status_string eq "license_evaluation_valid" ){ 
    $showKey = 0;
    $license_key = "";
    $license_status_print = "$text{'license_evaluation'}, $remaining_days $text{'license_days_left'}";}
elsif ( $license_status_string eq "license_valid" ){ 
    $showKey = 1;
    $license_status_print = "$text{'license_valid_until'} $expiration_date ($remaining_days $text{'license_days_left'})";
} else { 
    $showKey = 1;
    $license_key = "";
    $license_status_print = $text{$license_status_string};
}


print <<EOF;
					  
<fieldset class="fieldset_1column">
<legend>$text{"license_".$type}</legend>
  <table cellspacing="0" cellpadding="2" width="100%">
    <form action="parse_status.cgi?action=license&type=$type" method="POST">
      <tr>
        <td width="120"><b>$text{'license_status'}</b></td>
	<td>$license_status_print</td>
      </tr>
EOF
if ( $licensed_domains ne "0" )
	{ 
		print "<tr><td><b>$text{'license_domains'}</b></td>";
		print "<td>$licensed_domains</td></tr>";
	}
if ( $licensed_users ne "0" )
	{ 
		print "<tr><td><b>$text{'license_users'}</b></td>";
		print "<td>$licensed_users</td></tr>";
	}


print <<EOF;
	  <tr>
	    <td valign=top><b>$text{'license_key'}</b></td>
	    <td>
		<input class="input_edit" type="text" name="license_key" size="20" style="width:180px" value="$license_key" />
	        <input type="hidden" name="initial_license_key" value="$license_key" /> &nbsp; <input class="button" type="submit" value=$text{$license_key_button} />
	    </tr>
EOF
print "</form></table>";
if ($license_key eq ""){
    print "<br/>".$text{'license_buy_now_text'};
}


print "</fieldset><table width=100% style=\"float:left;\"><tr><td>&nbsp;</td></tr></table>";
}

sub draw_license
{
my($mail_daemon, $file_daemon, $mail_license_status_string, $mail_remaining_days, $mail_expiration_date,
                $mail_licensed_domains, $mail_licensed_users, $mail_license_key, $mail_license_key_button,
                $file_license_status_string, $file_remaining_days, $file_expiration_date, $file_licensed_domains, 
		$file_licensed_users, $file_license_key, $file_license_key_button,$myaccount_registered, $myaccount_email, $myaccount_error) = @_;
&draw_header('status','license');




my $no_license = 1;

&draw_tabs($text{'license'},'status','license');

&draw_myaccount_content($myaccount_registered, $myaccount_email, $myaccount_error);

if ($mail_daemon eq "yes")
	{
		&draw_license_content("mail", $mail_license_status_string, $mail_remaining_days, $mail_expiration_date,
                $mail_licensed_domains, $mail_licensed_users, $mail_license_key, $mail_license_key_button);
		$no_license = 0;
	}
if ($file_daemon eq "yes")
	{
		&draw_license_content("file", $file_license_status_string, $file_remaining_days, $file_expiration_date,
		$file_licensed_domains, $file_licensed_users, $file_license_key, $file_license_key_button);
		$no_license = 0;
	}
if ( $no_license )
{
print <<EOF;
<fieldset class="fieldset_1column">
    <label class=''>$text{'license_nolicense'}</label><br>
</fieldset>     
EOF
}

print <<EOF;
	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>&nbsp;</td>
	    </tr>
	</table>
    </td>
</tr>
EOF
&draw_footer;
}

sub draw_about
{
my ($product_info_entry, $corecomponents_versions, $agents_versions)= @_;
my @cc_versions = @$corecomponents_versions;
my @ag_versions = @$agents_versions;
my @product_info = @$product_info_entry;

&draw_header('status','about');

&draw_tabs($text{'about'},'status','about');

# product_info contains an array:
# (product_type, version_of_the_product)
if  ( defined @product_info )
{
	for $i ( 0 .. $#product_info )
		{
		print "<fieldset class=\"fieldset_1column\" >\n";
		print "<legend>$text{'about_product_'.$product_info[$i][0]} $product_info[$i][1]</legend>\n";
		print "$text{'about_'.$product_info[$i][0]}\n";
		print "</fieldset>\n";
		}
}
print <<EOF;
<fieldset class="fieldset_1column">
<legend>$text{'about_versions'}</legend>
EOF
if ( defined @cc_versions )
	{
		print "<div class='defs'><b>$text{'about_corecomponents'}</b>\n<table width=210>";
		for $i ( 0 .. $#cc_versions )
			{
			print "<tr><td>$cc_versions[$i][0]</td><td>$cc_versions[$i][1] &nbsp;</td></tr>\n";
			}
		print "</table></div>\n";
	}
if ( defined @ag_versions )
	{
		print "<div class='defs'><b>$text{'about_agents'}</b>\n<table width=210>";
		for $i ( 0 .. $#ag_versions )
			{
			my $text_disabled="";
			if ( $ag_versions[$i][2] eq "disabled" )
				{
					$text_disabled=$text{'about_agent_disabled'};
				}
			print "<tr><td>$ag_versions[$i][0]</td><td>$ag_versions[$i][1]  $text_disabled &nbsp;</td></tr>\n";
			}
		print "</table></div>\n";
	}
print <<EOF;
		<div class="defs"><b>$text{'about_radmin_version'} 3.0.1.80703 (9348)</b>
		<table width=210>
		    <tr>
			<td>
			    &copy; 2008 BitDefender<br/>
		    	    <a href="http://www.bitdefender.com">www.bitdefender.com</a>
			</td>
		    </tr>
		</table>
		</div>
	    </fieldset>
	</div>
    </td>
</tr>
<tr>
    <td class="footer">
	<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
	    <tr>
	        <td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
		<td>&nbsp;</td>
	    </tr>
	</table>
    </td>
</tr>

EOF
&draw_footer();
}


