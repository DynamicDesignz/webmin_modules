#!/usr/bin/perl
require 
	'./draw_lib.pl';
require 
	'./menu.pl';

@items_select = (10, 20, 30);

sub calculate_start_end
{
	# Used in displaying the bottom page numbers list
	# It returns the first and the last page that should be displayed
	# according to page_number (selected page) and the total number of pages (pages),
	# We usually display 6 pages before and 5 after the selected page 
	my ($page_number, $pages) = @_;

	$start_number = $page_number - 6;
	my $start_dif_number = 0;
	if ( $start_number < 1 )
		{
			$start_dif_number = 7 - $page_number;
			$start_number = 1;
		}

	$end_number = $page_number + 5;
	if ( $start_dif_number > 0 )
		{ $end_number = $end_number + $start_dif_number }
	
	if ( $end_number > $pages )
		{
			my $end_dif_number = $page_number +5 - $pages; 	
			$end_number = $pages;
		}
	if ( ( $start_number - $end_dif_number ) >= 1 )
		{ $start_number = $start_number - $end_dif_number; }
	else
		{ $start_number = 1;}

	return ($start_number, $end_number);
}

sub draw_quarantine
{
my($subcat, $qpath, $email, $files_info, $pages, $page_number, $items_per_page, 
	$search_type, $search_string, $queue, $queue_size) = @_;
my %files = %$files_info;
&draw_header("quarantine",$subcat."_quar");

&draw_tabs($text{$subcat."_quar"},'quarantine',$subcat."_quar");

my $browse_qpath = "";
my $user_disabled = "";
my $uuid = "";
#if ( ($remote_user eq "admin") || ($remote_user eq "bitdefender") || ($remote_user eq "root") )
#        {
#                $user_disabled="";
#		$browse_qpath = &bd_file_chooser_button("qpath", 1, 0);
#        }

my %type = ( sender => "",
	     recipient =>"",
	     subject => "",
     	     uuid => "");

$type{$search_type} = "selected=\"selected\"";
my $search_type_url = &urlize($search_type);
my $search_string_url = &urlize($search_string);
print <<EOF;
<form action="parse_quarantine.cgi?subcat=$subcat&action=search" method="POST">
<fieldset class="fieldset_1column">
<table>
<tr>
EOF

if ( $subcat eq "samba")
{
print <<EOF;
<td>
<select name=search_type class="input_select">
	<option value="uuid" $type{'uuid'}>$text{'quar_uuid'}</option>
</select></td>
EOF
}
else
{
print <<EOF;
<td>
<select name=search_type class="input_select">
        <option value="sender" $type{'sender'} >$text{'quar_sender'}</option>
        <option value="recipient" $type{'recipient'} >$text{'quar_recipient'}</option>
        <option value="subject" $type{'subject'} >$text{'quar_subject'}</option>
	<option value="uuid" $type{'uuid'} >$text{'quar_uuid'}</option>
</select></td>
EOF
}

print <<EOF;
<td>
<input class="input_edit" type="text" name="search_string" size="20" value="$search_string" $user_disabled /></td>
<td>
<input type="hidden" name="initial_search_string" value="$search_string" />
<input class="button" type="submit" name="apply" value="$text{'search_button'}" $user_disabled />
<input class="large_button" type="submit" name="rebuild_search_cache" value="$text{'rebuild_search_cache_button'}" /></td>
</td>
</table>
</fieldset>
</form>
EOF

if ( $page_number > $pages )
{
# The page number could be greater than the number of pages. In this case, we
# draw only until the last page.  The $files array already contains the last
# page, because of the page_items() subroutine in do_quarantine.pl
	$page_number = $pages;
}

# If there are items in the quarantine we show them
if ( $pages > 0 )
{
    print <<EOF;
    <form action="parse_quarantine.cgi?subcat=$subcat&action=parse&page=$page_number&items=$items_per_page&type_url=$search_type_url&string_url=$search_string_url" method="POST" onSubmit="return ValidateQuarantineForm()">
	<fieldset class="fieldset_1column">
	<legend>$text{'quar_results'}</legend>
        <table width="100%" cellspacing=1 cellpadding=2>
EOF

    # For file quarantine we show other data
    if ( $subcat eq "samba")
    {
    
print <<EOF;
    	    <tr class=container_table_header height=20>
		<td width=15>&nbsp;</td>
		<td width=60><b>$text{'quar_uuid'}</b></td>
	    	<td colspan=3><b>$text{'quar_location'}</b></td>
		</tr>
EOF

    for $i ( 0 .. $#{$files{'UUID'}} )
        {
	    if ($i%2 eq "1")  {
		print "<tr class=container_table_even_row style=\"cursor:pointer;\" onMouseOver=\"this.className='container_table_active_row';\" onMouseOut=\"this.className='container_table_even_row';\">";
	    }	
	        else {
		print "<tr class=container_table_odd_row  style=\"cursor:pointer;\" onMouseOver=\"this.className='container_table_active_row';\" onMouseOut=\"this.className='container_table_odd_row';\">";
	    } 
	    
	    if ($files{'UUID'}[$i] eq ""){
		print "<td colspan=3>$text{'quar_no_uuid'}</td></tr>";
	    } else {
	        print "<td><input class='checkbox' type='checkbox' name='check_files' value='$files{'UUID'}[$i]' /></td>";
		$uuid = $files{'UUID'}[$i];
		$uuid =~ s/^.*://;
		print "<td><label class=''>$text{'quar_uuid'}</label> $uuid </td>
		<td>".&html_escape($files{'Location'}[$i])."</td></tr>";
	    }
        }
    } else {
print <<EOF;
    	    <tr class=container_table_header height=20>
		<td width=15>&nbsp;</td>
		<td width=50><b>$text{'quar_uuid'}</b></td>
	    	<td width=150><b>$text{'quar_from'}</b></td>
	    	<td width=150><b>$text{'quar_to'}</b></td>
		<td><b>$text{'quar_thesubject'}</b></td>
		<td width=60><b>$text{'quar_date'}</b></td>
		</tr>
EOF
	for $i ( 0 .. $#{$files{'UUID'}} )
    	{
	    if ($i%2 eq "1")  {
		print "<tr class=container_table_even_row style=\"cursor:pointer;\" onMouseOver=\"this.className='container_table_active_row';\" onMouseOut=\"this.className='container_table_even_row';\">";
	    }	
	        else {
		print "<tr class=container_table_odd_row  style=\"cursor:pointer;\" onMouseOver=\"this.className='container_table_active_row';\" onMouseOut=\"this.className='container_table_odd_row';\">";
	    } 
	    if ($files{'UUID'}[$i] eq ""){
		print "<td colspan=6>$text{'quar_no_uuid'}</td></tr>";
	    } else {
                print "<td width=15><input class='checkbox' type='checkbox' name='check_files' value='$files{'UUID'}[$i]' /></td>";
	        $uuid = $files{'UUID'}[$i];
    	        $uuid =~ s/^.*://;
	        print "<td width=50 nowrap><label class=''>$text{'quar_uuid'}</label> $uuid </td>
		<td width=150 onClick='document.location=\"parse_quarantine.cgi?subcat=$subcat&action=view&uuid=$files{'UUID'}[$i]\";'>".&html_escape($files{'From'}[$i])."</td>
        	    <td width=150 onClick='document.location=\"parse_quarantine.cgi?subcat=$subcat&action=view&uuid=$files{'UUID'}[$i]\";'>".&html_escape($files{'To'}[$i])."</td>
		    <td onClick='document.location=\"parse_quarantine.cgi?subcat=$subcat&action=view&uuid=$files{'UUID'}[$i]\";'>".&html_escape($files{'Subject'}[$i])."</td>";
    		    print "<td width=66 nowrap onClick='document.location=\"parse_quarantine.cgi?subcat=$subcat&action=view&uuid=$files{'UUID'}[$i]\";'>". substr(&html_escape($files{'Date'}[$i]),5,11)."</td></tr>";
	    }		    
        }
    }
    
    my ($start_number, $end_number) = &calculate_start_end($page_number, $pages);

print "</table>";

# Pages navigation
    print "<span class='pages'>\n <b>$text{'quar_navigation_jump_to_page'}</b>&nbsp;";
    if ( $page_number > 1 )
    {
	$previous_page = $page_number - 1;
	print "&nbsp;<a href=parse_quarantine.cgi?subcat=$subcat&page=$previous_page&items=$items_per_page&type_url=$search_type_url&string_url=$search_string_url><img src='images/left.png' valign='center' alt='$text{'previous'}' border='0'></a>";
    }
    for $j ( $start_number .. $page_number-1 )
    {
	print "&nbsp;<a href=parse_quarantine.cgi?subcat=$subcat&page=$j&items=$items_per_page&type_url=$search_type_url&string_url=$search_string_url>$j</a>&nbsp;";
    }
	print "&nbsp;<b>$page_number</b>&nbsp;";
	for $j ( $page_number+1 .. $end_number )
		{
			print "&nbsp;<a href=parse_quarantine.cgi?subcat=$subcat&page=$j&items=$items_per_page&type_url=$search_type_url&string_url=$search_string_url>$j</a>&nbsp;";
		}
        if ( $page_number < $pages )
                {
                        $next_page = $page_number + 1;
                        print "&nbsp;<a href=parse_quarantine.cgi?subcat=$subcat&page=$next_page&items=$items_per_page&type_url=$search_type_url&string_url=$search_string_url><img src='images/right.png' valign='center' alt='$text{'next'}' border='0'></a>";
                }
        print "</span>";


print "</fieldset>";	
	
print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td>
				    <table cellspacing=1 cellpadding=1 border=0>
					<tr>
					    <td>&nbsp;<input class="small_button" type="submit" name="delete" value="$text{'delete_button'}" /></td>
					    <td>&nbsp;<input class="small_button" type="submit" name="delete_all" value="$text{'delete_all_button'}" onClick="return confirm('$text{'quar_delete_all_confirm'}');" /></td>

EOF
# No export as maildir/mailbox for samba
if ( $subcat ne "samba" )
{
	if ( $queue eq "" )
	{
print <<EOF;
					    <td>&nbsp;&nbsp;|&nbsp; Export: <select name="export_as" class="input_select"><option value="mbox">as mbox file</option><option value="maildir">as maildir</option></select></td>
					    <td><input type="submit" class="small_button" name="export" value="Export" />&nbsp;&nbsp;|</td>
EOF
	}
	else
	{
print <<EOF;
<td>&nbsp;&nbsp;|&nbsp; $text{$queue."_queue"} $queue_size 
<input type="hidden" name="queue_type" value="$queue" />
<input type="hidden" name="queue_size" value="$queue_size" />
</td>
<td><input type="submit" class="small_button" name="add_to_queue" value="Add" />&nbsp;&nbsp;|</td>
<td><input type="submit" class="small_button" name="purge_queue" value="Purge" />&nbsp;&nbsp;|</td>
<td><input type="submit" class="small_button" name="download_queue" value="Download" />&nbsp;&nbsp;|</td>
EOF
	}
}

print <<EOF;
					    <td><!-- <input class="submit" type="submit" name="send_to_lab" value="$text{'send_to_lab_button'}" /> -->
	    <td nowrap>&nbsp; $text{'quar_navigation'}:&nbsp;
		    <select name="sel_items" class="input_select">
EOF
		foreach my $nr (@items_select){
		    print "<option value='$nr' ";
	            if ($nr == $items_per_page)
        	    {
                	print "selected=\"selected\"";
	            }
    		    print ">".($nr)." / $text{'quar_navigation_items'}</option>\n";
		}
    print "</select>";
    print "&nbsp;<input class=\"small_button\" type=\"submit\" name=\"set\" value=\"$text{'set_button'}\" />";
print <<EOF	
				    </td></tr></table>

				</td>
			    </tr>
				</form>                                                                                                                        
	    		</table>
		    </td>		
		</tr>

EOF
	
}	
else
{
# There are no matches
print <<EOF;
		    	    <fieldset class="fieldset_1column"><legend>$text{'quar_results'}</legend>
			    <label class="">$text{'quar_nomatch'}</label><br>
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

}



&draw_footer
}

sub draw_status_quarantine
{
my ($subcat, $stats_tmp) = @_;
my @stats = @$stats_tmp;	
&draw_header('quarantine',$subcat."_quar");
&draw_tabs($text{$subcat."_quar"},'quarantine',$subcat."_quar");


my $browse_qpath = "";
my $user_disabled = "disabled";
if ( ($remote_user eq "admin") || ($remote_user eq "bitdefender") || ($remote_user eq "root") )
        {
                $user_disabled="";
        }

print <<EOF;
<form action="parse_quarantine.cgi?subcat=$subcat&action=search" method="POST">
<fieldset class="fieldset_1column">
<table>
<tr>
EOF
if ( $subcat eq "samba")
{
print <<EOF;
<td>
<select name=search_type class="input_edit">
	<option value="uuid" selected="selected" >$text{'quar_uuid'}</option>
</select></td>
EOF
}
else
{
print <<EOF;
<td>
<select name=search_type class="input_edit">
        <option value="sender" selected="selected" >$text{'quar_sender'}</option>
        <option value="recipient">$text{'quar_recipient'}</option>
        <option value="subject">$text{'quar_subject'}</option>
	<option value="uuid">$text{'quar_uuid'}</option>
</select></td>
EOF
}

print <<EOF;
<td>
<input class="input_edit" type="text" name="search_string" size="20" value="$search_string" $user_disabled />
<input type="hidden" name="initial_search_string" value="$search_string" />
</td>
<td>
&nbsp;<input class="button" type="submit" name="search" value="$text{'search_button'}" $user_disabled /></td>
<td><input class="button" type="submit" name="rebuild_search_cache" value="$text{'rebuild_search_cache_button'}" /></td>
</tr></table>
</fieldset>
<table border="0" cellspacing="0" cellpadding="1" align="left" width="100%">
<tr class="container_table_odd_row">
    <td width="120"><b>$text{'quar_path'}</b></td><td>$stats[1]</td>
</tr>
<tr class="container_table_even_row">
    <td><b>$text{'quar_files_number'}</b></td><td>$stats[2]</td>
</tr>
<tr class="container_table_odd_row">
    <td><b>$text{'quar_size'}</b></td><td>$stats[3]</td>
</tr>
</table>
</form>                                                                                                                        
EOF

print <<EOF;
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td></td>
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF


&draw_footer
}

sub draw_view_message
{
my ( $subcat, $uuid, $body, $content_type, $from, $to, $subject, $date, $attachments_tmp ) = @_;
my @attachments = @$attachments_tmp;
my @body = @$body;
&draw_header('quarantine',$subcat."_quar");
&draw_tabs($text{$subcat."_quar"},'quarantine',$subcat."_quar");


#<form action="parse_quarantine.cgi?subcat=$subcat&uuid=$uuid&action=view_original_html" method="POST">
print <<EOF;
<table width=99% cellspacing=1 cellpadding=5>
    <tr class=container_table_odd_row>
	<td width=110 valign=top><b>$text{'quar_from'}:</b></td>
	<td valign=top>$from</td>
    </tr>
    <tr class=container_table_even_row>
	<td width=110 valign=top><b>$text{'quar_to'}:</b></td>
	<td valign=top>$to</td>
    </tr>
    <tr class=container_table_odd_row>
	<td width=110 valign=top><b>$text{'quar_thesubject'}:</b></td>
	<td valign=top>$subject</td>
    </tr>
    <tr class=container_table_even_row>
	<td width=110 valign=top><b>$text{'quar_date'}:</b></td>
	<td valign=top>$date</td>
    </tr>
    <tr class=container_table_odd_row>
	<td width=110 valign=top><b>$text{'quar_body'}:</b></td>
	<td valign=top>@body</td>
    </tr>
EOF

if (@attachments){
    print "<tr class=container_table_even_row><td width=110 valign=top><b>$text{'quar_attachments'}:</b></td><td valign=top>";
    foreach $attachment (@attachments){
    	print "<b>$attachment</b><br>";
    }
    print "</td></tr>";
}

print <<EOF;
			    </table>
			</div>
		    </td>
		</tr>
		<tr>
		    <td class="footer">
			<table height="30" cellspacing="0" cellpadding="0" align="left" border="0">
			    <tr>
		    		<td width="14"><img src="images/new/s.gif" height="30" width="14" /></td>
				<td><input type=button class=button value="$type $text{'back_button'}" onClick="history.go(-1);"></td>
EOF
if ($content_type eq "html")
{
	# We show the show original html button
	print "<td>&nbsp;</td><td width=\"500\"><div style=\"font-size:8pt;\">$text{'quar_full_message'}<a href=\"parse_quarantine.cgi?subcat=$subcat&uuid=$uuid&action=view_original_html\" target=\"_blank\">$text{'quar_full_message_here'}</a></div></td>";
}
print <<EOF;
			    </tr>
	    		</table>
		    </td>		
		</tr>

EOF

&draw_footer;
	
}

sub draw_view_html
{
my $contents_temp = shift;
my @contents = @$contents_temp;
print "Content-Type: text/html\n\n";
print @contents;
}
