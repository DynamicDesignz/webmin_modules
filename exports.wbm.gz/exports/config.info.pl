line2=Konfiguracja systemu,11
exports_file=Plik 'exports',0
apply_cmd=Polecenia zastosowania konfiguracji,3,Brak
restart_command=Polecenie restartu serwera NFS,0
