line0=Opcje konfiguracji,11
view_condition=Wy�wietla� stan na li�cie regu�?,1,1-Tak,0-Nie
view_comment=Wy�wietla� komentarz na li�cie regu�?,1,1-Tak,0-Nie
comment_mod=Zapisuj komentarze jako,1,0-# zapis w pliku komentarzy,1-&#45;&#45;opcja komentarzy
cluster_mode=Aktualizuj klaster serwer�w,1,0-Zawsze&#44; gdy wprowadzono zmian�,1-Po zastosowaniu konfiguracji
force_init=Zawsze uruchamiaj firewall ze skryptem inita Debiana,1,1-Tak,0-Nie
before_cmd=Polecenie do uruchomienia przed zmienieniem regu�,3,Brak
after_cmd=Polecenie do uruchomienia po zmienieniu regu�,3,Brak
before_apply_cmd=Polecenie do uruchomienia przed zastosowaniem konfiguracji,3,Brak
after_apply_cmd=Polecenie do uruchomienia po zastosowaniu konfiguracji,3,Brak
line1=Opcje systemu,11
direct=Bezpo�rednio edytuj regu�y firewalla zamiast zapisywa� do pliku?,1,1-Tak,0-Nie
save_file=File to save/edit <tt>IPv4</tt> rules,3,Use operating system or Webmin default
save_file6=File to save/edit <tt>IPv6</tt> rules,3,Use operating system or Webmin default

