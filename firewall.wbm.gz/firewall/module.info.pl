desc_pl=Firewall Linuksa
longdesc_pl=Konfiguracja firewall linuksa u�ywaj�c iptables. Pozwala na edycj� wszystkich tabel, regu� i opcji.
