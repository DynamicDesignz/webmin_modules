#!/usr/bin/perl
# memcached-lib.pl
use Data::Dumper;
use Cache::Memcached;
# Common functions for the memcached server config file
do '../web-lib.pl';
&init_config();

sub collecte_stat  
{ 
 my $host= shift;
 my $memd=new Cache::Memcached {
                 'servers'  => ["$host"],
                                        };

my $x= $memd->stats('misc');
 return $x ;
}
sub stat_misc
 {
  my $res=shift;
  my $host=shift;
  my %tab=%{$res->{'hosts'}->{$host}->{misc}};
  return \%tab;    
}

1;


