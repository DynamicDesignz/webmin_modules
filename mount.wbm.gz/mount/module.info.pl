desc_pl=Lokalne i&nbsp;sieciowe systemy plik�w
