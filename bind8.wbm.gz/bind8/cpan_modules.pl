require 'bind8-lib.pl';

sub cpan_recommended
{
return ("Net::DNS::SEC::Tools::dnssectools",
        "Net::DNS::RR::DS",
	      "Net::DNS");
}
