desc_pl=BIND - serwer DNS
longdesc_pl=Tw�rz i edytuj domeny, rekordy DNS, opcje BIND i widoki.
