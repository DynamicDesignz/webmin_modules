# Common functions for the bacula config file

do '../web-lib.pl';
&init_config();

$dir_conf_file = "$config{'bacula_dir'}/bacula-dir.conf";
$fd_conf_file = "$config{'bacula_dir'}/bacula-fd.conf";
$sd_conf_file = "$config{'bacula_dir'}/bacula-sd.conf";
$console_conf_file = "$config{'bacula_dir'}/console.conf";

sub connect_to_database
{
local $drh;
eval <<EOF;
use DBI;
\$drh = DBI->install_driver(\$config{'driver'} || "mysql");
EOF
if ($@) {
        die $text{'connect_emysql'}."\n";
        }
local $dbh = $drh->connect($config{'driver'} eq "Pg" ?
				"dbname=$config{'db'}" :
			   $config{'driver'} eq "mysql" ?
				"database=$config{'db'}" :
				$config{'db'},
                           $config{'user'}, $config{'pass'}, { });
$dbh || die &text('connect_elogin', "<tt>$config{'db'}</tt>",$drh->errstr)."\n";
local $testcmd = $dbh->prepare("select count(*) from job");
if (!$testcmd) {
	die &text('connect_equery', "<tt>$config{'db'}</tt>")."\n".
	    ($config{'driver'} eq "SQLite" ? $text{'connect_equery2'} : "");
	}
$testcmd->finish();
return $dbh;
}

# read_config_file(file)
# Parses a bacula config file
sub read_config_file
{
local @rv = ( );
local $parent = { 'members' => \@rv };
local $lnum = 0;
open(CONF, $_[0]);
while(<CONF>) {
	s/\r|\n//g;
	s/#.*$//;
	if (/^\s*}\s*$/) {
		# End of a section
		$parent = $parent->{'parent'};
		$parent || die "Too many section ends at line ".($lnum+1);
		}
	elsif (/^\s*(\S+)\s*=\s*"(.*)"(.*)$/ ||
	    /^\s*(\S+)\s*=\s*(\S+)(.*)$/) {
		# A name=value record
		local $rest = $3;
		local $dir = { 'name' => $1,
			       'value' => $2,
			       'line' => $lnum,
			       'type' => 1,
			       'parent' => $parent };
		push(@{$parent->{'members'}}, $dir);

		if ($rest =~ /\s*{\s*$/) {
			# Also start of a section!
			$dir->{'type'} = 2;
			$dir->{'members'} = [ ];
			$parent = $dir;
			}
		}
	elsif (/^\s*(\S+)\s*{\s*$/) {
		# Start of a section
		local $dir = { 'name' => $1,
			       'parent' => $parent,
			       'line' => $lnum,
			       'type' => 2,
			       'members' => [ ] };
		push(@{$parent->{'members'}}, $dir);
		$parent = $dir;
		}
	$lnum++;
	}
close(CONF);
return @rv;
}

# bacula_file_button(filesfield, [jobfield], [volume])
# Pops up a window for selecting multiple files, using a tree-like view
sub bacula_file_button
{
return "<input type=button onClick='ifield = document.forms[0].$_[0]; jfield = document.forms[0].$_[1]; chooser = window.open(\"treechooser.cgi?volume=".&urlize($_[2])."&files=\"+escape(ifield.value)+\"&job=\"+escape(jfield.value), \"chooser\", \"toolbar=no,menubar=no,scrollbar=no,width=500,height=400\"); chooser.ifield = ifield; window.ifield = ifield' value=\"...\">\n";
}

sub tape_select
{
local $t;
print "<select name=tape>\n";
foreach $t (split(/\s+/, $config{'tape_device'})) {
	print "<option>",&text('index_tapedev', $t),"\n";
	}
print "<option value=''>$text{'index_other'}\n";
print "</select>\n";
print "<input name=other size=40> ",&file_chooser_button("other", 1),"\n";
}

# job_select(&dbh, [volumne])
# XXX needs value input?
# XXX needs flag for use of 'any' field?
sub job_select
{
local $cmd;
if ($_[1]) {
	$cmd = $_[0]->prepare("select Job.JobId,Job.Name,Job.SchedTime ".
			      "from Job,JobMedia,Media ".
			      "where Job.JobId = JobMedia.JobId ".
			      "and Media.MediaId = JobMedia.MediaId ".
			      "and Media.VolumeName = '$_[1]'") ||
		&error("prepare failed : ",$dbh->errstr);
	}
else {
	$cmd = $_[0]->prepare("select JobId,Name,SchedTime from Job") ||
		&error("prepare failed : ",$dbh->errstr);
	}
$cmd->execute();
print "<select name=job>\n";
print "<option value=''>$text{'job_any'}\n";
while(my ($id, $name, $when) = $cmd->fetchrow()) {
	$when =~ s/ .*$//;
	print "<option value=$id>$name ($id) ($when)\n";
	}
print "</select>\n";
}

# client_select(&dbh)
sub client_select
{
local $cmd = $_[0]->prepare("select ClientId,Name from Client order by ClientId asc");
$cmd->execute();
print "<select name=client>\n";
while(my ($id, $name) = $cmd->fetchrow()) {
	print "<option value=$name>$name ($id)\n";
	}
print "</select>\n";
}

sub unix_to_dos
{
local $rv = $_[0];
$rv =~ s/^\/([a-zA-Z]):/$1:/;
return $rv;
}

sub dos_to_unix
{
local $rv = $_[0];
$rv =~ s/^([a-zA-Z]):/\/$1:/;
return $rv;
}

1;

