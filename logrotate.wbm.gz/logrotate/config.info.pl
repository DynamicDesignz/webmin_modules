line1=Opcje konfiguracyjne,11
sort_mode=Sortuj pliki log�w wed�ug,1,1-Nazwy,0-Kolejno�ci w pliku konfiguracyjnym
add_file=Dodaj nowe sekcje rotacji log�w do,3,G��wnego pliku konfiguracyjnego
line2=Konfiguracja systemu,11
logrotate_conf=�cie�ka do pliku konfiguracyjnego logrotate,0
logrotate=�cie�ka do programu logrotate,0
