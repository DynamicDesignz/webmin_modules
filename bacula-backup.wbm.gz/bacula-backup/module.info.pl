desc_pl=Bacula - system kopii zapasowej
longdesc_pl=Skonfiguruj Bacula do przeprowadzania kopii zapasowej i przywracania r�cznie lub wed�ug harmonogramu na jednym lub wielu systemach.
