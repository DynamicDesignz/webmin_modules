desc_pl=Klaster - Zmiana hase�
longdesc_pl=Zmie� has�a na wielu serwerach w klastrze Webmina r�wnocze�nie.
