line2=Konfiguracja systemu,11
pppoe_conf=Plik konfiguracji PPPOE ADSL,0
conf_style=Format pliku konfiguracyjnego,1,0-Standardowa konfiguracja RP-PPPoE,1-Plik sieciowy Redhat
pap_file=Plik kont PPP,0
pppoe_cmd=Pe�na �cie�ka do polecenia pppoe,0
start_cmd=Polecenie do podniesienia po��czenia ADSL,0
stop_cmd=Polecenie do zamkni�cia po��czenia ADSL,0
status_cmd=Polecenie do pobrania stanu po��czenia ADSL,0
