desc_pl=Dovecot - serwer IMAP/POP3
longdesc_pl=Konfiguracja Dovecot - serwera pobierania e-maili przez IMAP i POP3.
