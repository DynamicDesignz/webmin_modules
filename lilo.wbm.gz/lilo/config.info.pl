lilo_conf=�cie�ka do pliku konfiguracyjnego LILO,0
lilo_cmd=Polecenie aktywacji konfiguracji LILO,0
