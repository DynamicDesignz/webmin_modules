# etcupdate-lip.pl

do '../web-lib.pl';
do '../ui-lib.pl';
&init_config();


sub load_file {
    $filename = shift;
    open(file, "<$filename");
    my @result=<file>;
    close(file);
    return @result;
}

sub get_files {
    
    %filelist =();
    find(\&cfg_filter, "/etc/");
}

sub cfg_filter {
    if (/^\._cfg....\_(.*)$/) {
	$filelist{"$File::Find::dir/$1"}="$File::Find::name";
	#print &ui_columns_row(["$File::Find::name",""]);
    }
}

sub get_old_cfg($filename) {
    $_ = $filename;
    if (/^(.*)\._cfg....\_(.*)$/) {
	return $1 . $2;
    }
}
