=head1 hpsmartarry-lib.pl
 
=cut

BEGIN { push(@INC, "."); };
use WebminCore;
init_config();
