named_boot_file=Podstawowy plik konfiguracyjny,0
show_list=Wy�wietlaj domeny jako,1,0-Ikony,1-List�
soa_style=Posta� numeru seryjnego,1,0-Numer Kolejny,1-Oparty na dacie (RRRRMMDDnn)
records_order=Kolejno�� wy�wietlania rekord�w,1,1-Alfabetycznie,0-W&nbsp;kolejno�ci dodawania
named_pid_file=Plik z&nbsp;numerem ID procesu,0
named_pathname=Pe�na �cie�ka do <i>named</i>,0
