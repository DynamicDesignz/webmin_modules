$confdel=$text{'confirm_delete'};
print <<JS;
<SCRIPT>
function delfax(n)
{ if (confirm("$confdel")) { document.forms[0].rm.value=n; document.forms[0].submit(); }}
</SCRIPT>
JS

1;