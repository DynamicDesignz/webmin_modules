# general functions for hylafax module

do '../web-lib.pl';
&init_config();
require '../ui-lib.pl';

$HYLA_DIR=$config{'spool_path'};
$HYLA_CONF=$config{'conf_path'};
$HOST_NAME=`hostname`; chop($HOST_NAME);
$HOMESITE="www.tecchio.net";
$HOMEPAGE="webmin/hylafax";

sub hylacheck
{
  my @pidlist=&find_byname("faxq");
  if($pidlist[0] =='')
  {
  	return(-1);
  }

  my @pidlist=&find_byname("hfaxd");
  if($pidlist[0] =='')
  {
        return(-1);
  }
  return(1);
}

sub faxstat
# get the hylafax status
{ 
@status=split /\n/, `faxstat`;
print "<SMALL>", $status[0], "</SMALL>";
}

sub faxqueue
# get a hylafax queue (send, done, received)
# args: param - s, d, or r
# patched by Carl Pulley
{
my $param=shift;
@lines=split(/\n/,`faxstat -l$param`);
while (shift @lines) {}; shift @lines;
@return=();
$flag=1;
while (($value = shift @lines) && $flag == 1) {
  if ($value =~ /^Trying [\-_a-zA-Z0-9\.]+ \([0-9\.]+\) at port [0-9]+\.\.\./) {
    $flag = 0;
  } else {
    push(@return, $value);
  }
}
return @return;
}

sub trim 
{
# a trim function 
my $string = shift;
for ($string) 
	{
	s/^\s+//;
	s/\s+$//;
	}
return $string;
}

sub outLang
{
# return a translation from a language, if exists; othervise return the string itself
my $item=shift; $chk=$item;
$chk =~ s/\s/_/gi;
if ($text{$chk}) { return $text{$chk}; }
elsif ($text{lc($chk)}) { return $text{lc($chk)}; }
else { return $item; }
}

sub getFmt
{
# get the format codes for queues output
# args: job (J or R), field to extract (code,key,title,size,descr)
my ($job,$field)=@_; 
my @FMT=();
my $fmtkey=($job eq 'J')? 'JobFmt' : 'RcvFmt';
my $fmt=`cat $HYLA_CONF/hyla.conf | grep -E ^$fmtkey`;
$fmt =~ /^$fmtkey:\s*"(.+)"/; 
foreach (split /\s+/,$1)
    {
    /%-?(\d*)\.?(\d*)(\w)/;
    $char=$3;
    if ($field eq 'size') { push @FMT, ($1)? $1 : $2; }
    else
        {
        foreach (@jobcodes)
            {                
            ($code,$key,$title,$size,$descr)=split/;/;
            next unless $code =~ /$job/;
            push @FMT, $$field if $key eq $char;
            }
        }
    }            
return @FMT;    
}

sub queueItems
{
# retrieve the fields from a queue output
# args: $line - output line
# @sizes - array of field dimensions
my $line=shift;
@items=(); $n=0;
foreach $size (@_)
	{ 
    push @items, &trim(substr($line,$n,$size)); 
	$n+=($size+1);
	}
return @items;
}

sub docInfo
{
# retrieve document informations from spool dir    
# patched by Carl Pulley
my $item=shift;    
@fname=();
open INFO, "$HYLA_DIR/$item";
while (<INFO>)
    {
    chop; /^(.+):(.+)$/;
    $owner=$2 if $1 eq "owner";    
    push (@fname,$2) if index($1,"postscript")!=-1;
    }
close INFO;
return ($owner,@fname);
}
1;