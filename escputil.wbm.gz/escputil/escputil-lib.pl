# escputil-lib.pl

do '../web-lib.pl';
&init_config();
require '../ui-lib.pl';

$devargs = $config{'device'} ? "-r '$config{'device'}'" : "-u";

# get_printer_model()
# Returns the printer model name, or an empty string if one could not be found
sub get_printer_model
{
local $out = `$config{'escputil'} -q -d $devargs 2>/dev/null`;
if ($out =~ /(EPSON\s+[^:;]+)/) {
	return $1;
	}
return undef;
}

# get_printer_status()
sub get_printer_status
{
local @rv;
open(STATUS, "$config{'escputil'} -q -s $devargs 2>/dev/null |");
while(<STATUS>) {
	s/\r|\n//g;
	if (/^\S+:/) {
		push(@rv, $_);
		}
	}
close(STATUS);
return @rv;
}

# get_ink_levels()
# Returns an array, each element of which is a colour name and percent
sub get_ink_levels
{
local @rv;
local $pid = open(INK, "$config{'escputil'} -q -i $devargs |");
local $rmask;
vec($rmask, fileno(INK), 1) = 1;
local $rv = select($rmask, undef, undef, 5);
if ($rv == 1) {
	while(<INK>) {
		if (/^\s*(\S.*\S)\s+(\d+)/) {
			push(@rv, [ $1, $2 ]);
			}
		}
	}
else {
	kill('KILL', $pid);
	}
close(INK);
return @rv;
}

# try_several(&func)
sub try_several
{
local $w = wantarray;
local $func = $_[0];
local $n;
for($n=0; $n<5; $n++) {
	local @rv = &$func;
	if ($w) {
		return @rv if (@rv);
		}
	else {
		return $rv[0] if ($rv[0] =~ /\S/);
		}
	sleep(1);
	}
return wantarray ? ( ) : undef;
}

1;

