
require 'mysql-lib.pl';

sub cpan_recommended
{
return ( "DBI", "DBD::mysql" );
}

