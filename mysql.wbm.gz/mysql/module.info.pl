desc_pl=MySQL - serwer baz danych
