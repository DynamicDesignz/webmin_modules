desc_pl=Klaster - Kopia plik�w
longdesc_pl=Zaplanowany transfer plik�w z tego serwera do innych serwer�w w klastrze.
