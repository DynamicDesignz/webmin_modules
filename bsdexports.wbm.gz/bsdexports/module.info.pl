desc_pl=Udost�pnianie po NFS
