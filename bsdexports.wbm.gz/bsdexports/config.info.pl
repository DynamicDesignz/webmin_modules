exports_file=Plik 'exports',0
restart_command=Polecenie restartuj�ce mountd i&nbsp;nfsd,0
