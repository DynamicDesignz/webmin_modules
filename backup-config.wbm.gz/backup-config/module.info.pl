desc_pl=Kopia plik�w konfiguracyjnych
longdesc_pl=R�czne lub zaplanowane tworzenie i przywracanie kopii zapasowych plik�w konfiguracyjnych modu��w zarz�dzanych przez Webmina.
