# Common functions for managing ACL lists
# XXX new icon

do '../web-lib.pl';
&init_config();
&foreign_require("squid", "squid-lib.pl");
&foreign_require("cron", "cron-lib.pl");

$acl_directory = "$module_config_directory/acls";
$cron_cmd = "$module_config_directory/refresh.pl";

# list_acls()
# Returns a list of all server-name ACLs managed by this module
sub list_acls
{
local @rv;
local $conf = &squid::get_config();
foreach $acl (&squid::find_config("acl", $conf)) {
	if ($acl->{'values'}->[1] eq "dstdomain" &&
	    $acl->{'values'}->[2] =~ /^"(.*)"/) {
		local $info = { 'name' => $acl->{'values'}->[0],
				'file' => $1,
				'acl' => $acl };
		&read_file("$acl_directory/$info->{'name'}", $info);
		push(@rv, $info);
		}
	}
return @rv;
}

sub save_acl
{
local %info = %{$_[0]};
delete($info{'name'});
delete($info{'file'});
delete($info{'acl'});
mkdir($acl_directory, 0755);
&write_file("$acl_directory/$_[0]->{'name'}", \%info);
}

# delete_acl(&acl)
sub delete_acl
{
unlink("$acl_directory/$_[0]->{'name'}");
}

# download_acl(&acl, [callback])
# Does the actual downloading of a website to an ACL file
sub download_acl
{
local %done_url;
local @domains = &download_recursive($_[0]->{'url'}, $_[0]->{'recur'}, $_[1]);
if (@domains) {
	@domains = &unique(@domains);
	open(FILE, ">$_[0]->{'file'}");
	foreach my $d (@domains) {
		print FILE $d,"\n";
		}
	close(FILE);
	}
return scalar(@domains);
}

sub download_recursive(url, count-left, [&callback])
{
return if ($_[1] <= 0);
return if ($done_url{$_[0]}++);
if ($_[2]) {
	&{$_[2]}($_[0]);
	}

my ($host, $port, $page, $ssl) = &parse_http_url($_[0]);
return ( ) if (!$host);

# Make the connection
$download_timed_out = undef;
local $SIG{ALRM} = "download_timeout";
alarm(30);
local $h = &make_http_connection($host, $port, $ssl, "GET", $page);
return ( ) if (!ref($h));
local @rv;
&write_http_connection($h, "Host: $host\r\n");
&write_http_connection($h, "User-agent: Webmin\r\n");
&write_http_connection($h, "\r\n");

# Read back headers
local $line = &read_http_connection($h);
if ($line !~ /^HTTP\/1\..\s+(200|302|301)\s+/) {
	return ( );
	}
local %header;
while(1) {
	$line = &read_http_connection($h);
	$line =~ s/\r|\n//g;
	$line =~ /^(\S+):\s+(.*)$/ || last;
	$header{lc($1)} = $2;
	}
alarm(0);
return ( ) if ($download_timed_out);

if ($header{'location'}) {
	return &download_recursive($header{'location'}, $_[1], $_[2]);
	}

push(@rv, lc($host));
if ($header{'content-type'} =~ /text\/html/i && $_[1] > 1) {
	# If this looks like HTML, parse it for links
	local ($data, $buf);
	while($buf = &read_http_connection($h, 1024)) {
		$data .= $buf;
		}
	local (@rellinks, @links, $l);
	$data =~ s/(src|href|action)\s*=\s*'([^']*)'/push(@rellinks,$2)/gei;
	$data =~ s/(src|href|action)\s*=\s*"([^"]*)"/push(@rellinks,$2)/gei;
	$data =~ s/(src|href|action)\s*=\s*([^ "'>]*)/push(@rellinks,$2)/gei;
	$data =~ s/((http:|https:)\/\/([^ "'>]*))/push(@rellinks,$1)/gei;
	foreach $l (&unique(@rellinks)) {
		next if ($l =~ /^(ftp|mailto|gopher):/i);
		local ($lhost, $lport, $lpage, $lssl) =
			&parse_http_url($l, $host, $port, $page, $ssl);
		if ($lhost) {
			push(@links, ($lssl ? "https://" : "http://").
				     $lhost.($lport == ($lssl ? 443 : 80) ? "" : ":$lport").$lpage);
			push(@rv, lc($lhost));
			}
		}

	# Recursively fetch any non image-looking pages
	foreach $l (@links) {
		if ($l !~ /\.(png|gif|jpg|jpeg)/i) {
			push(@rv, &download_recursive($l, $_[1]-1, $_[2]));
			}
		}
	}

&close_http_connection($h);
return @rv;
}

1;

