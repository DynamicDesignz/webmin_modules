#!/usr/local/bin/perl
# Refresh an ACL

$no_acl_check++;
require './generate-lib.pl';
@acls = &list_acls();
($acl) = grep { $_->{'name'} eq $ARGV[0] } @acls;
if ($acl) {
	&download_acl($acl);
	}
