exports_file=Plik 'exports',0
restart_command=Polecenie restartu serwera NFS,0
