# firewall-lib.pl
#
# $Id: firewall-lib.pl,v 1.2 2003/08/11 10:14:39 r_kleipool Exp $
#
# FreeBSD firewall functions
#

use vars qw($current_comment);
$current_comment="";

do '../web-lib.pl';
init_config();

#
# check for firewall on
#
sub check_firewall(){
  return 1;
} #check_firewall
#
# parse_ipfw(rule_list)
# Parse the output of ipfw list
#
sub parse_ipfw($@){
# Parse the rules from ipfw program or config file
# input:  A reference to a rules hash-list
# input:  A list of all lines of the firewall.
#         This can come from the ipfw program or a config file
# Return: A reference to a hash. Keys are the items that can be on a line
	my $rules=shift;
	my @rule_list=@_;

	foreach (@rule_list){
		my $whole_line = $_;
		my @fields= split / /;
		my %rule;

		$_=$fields[0];
		SWITCH: {
			if ( /^#/ )      { comment($whole_line); last SWITCH; };
			if ( /[0-9]+/ )  { 
				my $rule_number=shift @fields;
				$rule{'number'}=$rule_number+0;
				rule_line(\%rule, @fields);
				push @$rules, \%rule;
				last SWITCH;
			}; # if rule number
    } # Switch first field
    $rule_lineno++;
  } #foreach rule
  return \@rules;
} # parse_ipfw

sub comment(){
# Not implemented YET...
# This function gets an comment line from the firewall.conf file
# It will add this comment to the next rule taken from the file.
  $current_comment=$_;
} #comment

sub rule_line($@){
	my $rule=shift;
	my @fields=@_;
	$_=$fields[0];
	SWITCH: {
		if ( /set/ )     { rule_set($rule, @fields);			last SWITCH; };
		if ( /prob/ )    { rule_probability(@fields);		last SWITCH; };
		if ( /allow/ )   { rule_action($rule, @fields);		last SWITCH; };
		if ( /accept/ )  { rule_action($rule, @fields);		last SWITCH; };
		if ( /pass/ )    { rule_action($rule, @fields);		last SWITCH; };
		if ( /permit/ )  { rule_action($rule, @fields);		last SWITCH; };
		if ( /deny/ )    { rule_action($rule, @fields);		last SWITCH; };
		if ( /drop/ )    { rule_action($rule, @fields);		last SWITCH; };
		if ( /count/ )   { rule_action($rule, @fields);		last SWITCH; };
		if ( /check-state/ )  { rule_check_state(@fields); last SWITCH; };
		if ( /divert/ )  { rule_divert($rule, @fields);		last SWITCH; };
	} # switch fields[1]
} #rule_number

sub rule_set(){
  my $rule=shift;
  shift;  # get rid of "set"
  $rule->{set}=shift;
  my @fields=@_;
  rule_line($rule, @fields);
} #rule_set

sub rule_action($@){
# handle an allow, deny etc. action
	my $rule=shift;
	$rule->{action}=shift;
	my @fields=@_;
	rule_body($rule, @fields);
} #rule_action

sub rule_divert($@){
# Handle divert <port> 
  my $rule=shift;
  $rule->{'action'}=shift;      # is divert
  $rule->{'divert_port'}=shift; # divert port
  my @fields=@_;
  rule_body($rule, @fields);
} #rule_action

sub rule_body($@){
  my $rule=shift;
  my $protocol=shift;
  shift; #loose from
  my ($src, $sport, $dst, $dport);
  $sport=$dport="";

  my $src=shift;  # src ip + mask
  if ( $_[0] !~ /to/ ) {
    # Has port or port range
    $sport=shift;
  }# if port number

  shift; # Loose to

  $dst=shift;

  $rule->{protocol}=$protocol;
  $rule->{src}=$src;
  $rule->{sport}= $sport;
  $rule->{dst}=$dst;
  $rule->{dport}= $dport;
}#rule_body

sub parse_post($){
# construct a rules hash from the posted variables
# Input: a reference to a hash-list to store the data
# Return reference to rules list
	my $rule_listref=shift;
	my %rules;
	my ($ip, $mask);
	# construct a hash %rules{rule_numer}{field}
  foreach (keys %in){
    my ($part,$rule) = split /_/;
    $rule=$in{"number_$rule"} if $rule =~ /^new/ ;
    $rule+=0; #convert to number
    $rules{$rule}{$part}=$in{$_} if not exists $in{"delete_$rule"};
  }#foreach keys
  # Check posted vars in %rules
	if (exists $rules{'0'}) { delete $rules{'0'}; } # delete empty new rule
	foreach (sort keys %rules){
		my $rule = $rules{$_};
		$rule->{'number'}+=0; #convert to number
		if ($rule->{'protocol'} =~ /udp|tcp/) {
			# tcp or udp with empty ports is any
			$rule->{'sport'}='any' if $rule->{'sport'} eq '';
			$rule->{'dport'}='any' if $rule->{'dport'} eq '';
		} else {
			# Other protocols must have empty ports
			if ($rule->{'sport'} ne '') {
				$rule->{sport}="<font color=#FF0000>$rule->{sport}</font>";
				$error_out="$text{error_port_must_empty}: $rule->{number}<br>\n";
			}#if not empty sport
			if ($rule->{'dport'} ne '') {
				$rule->{dport}="<font color=#FF0000>$rule->{dport}</font>";
				$error_out="$text{error_port_must_empty}: $rule->{number}<br>\n";
			}#if not empty dport
		}# if tcp or udp
		($ip, $mask) = split /\//, $rule->{'src'};
		if (not check_ipaddress( $ip ) and not $ip eq 'any') {
			$rule->{src}="<font color=#FF0000>$rule->{src}</font>";
			$error_out.="$text{error_invalid_ip}: $rule->{number} $ip <br>\n";
		}#if ip error
		if ( $mask > 32 or $mask < 1 and not $ip eq 'any' and not $mask eq '') {
			$rule->{src}="<font color=#FF0000>$rule->{src}</font>";
			$error_out.="$text{error_invalid_mask}: $rule->{number} $mask<br>\n";
		}#if mask error
		($ip, $mask) = split /\//, $rule->{'dst'};
		if (not check_ipaddress( $ip ) and not $ip eq 'any') {
			$rule->{dst}="<font color=#FF0000>$rule->{dst}</font>";
			$error_out.="$text{error_invalid_ip}: $rule->{number} $ip<br>\n";
		}#if ip error
		if ( $mask > 32 or $mask < 1 and not $ip eq 'any' and not $mask eq '') {
			$rule->{src}="<font color=#FF0000>$rule->{src}</font>";
			$error_out.="$text{error_invalid_mask}: $rule->{number} $mask<br>\n";
		}#if mask error
		# push the result onto list
		push @$rule_listref, $rule;
	}# foreach rule
}#parse_post

sub save_current_rules{
# quick way to save current rules to a file in script format for the restore process
# We do not save set 31 rules
	open RULES, "ipfw -S list|";
	open SAVED_RULES, ">$temp_filename";
	print SAVED_RULES "ipfw -q flush\n";
	while (<RULES>) {
		print SAVED_RULES "ipfw -q add $_" unless /set 31/;
	}#while rules
	close RULES; close SAVED_RULES;
}#save_current_rules

sub save_rules_rc($){
# save the current rules in firewall.conf format.
# input: a filename to save (possibly /etc/firewall.conf)
	my $filename=shift;
	open RULES, "ipfw -S list|"; open RC_FILE, ">$filename";
	while (<RULES>){

		print RC_FILE "add $_" unless /set 31/;
	}#while rules
	close RULES; close RC_FILE;
}#save_rules_rc

sub firewall_script($$){
# create statements for the ipfw program from rules hash-list
# input: a reference to a rules hash-list
# input: a reference to a list to contain the statements
# output: the statement list referenced variable
   my $rule_ref=shift;
	my $statement_list=shift;
   my $statement;
	push @$statement_list, "ipfw -q flush";
   foreach $rule (@$rule_ref) {
		next if $rule->{set} == 31;
		if ( $rule->{action} eq "divert" ) { $rule->{action}.=" $config{divert_port}"; }
      $statement =" ipfw -q add $rule->{number} set $rule->{set} $rule->{action} $rule->{protocol} from";
      $statement.=" $rule->{src} $rule->{sport} to $rule->{dst} $rule->{dport}";
		push @$statement_list, $statement;
   }#foreach rule
   return $statement_list;
}#firewall_script

sub do_rules($){
# perform firewall statements one by one and watch for errors
# write html on failure and success
# input: a reference to a ipfw statement list
	my $statement_ref=shift;
	my ($statement, $html, $ret_val, $error);

	foreach $statement ( @$statement_ref){
		if ( ( $ret_val=system($statement) ) != 0 ) {
		# an error occured
			$error= qq{<font color="#FF0000">ERROR: $statement</font> Return code from ipfw: $ret_val<br>\n};
			$html.=$error; $error_out.=$error;
			last;
		} else {
			$html.="$statement<br>\n";
		}# if error
	}# for each statement
	if ( $ret_val != 0 ) {
		$error_out.="$text{recover_needed}<br>";
		open OLD_RULES, $temp_filename or $error_out.="Can't open $temp_filename<br>\n";
		$error_out.="<font color=#000000>\n";
		while ( <OLD_RULES> ) {
			system $_;
			$error_out.="$text{recover_restored} $_<br>\n";
		}#while old rules
		close OLD_RULES;
		$error_out.="</font>\n";
	}#if error
	return $html;
}# do_rules

sub start_recover_process($){
# Start a sub process that will restore the firewall rules
#  after a certain timeout
# input: a filename of a firewall script with rules to restore
# output: a pid of the child process
	my $firewall_script=shift;
	my $pid;
	FORK: {
		if ( $pid = fork) {
			#parent
			return $pid;
		} elsif (defined $pid) {  # pid is zero if defined
			#child
			close STDOUT; close STDIN; close STDERR;
			open STDIN, "/dev/null"; open STDOUT, ">/dev/null"; open STDERR, ">&STDOUT";
			exec qq~sleep $config{restore_timeout}; sh $firewall_script; logger -p user.warn 'webmin firewall-fbsd; restored firewall rules after timeout.'~;
			# NOT REACHED
		} elsif ($! =~ /No more process/) {
			# EAGAIN: no more processus, try again
			sleep 3;
			redo FORK;
		} else {
			#Weird fork error
			$error_out.="$text{error_fork} error is: $!<br>";
		}
		return $pid;
	}# FORK
}# start_recover_process
###
######### Web html #######
###
sub rule_form_html($){
	my $rules_ref=shift;
	my $html="<table>\n";
	$html.=<<EINDE;
    <tr>
      <th valign=bottom>$text{firewall_delete}</th>
      <th valign=bottom>$text{firewall_rule}</th>
      <th valign=bottom>$text{firewall_set}</th>
      <th valign=bottom>$text{firewall_action}</th>
      <th valign=bottom>$text{firewall_protocol}</th>
      <th valign=bottom></th>
      <th valign=bottom>$text{firewall_src}</th>
      <th valign=bottom>$text{firewall_port}</th>
      <th valign=bottom></th>
      <th valign=bottom>$text{firewall_dst}</th>
      <th valign=bottom>$text{firewall_port}</th>
    </tr>
EINDE
	foreach $rule ( @$rules_ref ) {
		my $number=$rule->{number};
		$html.="<tr>\n";
		$html.="<td><input type=checkbox name=delete_$number></td>\n";
		$html.=rule_number_html($rule);
		$html.=rule_set_html($rule);
		$html.=rule_action_html($rule);
		$html.=rule_protocol_html($rule);
		$html.=rule_from_html($rule);
		$html.="</tr>\n";
	}#foreach rule
	$html.="<tr><td colspan=10>$text{firewall_add_rule}</td></tr>";
	$html.=rule_add_html();
	return $html . "</table>\n";
}# rule_form_html

sub rule_number_html(){
# Show textbox for rulenumber
 my $number=$_[0]->{number};
 return "<td align=right><input type=text name=number_$number size=5 style=\"border: 0 solid #FFFFFF\" value=$number></td>\n";
}# rule_number_html

sub rule_set_html($){
# show dropdown with set number
	my $rule_set=$_[0]{'set'}+0;
	my $number=$_[0]->{'number'};
	my $i;
	my $html="<td><select size=1 name=set_$number>";

	for ($i=0; $i<31; $i++) {
		$html.="\n <option" . ($rule_set == $i ? " selected>" : ">") . "$i</option>";
	}# for sets
	$html.="\n <option selected>31</option>" if $rule_set == 31;
	return "$html\n</select></td>\n";
}#rule_set_html

sub rule_action_html($){
# show dropdown list with valid_actions
  my $rule_action=$_[0]->{'action'};
  my $number=$_[0]->{'number'};
  my @valid_actions=split / /, $config{valid_actions};

  my $html="<td><select size=1 name=action_$number>";
  
  foreach $actie ( @valid_actions ) {
   $html .= "\n <option" . ($rule_action eq $actie ? " selected>" : ">") . $actie . "</option>";
  }
  return $html . "\n</select></td>\n";
}#rule_action_html

sub rule_protocol_html($){
# show an option box for the protocols
  my $rule_protocol=$_[0]->{protocol};
  my $number=$_[0]->{number};
  my @valid_protocols=split / /, $config{valid_protocols};

  my $html="<td><select size=1 name=protocol_$number>";
  foreach $proto ( @valid_protocols ) {
   $html .="\n <option" . ($rule_protocol eq $proto ? " selected>" : ">") . $proto . "</option>";
  }
  return $html . "\n</select></td>\n";
}#rule_protocl_html

sub rule_from_html($){
# Print html for rule_body: from netw/mask port to netw/msk port
  my $number=$_[0]->{number};
  my $rule_src=$_[0]->{src};
  my $rule_sport=$_[0]->{sport};
  my $rule_dst=$_[0]->{dst};
  my $rule_dport=$_[0]->{dport};

  my $html="<td>$text{firewall_from}</td>";
  $html.=qq#<td><input type=text size=16 value="$rule_src" name=src_$number></td>#;
  $html.=qq#<td><input type=text size=8 value="$rule_sport" name=sport_$number></td>#;
  $html.=qq#<td>$text{firewall_to}</td>#;
  $html.=qq#<td><input type=text size=16 value="$rule_dst" name=dst_$number></td>#;
  $html.=qq#<td><input type=text size=8 value="$rule_dport" name=dport_$number></td>#;
  return $html;
}#rule_from_html
 
sub rule_add_html(){
# Add new firewall rule lines
	my ($line, $set, $action, $protocol, $body, $html);
	for ($line=1; $line<=$config{add_lines}; $line++){
		$set=rule_set_html( {'number' => "new$line", 'set' => 0} );
		$action=rule_action_html( {'number' => "new$line", 'action' => ''} );
		$protocol=rule_protocol_html( { 'number' => "new$line", 'protocol' => 'ip'} );
		$body=rule_from_html( { 'number' => "new$line"} );
		$html.=<<EINDE;
  <tr>
    <td>&nbsp;</td>
    <td><input type=text size=8 name=number_new$line></td>
    $set
    $action
    $protocol
    $body
  </tr>
EINDE
	}#for lines
	return $html;
}#rule_add_html

# confirmation form
sub rule_list_html($){
# List the rules in @rule_ref for confirmation
	my $rule_ref=shift;
	my $html="<table>\n";
	foreach $rule ( @$rule_ref){
		if ( $rule->{action} eq "divert" ) { $rule->{action}.=" $config{divert_port}";}
		$html.=<<EINDE;
  <tr>
    <td align=right>$rule->{number}</td><td align=right> set $rule->{set}</td>
    <td>$rule->{action}</td><td>$rule->{protocol}</td><td>from</td>
    <td>$rule->{src}</td><td>$rule->{sport}</td>
    <td>to</td><td>$rule->{dst}</td>
    <td>$rule->{dport}</td>
  </tr>
EINDE
  }#while rules
  $html.="</table>\n";
  return $html;
}#rule_list_html

sub rule_list_as_vars($){
# List the rules in rule_ref as hidden form fields
	my $rule_ref=shift;
	my $html;
	foreach $rule (@$rule_ref){
		my $rule_number=$rule->{number};
		foreach $field (keys %$rule){
			$html.="   <input type=hidden name=${field}_${rule_number} value=\"$rule->{$field}\">\n";
		}# foreach field
	}#foreach rule
	return $html;
}#rule_list_as_vars
