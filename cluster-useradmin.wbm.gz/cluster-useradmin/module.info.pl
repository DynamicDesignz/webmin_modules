desc_pl=Klaster - U�ytkownicy i grupy
longdesc_pl=Tw�rz, aktualizuj i usuwaj u�ytkownik�w i grupy na wielu serwerach. Inaczej ni� w NIS, ka�dy serwer ma w�asny plik has�a i grupy, kt�ry jest zdalnie aktualizowany przez ten modu�.
