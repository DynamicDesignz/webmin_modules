majordomo_cf=Pe�na �cie�ka do pliku konfiguracyjnego majordomo,0
program_dir=Katalog zawieraj�cy programy majordomo,0
wrapper_path=�cie�ka do wrappera majordomo,3,W&nbsp;katalogu program�w
aliases_file=Plik alias�w w stylu Sendmaila,3,Pobierz z sendmail.cf
dynamic=U�ywa� losowych alias�w list,1,1-Tak,0-Nie
sort_mode=Porz�dkuj listy wed�ug,1,1-Nazwy,0-Kolejno�ci utworzenia
smrsh_program_dir=Katalog zawieraj�cy bezpieczne programy sendmail,3,Gdziekolwiek
