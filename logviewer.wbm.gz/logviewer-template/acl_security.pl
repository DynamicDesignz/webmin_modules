
require '../logviewer/logviewer-lib.pl';
# acl_security_form(&options)
# Output HTML for editing security options for the servers module
sub acl_security_form
{
local $o = $_[0];
print "<tr> <td valign=top><b>$text{'acl_servers'}</b></td>\n";
print "<td colspan=2>\n";

print "<tr> <td><b>$text{'acl_des'}</b></td> <td>";
print_checkbox_acl('access_des',$o);
#print "<input type=checkbox name=access_des ",
#    $o->{'access_des'} ne '' ? 'checked' : '' , "></td>\n";

print "<tr> <td><b>$text{'acl_pre'}</b></td> <td>";
print_checkbox_acl('access_pre',$o);
#print "<input type=checkbox name=access_pre ",
#    $o->{'access_pre'} ne '' ? 'checked' : '' , "></td>\n";

print "<tr> <td><b>$text{'acl_pro'}</b></td> <td>";
print_checkbox_acl('access_pro',$o);

print "<tr> <td><b>$text{'acl_debug'}</b></td> <td>";
print_checkbox_acl('can_debug',$o);
}

# acl_security_save(&options)
# Parse the form for security options for the servers module
sub acl_security_save
{
$_[0]->{'access_des'} = $in{'access_des'};
$_[0]->{'access_pre'} = $in{'access_pre'};
$_[0]->{'access_pro'} = $in{'access_pro'};
$_[0]->{'can_debug'} = $in{'can_debug'};
}

