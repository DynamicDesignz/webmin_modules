#!/usr/bin/perl

sub load_servers
{
# Load the servers lists
# Define the array with the servers lists
$servers_list = {
		# Weblogic linux
		wllinux  => {
			    P => "plapphp01f plapphp02f",
			    Q => "qlapphp01f qlapphp02f",
			    D => "dlapphp01f"
			    },
		# Weblogic AIX
		wlaix	  => {
			    P => "saturno",
			    Q => "triton",
			    D => "triton"
			    },
		# Explotación
		explo	  => {
			    P => "plappfj03f plappfj05f",
		  	    Q => "qlapphp01v",
			    D => "dlapphp07v"
			    },
		};

# Fin de listas de servidores
print "$servers_list->{'wllinux'}->{'D'}\n";

}

load_servers;
