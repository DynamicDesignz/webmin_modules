
=head1 logviewer-lib.pl

Functions for managing remote log viewing

=cut

BEGIN { push(@INC, ".."); };
use WebminCore;
use Socket;
&init_config();
%access = &get_module_acl();

=head2 load_servers

Loads the servers lists

=cut
sub load_servers
{
# Servers lists.

$servers_list = {
                # Weblogic linux
                wllinux  => {
                            P => "wlpro01 wlpro02",
                            Q => "wlprepro01",
                            D => "dlapphp01f"
                            },
                # Weblogic AIX
                wlaix     => {
                            P => "saturno",
                            Q => "triton",
                            D => "triton"
                            },
                # Explotación
                explo     => {
                            P => "plappfj03f plappfj05f",
                            Q => "qlapphp01v",
                            D => "dlapphp07v"
                            },
                };

#print "$servers_list->{'wllinux'}->{'D'}\n";

}


=head2 can_debug()

Returns 1 if the user can view debug info

=cut
sub can_debug
{
    if ( $access{'can_debug'} )
    {
        $allowed=1;
    } else {
	$allowed=0;
    }
    return $allowed;
}

=head2 can_access_des()

Returns 1 if the user can access development

=cut
sub can_access_des
{
    if ( $access{'access_des'} ne '' and $config{'servers_des'} )
    {
        $allowed=1;
    } else {
	$allowed=0;
    }
    return $allowed;
}


=head2 can_access_pre()

Returns 1 if the user can access preproduction

=cut
sub can_access_pre
{
    if ( $access{'access_pre'} ne '' and $config{'servers_pre'} )
    {
        $allowed=1;
    } else {
	$allowed=0;
    }
    return $allowed;
}

=head2 can_access_pro()

Returns 1 if the user can access production

=cut
sub can_access_pro
{
    if ( $access{'access_pro'} ne '' and $config{'servers_pro'} )
    {
        $allowed=1;
    } else {
	$allowed=0;
    }
    return $allowed;
}

=head2 print_checkbox_acl()

Prints a checkbox in acl form, with the name and checked depending on its value

=cut
sub print_checkbox_acl
{
    $varname=$_[0];
    $vararray=$_[1];
    $varvalue=eval "\"$vararray->{$varname}\"";
    print "<input type=checkbox name=$varname ",
         $varvalue ne '' ? 'checked' : '' , "></td>\n";
}

=head2 set_servers_lists()

Sets the $config variable for runtime according to the module config settings

=cut
sub set_servers_lists
{
    load_servers;
    $family=$config{'server_family'};
    if ( $family ne 'custom' )
    {
	$config{'servers_des'}=$servers_list->{$family}->{'D'};
	$config{'servers_pre'}=$servers_list->{$family}->{'Q'};
	$config{'servers_pro'}=$servers_list->{$family}->{'P'};
    } 
}

=head2 print_servers()

Once passed ACL checks, print servers for a specific environment

=cut
sub print_servers
{
    $family=$config{'server_family'};
    $servers=$config{$_[0]};
    @servers=split(' ',$servers);
#    print "<p>DEBUG1: $servers,$family</p>";
    $temprow=scalar @servers;
    print "<tr>\n";
    print "   <td rowspan=\"",$temprow,"\">", $_[1], "</td>\n";
    foreach $server_name (@servers)
    {
        # For a right html rowspan, we have to control from the second <tr> on
	if ($temprow == 0)
	{
	    print "<tr>";
	}
	$temprow = 0;
    	print "      <td><a href='./view_directory.cgi?directory=", $config{'remote_dir'}, "&machine=", $server_name, "'>Logs de <b>", $server_name ,"</b></a></td>\n";
	print "</tr>\n";
    }
    
}

=head2 print_servers_lists()

Check acl and prints the whole servers accordingly

=cut
sub print_servers_lists
{
    set_servers_lists;
    $family=$config{'server_family'};
    $servers=eval "\"$servers_list->{$family}->{'D'}\"";
#    print "<p>DEBUG0: $servers,$family</p>";

    print "<table border width=100%>\n<tr $tb> <td><b>$text{'index_environment'}</b></td>\n<td><b>$text{'index_servers'}</b></td></tr>\n";

    if ( can_access_des )
    {
	print_servers (servers_des, $text{'env_des'});
    }
        
    if ( can_access_pre )
    {
	print_servers (servers_pre, $text{'env_pre'});
    }

    if ( can_access_pro )
    {
	print_servers (servers_pro, $text{'env_pro'});
    }

    print "</table>\n";
}


=head2 run_local_command

Runs a local command via webmin API

=cut
sub run_local_command
{
    $localcommand=$_[0];
    $result=foreign_call("proc", "safe_process_exec",
                    $localcommand,
                    0, 0, STDOUT, undef, 1);
    print "DEBUG: localcommand: $localcommand, server: $server\n" if can_debug;

}

=head2 run_ssh_command

Sets the ssh options and runs the specified remote command

=cut
sub run_ssh_command
{
    if ($config{'ssh_configfile'}) {
	$sshoption = "-F $config{'ssh_configfile'}";
    }
    
    my $server=$_[0];
    my $sshcommand=$_[1];
#    	! open(IN,"ssh $sshoption $in{'machine'} \"ls -ld $in{'directory'}/* |grep ^[d-] \" |")
#     $ssh_result=open(IN,"ssh $sshoption $server $sshcommand |");
#     $ssh_result=qx("ssh $sshoption $server $sshcommand");
#    $got = &foreign_call("proc", "safe_process_exec",
#        "ssh $sshoption $in{'machine'} cat $fullpath | grep $filter | tail -n $lines",
#        0, 0, STDOUT, undef, 1);
    print "DEBUG: server: $server, sshcommand=$sshcommand\n" if can_debug;
    foreign_call("proc", "safe_process_exec",
        "ssh $sshoption $server $sshcommand |sed -e 's/\\n/\<br\>/g'",
        0, 0, STDOUT, undef, 1);
}


=head2 print_directory_index()

Prints the browsed directory entries

=cut
sub print_directory_index
{

    # The table starts here
    print "<table border>\n";
    print "<tr $tb> <td><b>$text{'index_type'}</b></td>",
      "<td><b>$text{'index_item'}</b></td>\n<td>",
      "<b>$text{'index_size'}</b></td>",
      "</tr>";
    
    if ( $server ne "localhost" )
    {
    if ($config{'ssh_configfile'}) {
	$sshoption = "-F $config{'ssh_configfile'}";
    }
        open(IN,"ssh $sshoption $server \"ls -ld $in{'directory'}/* |grep ^[d-] \" |");
#        open(IN,&run_ssh_command($server,"ls -ld $in{'directory'}/* |grep ^[d-] |"));
    }
    else
    {
	open(IN,"ls -ld $in{'directory'}/* |grep ^[d-]  |");
#	open(IN,&run_local_command("ls -ld $in{'directory'}/* |grep ^[d-]  |"));
    }
    
#    print "localcommand=$localcommand, server=$server";
    my @exceptions=('lost+found');
    while (<IN>)
    {
	$att=substr($_,0,1);
	@line=split('/',$_);
	$file=pop(@line);
	chomp $file;
	$size=(split /\s+/, $_)[4];
	foreach $exception (@exceptions)
	{
	    $size='NULL' if ($file eq $exception);
	    #print "<!-- comparing $file with $exception: $size  -->";
	}
	if ($size ne NULL)
	{
	    #print "<!-- line: $_ -->";
	    print "<tr $cb> <td>\n";
	    if ($att =~ /d/)
	    {
	        print "$text{'index_directory'}</td>";
	        print "<td><a href=\"view_directory.cgi?machine=$server&directory=$in{'directory'}\/$file&jobname=$in{'jobname'}\">$in{'directory'}\/$file</a>\n";
	    }
	    else
	    {
	        print "$text{'index_file'}</td>";
	        print "<td><a href=\"view_log.cgi?machine=$server&file=$file&directory=$in{'directory'}&jobname=$in{'jobname'}\">$in{'directory'}\/$file</a>\n";
	    }
	    print "</td><td>$size bytes";
	}
	print "</td> </tr>\n";
    }

    print "</table>\n";
    print "<p>\n";

}

=head2 print_filter_form()

Outputs the html textboxes in order to input filters

=cut
sub print_filter_form
{
    $lines = $in{'lines'} ? int($in{'lines'}) : $config{'lines'};
    $filter = $in{'filter'} ? quotemeta($in{'filter'}) : "";
    print "<form action=view_log.cgi style='margin-left:1em'>\n";
    print "<input type=hidden name=machine value='$in{'machine'}'>\n";
    print "<input type=hidden name=file value='$in{'file'}'>\n";
    print "<input type=hidden name=directory value='$in{'directory'}'>\n";
    print "<input type=hidden name=jobname value='$in{'jobname'}'>\n";
    print &text('view_header', "<input name=lines size=3 value='$lines'>",
            "<tt>".&html_escape($in{'file'})."</tt>"),"\n";
    print "&nbsp;&nbsp;\n";
    print &text('view_filter', "<input name=filter size=15 value='$in{'filter'}'>"),"\n";
    print "&nbsp;&nbsp;\n";
    print "<input type=submit value='$text{'view_refresh'}'></form>\n";
}

=head2 print_log_file()

Prints the log file

=cut
sub print_log_file
{

    &print_filter_form();
    
#print "<marquee scrollamount=\"2\" direction=\"up\" loop=\"true\" width=98% onMouseOver=\"this.stop()\" onMouseOut=\"this.start()\">";
    $| = 1;
    $fullpath="$in{'directory'}/$in{'file'}";
    $server=$in{'machine'};
#    $htmlheight=$lines * 1.3;
    $htmlheight="30em";
    $htmlwidth="190";
    print "<div style=\"overflow:auto;height:${htmlheight};margin-righ:10px;margin-left:10px\"><pre>";
    if ($server ne 'localhost')
    {
        $localfilter="";
        if ($filter ne "")
        {
            # Are we supposed to filter anything? Then use grep.
            # print "<i>View Log - Debug 1, machine: $in{'machine'} $lines lines, file $in{'file'}</i>\n";

            $ssh_command="grep $filter $fullpath | tail -n $lines";
        }
        else
        {
            # print "<i>View Log - Debug 2, machine: $in{'machine'} $lines lines, file $in{'file'}</i>\n";

            $ssh_command="tail -n $lines $fullpath";

	}
        $ssh_result = run_ssh_command($server, $ssh_command);
        if ($localfilter)
        {
            $localcommand="COLUMNS=$htmlwidth echo $ssh_result|$localfilter";
        }
        else
        {
    	    $got=$ssh_result;
	}
    }
    else
    {
        if ($filter)
        {
    	    # Are we supposed to filter anything? Then use grep.
    	    # print "<i>View Log - Debug 3, $lines lines, file $in{'file'}</i>\n";
#   	    $localcommand ="cat $fullpath | grep $filter | tail -n $lines";
   	    $localcommand ="grep $filter $fullpath | tail -n $lines";
	}
	else
	{
    	    # print "<i>View Log - Debug 4</i>\n";
   	    $localcommand = "tail -n $lines $fullpath";
	}
    }

    if ($localcommand)
    {
        $got = run_local_command($localcommand);
    }
    print "<i>$text{'view_empty'}: $in{'file'}</i>\n" if (!$got);
    print "</pre>\n";
    print "</div><br>\n";
    print_filter_form();
}

=head2 print_template_index

prints the index.cgi of every template

=cut
sub print_template_index
{
    # All stuff for index.cgi in the templates
    &ui_print_header(undef, $text{'index_title'}, "", undef, 1, 1);

    if ($config{'ssh_configfile'}) {
        $ssh_options = '-F ', $config{'ssh_configfile'};
    }

    print_servers_lists();

    &ui_print_footer("/", $text{'index'});
}

=head2 print_view_directory

prints the view_directory contents

=cut
sub print_view_directory
{
    # All the necessary stuff to view a directory
    &ReadParse();
    
    # Viewing a log directory

    $server=$in{'machine'};
    
    ## We redirect to view the file if it's a file
    if ( $server and $in{'file'} )
    {
	&redirect("view_log.cgi?machine=$server&file=$in{'directory'}/$in{'file'}&jobname=$in{'jobname'}&directory=0");
    }
    
    ## It's a directory, so we draw the result
    ## First, the html header
    &ui_print_header( undef, &text( 'dir_index_title', &text('index_title'), $server, $in{'directory'} ),
    "", undef, 0, 1 );
    
    # Some optional debug output
    #   print "<pre>machine:   $in{'machine'}<br>directory: $in{'directory'}<br>jobname: $in{'jobname'}</pre>";
    
    print_directory_index;
    
    &ui_print_footer( "", $text{'index_title'} );
}


=head2 print_view_log

prints the view_log contents

=cut
sub print_view_log
{
    # All necesary stuff to view a log file

    &ReadParse();
    &foreign_require("proc", "proc-lib.pl");
    
    # Viewing a log file
    $name = &html_escape("$in{'machine'}:$in{'jobname'}") if ($in{'machine'});
    &ui_print_header(undef, &text('view_title', $name), "", undef, 0, 1);
    
    &print_log_file();

    if ($in{'directory'} !~ "0") {
	&ui_print_footer("view_directory.cgi?machine=$in{'machine'}&directory=$in{'directory'}&jobname=$in{'jobname'}", $text{'index_return'});
    }
    else
    {
    &ui_print_footer("", $text{'index_title'});
    }
}

